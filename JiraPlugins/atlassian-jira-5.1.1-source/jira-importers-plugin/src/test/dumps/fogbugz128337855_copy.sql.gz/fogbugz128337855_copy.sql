CREATE TABLE `ACL`
(`ixACL` INT NOT NULL AUTO_INCREMENT, 
`sSectionName` VARCHAR(50) DEFAULT '' NOT NULL, 
`ixSection` INT DEFAULT 0 NOT NULL, 
`ixPerson` INT DEFAULT 0 NOT NULL, 
`iPermission` INT DEFAULT 0 NOT NULL, 
PRIMARY KEY(`ixACL`), 
INDEX `ACLsSectionNameixPersoniPermission`(`sSectionName`,`ixPerson`,`iPermission`), 
INDEX `ACLixPersonixSectioniPermissionsSectionName`(`ixPerson`,`ixSection`,`iPermission`,`sSectionName`), 
INDEX `ACLixSectioniPermissionixPersonsSectionName`(`ixSection`,`iPermission`,`ixPerson`,`sSectionName`)) ENGINE = MyISAM;

CREATE TABLE `Area`
(`ixArea` INT NOT NULL AUTO_INCREMENT, 
`ixProject` INT DEFAULT 0 NULL, 
`ixPersonOwner` INT DEFAULT -1 NOT NULL, 
`sArea` VARCHAR(50) DEFAULT '' NULL, 
`fDeleted` INT DEFAULT 0 NOT NULL, 
`nType` INT DEFAULT 0 NOT NULL, 
`cDoc` INT DEFAULT 0 NOT NULL, 
PRIMARY KEY(`ixArea`), 
INDEX `AreaIxAreaNTypeSArea`(`ixArea`,`nType`,`sArea`)) ENGINE = MyISAM;

CREATE TABLE `Attachment`
(`ixAttachment` INT NOT NULL AUTO_INCREMENT, 
`sData` LONGBLOB DEFAULT '' NOT NULL, 
`sFilename` VARCHAR(255) DEFAULT '' NULL, 
`fFileStatus` INT DEFAULT 0 NOT NULL, 
`ixBugEvent` INT DEFAULT 0 NULL, 
`ixWiki` INT DEFAULT 0 NULL, 
`ixTemplate` INT DEFAULT 0 NULL, 
PRIMARY KEY(`ixAttachment`), 
INDEX `AttachmentixBugEvent`(`ixBugEvent`)) ENGINE = MyISAM;

CREATE TABLE `AutoResponseRecord`
(`ixAutoResponseRecord` INT NOT NULL AUTO_INCREMENT, 
`sEmail` VARCHAR(255) NULL, 
`dt` DATETIME NULL, 
PRIMARY KEY(`ixAutoResponseRecord`)) ENGINE = MyISAM;

CREATE TABLE `Bug`
(`ixBug` INT NOT NULL AUTO_INCREMENT, 
`fOpen` INT DEFAULT 0 NULL, 
`dtOpened` DATETIME DEFAULT '2000-01-01 12:00:00' NULL, 
`sTitle` VARCHAR(128) DEFAULT '' NULL, 
`sOriginalTitle` VARCHAR(128) DEFAULT '' NULL, 
`ixBugEventLatestText` INT DEFAULT 0 NULL, 
`sLatestTextSummary` VARCHAR(255) DEFAULT '' NULL, 
`ixProject` INT DEFAULT 0 NULL, 
`ixArea` INT DEFAULT 0 NULL, 
`ixPersonOpenedBy` INT DEFAULT 0 NULL, 
`ixPersonAssignedTo` INT DEFAULT 0 NULL, 
`ixPersonResolvedBy` INT DEFAULT 0 NULL, 
`ixPersonClosedBy` INT DEFAULT 0 NULL, 
`ixPersonLastEditedBy` INT DEFAULT 0 NULL, 
`ixPersonEstimator` INT DEFAULT 0 NULL, 
`ixStatus` INT DEFAULT 0 NULL, 
`ixPriority` INT DEFAULT 0 NULL, 
`ixFixFor` INT DEFAULT 0 NULL, 
`sVersion` VARCHAR(40) DEFAULT '' NULL, 
`sComputer` VARCHAR(80) DEFAULT '' NULL, 
`hrsOrigEst` DOUBLE DEFAULT 0 NULL, 
`hrsCurrEst` DOUBLE DEFAULT 0 NULL, 
`hrsElapsed` DOUBLE DEFAULT 0 NULL, 
`hrsElapsedExtra` DOUBLE DEFAULT 0 NULL, 
`c` INT DEFAULT 0 NULL, 
`sCustomerEmail` VARCHAR(255) DEFAULT '0' NULL, 
`ixCategory` INT DEFAULT 1 NULL, 
`dtResolved` DATETIME NULL, 
`dtClosed` DATETIME NULL, 
`ixMailbox` INT DEFAULT 0 NULL, 
`ixBugEventLatest` INT NULL, 
`fTrained` SMALLINT DEFAULT 0 NOT NULL, 
`fReplied` SMALLINT DEFAULT 0 NOT NULL, 
`fForwarded` SMALLINT DEFAULT 0 NOT NULL, 
`fEstLocked` SMALLINT DEFAULT 0 NOT NULL, 
`ixOriginalPrediction` INT NULL, 
`nStatType` INT NULL, 
`sTicket` VARCHAR(40) DEFAULT '' NULL, 
`sReleaseNotes` LONGTEXT DEFAULT '' NULL, 
`ixDiscussTopic` INT NULL, 
`dtDue` DATETIME NULL, 
`ixTagEventLatest` INT DEFAULT -1 NOT NULL, 
`ixBugEmail` INT DEFAULT 0 NULL, 
`ixBugParent` INT DEFAULT 0 NOT NULL, 
`ixBugRoot` INT DEFAULT 0 NOT NULL, 
`iSetLeft` INT DEFAULT 0 NOT NULL, 
`iSetRight` INT DEFAULT 1 NOT NULL, 
PRIMARY KEY(`ixBug`), 
INDEX `BugixBugEmail`(`ixBugEmail`), 
INDEX `IX_IxPersonResolvedBy`(`ixPersonResolvedBy`), 
INDEX `IX_IxPersonClosedBy`(`ixPersonClosedBy`), 
INDEX `IX_IxPriority`(`ixPriority`), 
INDEX `IX_DtResolved`(`dtResolved`), 
INDEX `IX_DtClosed`(`dtClosed`), 
INDEX `IX_DtOpened`(`dtOpened`), 
INDEX `IX_DtDue`(`dtDue`), 
INDEX `IX_IxDiscussTopic`(`ixDiscussTopic`), 
INDEX `IX_IxBugParent`(`ixBugParent`), 
INDEX `IX_IxStatusCompound`(`ixStatus`,`ixBugParent`,`ixBug`), 
INDEX `IX_IxBugRootCompound`(`ixBugRoot`,`ixBug`,`iSetLeft`,`iSetRight`), 
INDEX `IX_IxPersonAssignedToCovering1`(`ixPersonAssignedTo`,`fOpen`,`ixPersonOpenedBy`,`ixCategory`,`ixBug`,`ixProject`,`ixArea`), 
INDEX `IX_IxPersonAssignedToCovering2`(`ixPersonAssignedTo`,`fOpen`,`ixCategory`,`ixBug`,`ixArea`,`ixProject`), 
INDEX `IX_IxPersonAssignedToCovering3`(`ixPersonAssignedTo`,`ixProject`,`ixArea`), 
INDEX `IX_BugCompoundfOpen`(`fOpen`,`ixProject`,`ixArea`), 
INDEX `IX_FOpenIxPersonAssignedToHrsEstElapsed`(`fOpen`,`ixPersonAssignedTo`,`hrsCurrEst`,`hrsElapsed`), 
INDEX `IX_BugCompoundixArea`(`ixArea`,`fOpen`,`ixProject`), 
INDEX `IX_BugCompoundixBugEventLatestDesc`(`ixBugEventLatest`,`ixArea`,`ixProject`), 
INDEX `IX_BugCompoundixProject`(`ixProject`,`ixBug`,`ixArea`), 
INDEX `IX_BugCompoundixBug`(`ixBug`,`ixArea`,`ixProject`)) ENGINE = MyISAM;

CREATE TABLE `BugEmail`
(`ixBugEmail` INT NOT NULL AUTO_INCREMENT, 
`sEmail` VARCHAR(255) DEFAULT '' NULL, 
`sFullName` VARCHAR(255) DEFAULT '' NULL, 
PRIMARY KEY(`ixBugEmail`), 
INDEX `BugEmailsEmail`(`sEmail`)) ENGINE = MyISAM;

CREATE TABLE `BugEvent`
(`ixBugEvent` INT NOT NULL AUTO_INCREMENT, 
`ixBug` INT DEFAULT 0 NULL, 
`sVerb` VARCHAR(128) NULL, 
`dt` DATETIME NULL, 
`ixPerson` INT DEFAULT 0 NULL, 
`s` LONGTEXT NULL, 
`fEmail` SMALLINT DEFAULT 0 NULL, 
`fExternal` SMALLINT DEFAULT 0 NULL, 
`sChanges` LONGTEXT NULL, 
`sHTML` LONGTEXT NULL, 
`fHTML` SMALLINT DEFAULT 0 NOT NULL, 
`ixPersonAssignedTo` INT DEFAULT 0 NOT NULL, 
`sStatus` VARCHAR(50) DEFAULT '' NOT NULL, 
PRIMARY KEY(`ixBugEvent`), 
INDEX `IX_BugCompound`(`ixBug`,`dt`,`ixBugEvent`), 
INDEX `IX_Person`(`ixPerson`,`ixBug`,`ixBugEvent`)) ENGINE = MyISAM;

CREATE TABLE `BugRelation`
(`ixBugRelation` INT NOT NULL AUTO_INCREMENT, 
`ixBugFrom` INT DEFAULT 0 NOT NULL, 
`ixBugTo` INT DEFAULT 0 NOT NULL, 
`ixWikiPageFrom` INT DEFAULT 0 NOT NULL, 
`ixWikiPageTo` INT DEFAULT 0 NOT NULL, 
PRIMARY KEY(`ixBugRelation`), 
INDEX `BugRelationIxBugFrom`(`ixBugFrom`), 
INDEX `BugRelationIxBugTo`(`ixBugTo`), 
INDEX `BugRelationIxWikiPageTo`(`ixWikiPageTo`)) ENGINE = MyISAM;

CREATE TABLE `BugView`
(`ixBugView` INT NOT NULL AUTO_INCREMENT, 
`ixPerson` INT DEFAULT 0 NOT NULL, 
`ixBug` INT DEFAULT 0 NOT NULL, 
`ixBugEvent` INT DEFAULT 0 NOT NULL, 
`dt` DATETIME NULL, 
PRIMARY KEY(`ixBugView`), 
INDEX `BugViewIxPersonCompound`(`ixPerson`,`ixBugEvent`,`dt`,`ixBug`), 
INDEX `BugViewIxBug`(`ixBug`), 
INDEX `BugViewSuggested1`(`ixPerson`,`ixBugView`,`dt`,`ixBug`), 
INDEX `BugViewPersonDtReverse`(`ixPerson`,`dt`), 
INDEX `IX_BugViewCompound`(`ixBug`,`ixPerson`,`ixBugView`,`ixBugEvent`,`dt`)) ENGINE = MyISAM;

CREATE TABLE `BugViewPinnedField`
(`ixBugViewPinnedField` INT NOT NULL AUTO_INCREMENT, 
`ixPerson` INT DEFAULT 0 NOT NULL, 
`ixPlugin` INT DEFAULT -1 NOT NULL, 
`sField` VARCHAR(50) NULL, 
PRIMARY KEY(`ixBugViewPinnedField`), 
INDEX `BugViewPinnedFieldIxPersonSFieldIxPlugin`(`ixPerson`,`sField`,`ixPlugin`)) ENGINE = MyISAM;

CREATE TABLE `Category`
(`ixCategory` INT NOT NULL AUTO_INCREMENT, 
`sCategory` VARCHAR(50) DEFAULT '' NOT NULL, 
`sPlural` VARCHAR(50) DEFAULT '' NOT NULL, 
`ixStatusDefault` INT NULL, 
`fIsScheduleItem` INT DEFAULT 0 NOT NULL, 
`fDeleted` SMALLINT DEFAULT 0 NOT NULL, 
`iOrder` INT DEFAULT 0 NOT NULL, 
`nIconType` INT DEFAULT 0 NOT NULL, 
`ixAttachmentIcon` INT DEFAULT 0 NOT NULL, 
`ixStatusDefaultActive` INT DEFAULT 0 NOT NULL, 
PRIMARY KEY(`ixCategory`)) ENGINE = MyISAM;

CREATE TABLE `CVS`
(`ixCVS` INT NOT NULL AUTO_INCREMENT, 
`ixBug` INT DEFAULT 0 NOT NULL, 
`sFile` VARCHAR(255) DEFAULT '' NOT NULL, 
`sPrev` VARCHAR(255) DEFAULT '' NOT NULL, 
`sNew` VARCHAR(255) DEFAULT '' NOT NULL, 
`ixRepository` INT DEFAULT 0 NOT NULL, 
PRIMARY KEY(`ixCVS`), 
INDEX `CVSIxBug`(`ixBug`)) ENGINE = MyISAM;

CREATE TABLE `DBCopier`
(`ixDBCopier` INT NOT NULL AUTO_INCREMENT, 
`sConnStrSrc` VARCHAR(255) NULL, 
`sConnStrDest` VARCHAR(255) NULL, 
`sTableCurrent` VARCHAR(255) NULL, 
`ixLastCopied` INT NULL, 
`dtStartedCopy` DATETIME NULL, 
`nDBCopyState` INT NULL, 
`nDownloadTarget` INT NULL, 
`sFailureError` LONGTEXT NOT NULL, 
PRIMARY KEY(`ixDBCopier`)) ENGINE = MyISAM;

CREATE TABLE `DbSession`
(`ixDbSession` INT NOT NULL AUTO_INCREMENT, 
`sSessionId` VARCHAR(255) DEFAULT '' NOT NULL, 
`dtLastAccess` DATETIME NULL, 
PRIMARY KEY(`ixDbSession`), 
INDEX `DbSession_sSessionId`(`sSessionId`)) ENGINE = MyISAM;

CREATE TABLE `DbSessionData`
(`ixDbSessionData` INT NOT NULL AUTO_INCREMENT, 
`ixDbSession` INT DEFAULT 0 NOT NULL, 
`sKey` VARCHAR(255) DEFAULT '' NOT NULL, 
`sValue` LONGTEXT NULL, 
`fSerialized` INT DEFAULT 0 NOT NULL, 
PRIMARY KEY(`ixDbSessionData`), 
INDEX `DbSessionData_ixDbSession`(`ixDbSession`)) ENGINE = MyISAM;

CREATE TABLE `DBUpdate`
(`ixDBUpdate` INT NOT NULL AUTO_INCREMENT, 
`sUpgradeKey` VARCHAR(30) NULL, 
`nChangeType` INT NULL, 
`sChangeSpecifics` VARCHAR(80) NULL, 
`fReversed` INT NULL, 
PRIMARY KEY(`ixDBUpdate`)) ENGINE = MyISAM;

CREATE TABLE `Dictionary`
(`ixPKDictionary` INT NOT NULL AUTO_INCREMENT, 
`ixDictionary` INT DEFAULT 0 NOT NULL, 
`sDictionary` VARCHAR(128) NOT NULL, 
`sDescription` VARCHAR(128) NOT NULL, 
PRIMARY KEY(`ixPKDictionary`)) ENGINE = MyISAM;

CREATE TABLE `DiscussEmail`
(`ixDiscussEmail` INT NOT NULL AUTO_INCREMENT, 
`dt` DATETIME NOT NULL, 
`sRemoteIP` VARCHAR(128) DEFAULT '0.0.0.0' NULL, 
`ixDiscussTopic` INT DEFAULT 0 NOT NULL, 
`sUniqueID` VARCHAR(40) DEFAULT '' NOT NULL, 
`sUniqueEmail` VARCHAR(40) DEFAULT '' NOT NULL, 
`sFullName` VARCHAR(128) NULL, 
`sEmail` VARCHAR(128) NULL, 
PRIMARY KEY(`ixDiscussEmail`), 
INDEX `DiscussEmailSUniqueID`(`sUniqueID`), 
INDEX `DiscussEmailSUniqueEmail`(`sUniqueEmail`), 
INDEX `DiscussEmailIP`(`sRemoteIP`)) ENGINE = MyISAM;

CREATE TABLE `DiscussGroup`
(`ixDiscussGroup` INT NOT NULL AUTO_INCREMENT, 
`sFullName` VARCHAR(255) NULL, 
`sURLName` VARCHAR(32) NULL, 
`sTagLineHTML` LONGTEXT NULL, 
`sSidebarHTML` LONGTEXT NULL, 
`sPostHelpHTML` LONGTEXT NULL, 
`ixAreaSpam` INT DEFAULT 0 NOT NULL, 
`ixAreaNonSpam` INT DEFAULT 0 NOT NULL, 
`cDaysHomePage` INT DEFAULT 30 NOT NULL, 
`fDeleted` SMALLINT DEFAULT 0 NOT NULL, 
`fRequireApproval` SMALLINT DEFAULT 1 NOT NULL, 
`ixAreaUndecided` INT DEFAULT -1 NOT NULL, 
`ixGroup` INT DEFAULT 0 NULL, 
PRIMARY KEY(`ixDiscussGroup`), 
INDEX `IX_ixGroup`(`ixGroup`)) ENGINE = MyISAM;

CREATE TABLE `DiscussLayout`
(`ixDiscussLayout` INT NOT NULL AUTO_INCREMENT, 
`sTopHTML` LONGTEXT DEFAULT '' NOT NULL, 
`sBottomHTML` LONGTEXT DEFAULT '' NOT NULL, 
`sStylesCSS` LONGTEXT DEFAULT '' NOT NULL, 
`cPixelsLeftSidebar` INT DEFAULT 125 NULL, 
`cPixelsMain` INT DEFAULT 600 NULL, 
PRIMARY KEY(`ixDiscussLayout`)) ENGINE = MyISAM;

CREATE TABLE `DiscussTopic`
(`ixDiscussTopic` INT NOT NULL AUTO_INCREMENT, 
`ixDiscussGroup` INT DEFAULT 0 NOT NULL, 
`sHeadline` VARCHAR(64) NULL, 
`ixDiscussTopicParent` INT DEFAULT 0 NOT NULL, 
`sFullName` VARCHAR(128) NULL, 
`sURL` VARCHAR(128) NULL, 
`sEmail` VARCHAR(128) NULL, 
`dt` DATETIME NULL, 
`sUniqueID` VARCHAR(40) NULL, 
`sUniquePost` VARCHAR(40) NULL, 
`sUserAgent` VARCHAR(255) DEFAULT 'Unrecorded' NULL, 
`sPost` LONGTEXT NULL, 
`ixPerson` INT NULL, 
`sRemoteIP` VARCHAR(128) DEFAULT '0.0.0.0' NULL, 
`sRemoteSubNetIP` VARCHAR(128) DEFAULT '0.0.0' NULL, 
`ixPersonDeletedBy` INT DEFAULT 0 NOT NULL, 
`ixArea` SMALLINT NULL, 
`fTrained` SMALLINT NULL, 
PRIMARY KEY(`ixDiscussTopic`), 
INDEX `DiscussTopicSUniquePost`(`sUniquePost`), 
INDEX `DiscussTopicDt`(`dt`), 
INDEX `DiscussTopicGetChild`(`ixArea`,`ixPersonDeletedBy`), 
INDEX `DiscussTopicSuggested1`(`ixDiscussTopic`,`ixDiscussGroup`,`ixArea`,`sHeadline`,`ixDiscussTopicParent`), 
INDEX `IX_DiscussTopicCompound`(`ixDiscussTopic`,`ixPerson`,`sUniqueID`,`ixArea`,`sRemoteSubNetIP`), 
INDEX `DiscussTopicSuggested2`(`ixDiscussTopicParent`,`ixDiscussTopic`,`ixDiscussGroup`,`ixArea`,`sHeadline`), 
INDEX `DiscussTopicSuggested4`(`ixDiscussTopicParent`,`ixDiscussTopic`,`dt`,`ixDiscussGroup`,`ixPerson`), 
INDEX `DiscussTopicGetSpam`(`ixDiscussTopicParent`,`dt`,`ixArea`,`ixPersonDeletedBy`), 
INDEX `DiscussTopicSuggested3b`(`sUniqueID`,`sRemoteSubNetIP`,`ixDiscussTopicParent`,`ixDiscussTopic`), 
INDEX `DiscussTopicSuggested5`(`ixDiscussGroup`,`ixDiscussTopicParent`,`dt`,`ixDiscussTopic`,`ixPerson`)) ENGINE = MyISAM;

CREATE TABLE `DiscussTopicView`
(`ixDiscussTopicView` INT NOT NULL AUTO_INCREMENT, 
`ixPerson` INT DEFAULT 0 NOT NULL, 
`ixDiscussTopicFirst` INT DEFAULT 0 NOT NULL, 
`ixDiscussTopicLast` INT DEFAULT 0 NOT NULL, 
`dt` DATETIME NULL, 
PRIMARY KEY(`ixDiscussTopicView`), 
INDEX `DiscussTopicViewPersonDtReverse`(`ixPerson`,`dt`), 
INDEX `DiscussTopicViewSuggested1`(`ixPerson`,`ixDiscussTopicFirst`,`ixDiscussTopicView`,`ixDiscussTopicLast`)) ENGINE = MyISAM;

CREATE TABLE `DocList`
(`ixDocList` INT NOT NULL AUTO_INCREMENT, 
`ixPerson` INT DEFAULT 0 NOT NULL, 
`sName` VARCHAR(40) DEFAULT 0 NOT NULL, 
`fFavorites` INT DEFAULT 0 NOT NULL, 
PRIMARY KEY(`ixDocList`), 
INDEX `DocListIxPerson`(`ixPerson`)) ENGINE = MyISAM;

CREATE TABLE `DocListItem`
(`ixDocListItem` INT NOT NULL AUTO_INCREMENT, 
`ixDocList` INT DEFAULT 0 NOT NULL, 
`sType` VARCHAR(40) NULL, 
`ixItem` INT DEFAULT 0 NOT NULL, 
`nPos` INT DEFAULT 0 NOT NULL, 
PRIMARY KEY(`ixDocListItem`), 
INDEX `DocListItemSType`(`sType`), 
INDEX `DocListItemIxItem`(`ixItem`), 
INDEX `DocListItemIxDocListInOrder`(`ixDocList`,`nPos`), 
INDEX `IX_DocListCompound`(`ixDocList`,`sType`,`ixItem`,`nPos`)) ENGINE = MyISAM;

CREATE TABLE `Draft`
(`ixDraft` INT NOT NULL AUTO_INCREMENT, 
`ixPerson` INT DEFAULT 0 NOT NULL, 
`ixItem` INT DEFAULT 0 NOT NULL, 
`nRevision` INT DEFAULT 0 NULL, 
`sType` VARCHAR(128) NULL, 
`sDraft` LONGTEXT NULL, 
`dt` DATETIME NULL, 
PRIMARY KEY(`ixDraft`), 
INDEX `DraftIxPerson`(`ixPerson`), 
INDEX `DraftIxItem`(`ixItem`), 
INDEX `DraftSType`(`sType`)) ENGINE = MyISAM;

CREATE TABLE `Duplicates`
(`ixDuplicates` INT NOT NULL AUTO_INCREMENT, 
`ixBugDupe` INT DEFAULT 0 NOT NULL, 
`ixBugDupeOf` INT DEFAULT 0 NOT NULL, 
PRIMARY KEY(`ixDuplicates`), 
INDEX `IX_IxBugDupeIxBugDupeOf`(`ixBugDupe`,`ixBugDupeOf`)) ENGINE = MyISAM;

CREATE TABLE `EmailWildcard`
(`ixEmailWildcard` INT NOT NULL AUTO_INCREMENT, 
`sEmailDomain` VARCHAR(255) NULL, 
`ixGroup` INT NULL, 
`iPermission` INT NULL, 
PRIMARY KEY(`ixEmailWildcard`)) ENGINE = MyISAM;

CREATE TABLE `FBLanguage`
(`ixLanguage` INT NOT NULL AUTO_INCREMENT, 
`sName` VARCHAR(50) NOT NULL, 
`sLCID` VARCHAR(10) NOT NULL, 
`sLangFile` VARCHAR(20) NULL, 
`sLocaleCode` VARCHAR(11) NOT NULL, 
`sGenericLocaleCode` VARCHAR(5) NULL, 
PRIMARY KEY(`ixLanguage`), 
INDEX `LanguageName`(`sName`), 
INDEX `LanguageLCID`(`sLCID`), 
INDEX `LanguageLocaleCode`(`sLocaleCode`)) ENGINE = MyISAM;

CREATE TABLE `FBLock`
(`ixFBLock` INT NOT NULL AUTO_INCREMENT, 
`sLock` VARCHAR(255) DEFAULT '' NOT NULL, 
`sKey` VARCHAR(255) DEFAULT '' NOT NULL, 
`dtExpires` DATETIME NULL, 
`fBrokeLock` INT DEFAULT 0 NOT NULL, 
PRIMARY KEY(`ixFBLock`), 
INDEX `FBLockSLockSKey`(`sLock`,`sKey`)) ENGINE = MyISAM;

CREATE TABLE `Filter`
(`ixFilter` INT NOT NULL AUTO_INCREMENT, 
`fOpenBugs` VARCHAR(4) DEFAULT 'ON' NULL, 
`ixProject` INT NULL, 
`ixArea` INT NULL, 
`ixPersonOpenedBy` INT NULL, 
`ixPersonAssignedTo` INT NULL, 
`ixPersonResolvedBy` INT DEFAULT -1 NULL, 
`ixPersonClosedBy` INT DEFAULT -1 NULL, 
`ixPersonLastEditedBy` INT DEFAULT -1 NULL, 
`ixStatus` INT NULL, 
`ixPriority` INT NULL, 
`ixGroup` INT NULL, 
`maxrecords` INT NULL, 
`sort1` INT DEFAULT 0 NULL, 
`sort2` INT DEFAULT 0 NULL, 
`sort3` INT DEFAULT 0 NULL, 
`ixPluginSort1` INT DEFAULT -1 NOT NULL, 
`ixPluginSort2` INT DEFAULT -1 NOT NULL, 
`ixPluginSort3` INT DEFAULT -1 NOT NULL, 
`fDescendingSort1` SMALLINT DEFAULT 0 NOT NULL, 
`fDescendingSort2` SMALLINT DEFAULT 0 NOT NULL, 
`fDescendingSort3` SMALLINT DEFAULT 0 NOT NULL, 
`ixFixFor` INT DEFAULT 0 NULL, 
`openInLast` INT DEFAULT 0 NULL, 
`ixPerson` INT NULL, 
`sFilterName` VARCHAR(40) NULL, 
`fClosedBugs` VARCHAR(4) DEFAULT 'OFF' NULL, 
`priorityRange` INT NULL, 
`sentBy` VARCHAR(255) DEFAULT '' NULL, 
`sComputer` VARCHAR(255) DEFAULT '' NULL, 
`sVersion` VARCHAR(255) DEFAULT '' NULL, 
`resolvedInLast` INT NULL, 
`closedInLast` INT NULL, 
`dueInNext` INT NULL, 
`ixCategory` INT NULL, 
`fMissingEstimate` INT DEFAULT 0 NULL, 
`fNoParent` INT DEFAULT 0 NULL, 
`fNoChildren` INT DEFAULT 0 NULL, 
`fSubscribedBugs` INT DEFAULT 0 NULL, 
`fSeenByMe` INT DEFAULT 0 NULL, 
`fGlobal` SMALLINT DEFAULT 0 NOT NULL, 
`fGridView` INT DEFAULT 1 NULL, 
`fFlatView` INT DEFAULT 0 NULL, 
`sSearchFor` LONGTEXT NULL, 
`sTags` LONGTEXT NULL, 
PRIMARY KEY(`ixFilter`), 
INDEX `FiltersFilterName`(`sFilterName`), 
INDEX `FilterixPerson`(`ixPerson`)) ENGINE = MyISAM;

CREATE TABLE `FixFor`
(`ixFixFor` INT NOT NULL AUTO_INCREMENT, 
`sFixFor` VARCHAR(255) NULL, 
`dt` DATETIME NULL, 
`fDeleted` INT DEFAULT 0 NULL, 
`ixProject` INT DEFAULT 0 NULL, 
`fInactive` SMALLINT DEFAULT 0 NULL, 
`dtStart` DATETIME NULL, 
`sStartNote` VARCHAR(255) NULL, 
PRIMARY KEY(`ixFixFor`)) ENGINE = MyISAM;

CREATE TABLE `FixForDependency`
(`ixFixForDependency` INT NOT NULL AUTO_INCREMENT, 
`ixFixFor` INT NOT NULL, 
`ixFixForDependsOn` INT NOT NULL, 
PRIMARY KEY(`ixFixForDependency`), 
INDEX `FixForDependencyixFixFor`(`ixFixFor`)) ENGINE = MyISAM;

CREATE TABLE `FragmentCache`
(`ixFragmentCache` INT NOT NULL AUTO_INCREMENT, 
`ixPerson` INT DEFAULT 0 NOT NULL, 
`sKey` VARCHAR(128) NULL, 
`sParams` VARCHAR(128) NULL, 
`sValue` LONGTEXT NULL, 
`dt` DATETIME NULL, 
PRIMARY KEY(`ixFragmentCache`), 
INDEX `FragmentCacheIxPerson`(`ixPerson`), 
INDEX `FragmentCache_SearchCompound`(`sParams`,`sKey`,`ixPerson`), 
INDEX `FragmentCache_Compound`(`sKey`,`sParams`,`ixPerson`)) ENGINE = MyISAM;

CREATE TABLE `FragmentDependency`
(`ixFragmentDependency` INT NOT NULL AUTO_INCREMENT, 
`sKey` VARCHAR(128) NULL, 
`sDependency` VARCHAR(128) NULL, 
PRIMARY KEY(`ixFragmentDependency`), 
INDEX `FragmentCacheSKey`(`sKey`), 
INDEX `FragmentCacheSDependency`(`sDependency`)) ENGINE = MyISAM;

CREATE TABLE `GridColumn`
(`ixGridColumn` INT NOT NULL AUTO_INCREMENT, 
`ixPerson` INT DEFAULT -1 NOT NULL, 
`ixFilter` INT DEFAULT -1 NOT NULL, 
`ixPlugin` INT DEFAULT -1 NOT NULL, 
`iType` INT DEFAULT -1 NOT NULL, 
`iOrder` INT DEFAULT -1 NULL, 
`pxWidth` INT DEFAULT 0 NULL, 
`fVisible` INT DEFAULT 0 NULL, 
PRIMARY KEY(`ixGridColumn`), 
INDEX `GridColumnCompound5`(`ixPlugin`,`iType`,`ixPerson`), 
INDEX `GridColumnCompound4`(`ixPlugin`,`iType`,`ixFilter`), 
INDEX `GridColumnCompound1`(`ixPerson`,`fVisible`,`iOrder`), 
INDEX `IX_IxPersonIType`(`ixPerson`,`iType`), 
INDEX `IX_IxFilterCompound`(`ixFilter`,`fVisible`,`iType`,`iOrder`,`ixGridColumn`,`ixPerson`)) ENGINE = MyISAM;

CREATE TABLE `Groups`
(`ixGroup` INT NOT NULL AUTO_INCREMENT, 
`sName` VARCHAR(255) DEFAULT '' NULL, 
`sNotes` LONGTEXT DEFAULT '' NOT NULL, 
`fDeleted` SMALLINT DEFAULT 0 NULL, 
PRIMARY KEY(`ixGroup`)) ENGINE = MyISAM;

CREATE TABLE `Holiday`
(`ixHoliday` INT NOT NULL AUTO_INCREMENT, 
`ixPerson` INT DEFAULT 0 NOT NULL, 
`sHoliday` VARCHAR(255) NULL, 
`dtHoliday` DATETIME NULL, 
`dtHolidayEnd` DATETIME NULL, 
PRIMARY KEY(`ixHoliday`)) ENGINE = MyISAM;

CREATE TABLE `ID`
(`id` VARCHAR(30) DEFAULT '' NOT NULL) ENGINE = MyISAM;

CREATE TABLE `IgnoredWord`
(`ixIgnoredWord` INT NOT NULL AUTO_INCREMENT, 
`sIgnoredWord` VARCHAR(255) NOT NULL, 
`ixWikiPage` INT DEFAULT 0 NOT NULL, 
PRIMARY KEY(`ixIgnoredWord`)) ENGINE = MyISAM;

CREATE TABLE `IndexDelta`
(`ixIndexDelta` INT NOT NULL AUTO_INCREMENT, 
`sType` VARCHAR(255) NULL, 
`ix` INT NULL, 
`fDeleted` INT DEFAULT 0 NULL, 
PRIMARY KEY(`ixIndexDelta`), 
INDEX `IX_sType`(`sType`,`fDeleted`,`ix`)) ENGINE = MyISAM;

CREATE TABLE `IndexFile`
(`ixIndexFile` INT NOT NULL AUTO_INCREMENT, 
`sPrefix` VARCHAR(255) DEFAULT '' NOT NULL, 
`sFilename` VARCHAR(255) DEFAULT '' NOT NULL, 
`sLockKey` VARCHAR(255) DEFAULT '' NOT NULL, 
`nLastModifiedLo` INT DEFAULT 0 NOT NULL, 
`nLastModifiedHi` INT DEFAULT 0 NOT NULL, 
`cbLengthLo` INT DEFAULT 0 NOT NULL, 
`cbLengthHi` INT DEFAULT 0 NOT NULL, 
`ixFirstGeneration` INT DEFAULT 1 NOT NULL, 
`ixLastGeneration` INT DEFAULT 1 NOT NULL, 
`dtExpires` DATETIME NULL, 
PRIMARY KEY(`ixIndexFile`), 
INDEX `IX_sFilename`(`sFilename`), 
INDEX `IX_ixFirstGeneration`(`ixFirstGeneration`), 
INDEX `IX_ixLastGeneration`(`ixLastGeneration`)) ENGINE = MyISAM;

CREATE TABLE `IndexFilePage`
(`ixIndexFilePage` INT NOT NULL AUTO_INCREMENT, 
`ixIndexFile` INT DEFAULT 0 NOT NULL, 
`nPage` INT DEFAULT 0 NOT NULL, 
`sPage` BLOB NULL, 
PRIMARY KEY(`ixIndexFilePage`), 
INDEX `IX_ixIndexFile_nPage`(`ixIndexFile`,`nPage`)) ENGINE = MyISAM;

CREATE TABLE `Licenses`
(`ixLicense` INT NOT NULL AUTO_INCREMENT, 
`sLicense` VARCHAR(255) DEFAULT '' NULL, 
`sSignature` BLOB NULL, 
`sLicense2` VARCHAR(255) DEFAULT '' NULL, 
`sSignature2` BLOB NULL, 
`sLicense3` VARCHAR(255) DEFAULT '' NULL, 
`sSignature3` BLOB NULL, 
PRIMARY KEY(`ixLicense`)) ENGINE = MyISAM;

CREATE TABLE `Mailbox`
(`ixMailbox` INT NOT NULL AUTO_INCREMENT, 
`sEmail` VARCHAR(255) DEFAULT '' NOT NULL, 
`sFullName` VARCHAR(255) DEFAULT '' NOT NULL, 
`sUser` VARCHAR(255) DEFAULT '' NOT NULL, 
`sPass` VARCHAR(255) DEFAULT '' NOT NULL, 
`sServer` VARCHAR(255) DEFAULT '' NOT NULL, 
`sPort` VARCHAR(255) DEFAULT '' NOT NULL, 
`sURLPrefix` VARCHAR(255) DEFAULT '' NOT NULL, 
`sTemplate` LONGTEXT DEFAULT '' NOT NULL, 
`ixProject` INT DEFAULT 0 NOT NULL, 
`ixArea` INT DEFAULT 0 NOT NULL, 
`ixFixFor` INT DEFAULT 0 NOT NULL, 
`ixPriority` INT DEFAULT 0 NOT NULL, 
`ixPersonOpenedBy` INT DEFAULT 0 NOT NULL, 
`ixPersonAssignedTo` INT DEFAULT 0 NOT NULL, 
`nDeleteSPAM` INT NULL, 
`nDeleteInquiries` INT NULL, 
`fDeleted` SMALLINT DEFAULT 0 NOT NULL, 
`fAutoSort` SMALLINT DEFAULT 0 NULL, 
`fAutoReply` SMALLINT DEFAULT 0 NULL, 
`sReplySubject` LONGTEXT DEFAULT '' NOT NULL, 
`sReplyMessage` LONGTEXT DEFAULT '' NOT NULL, 
`fDueDate` SMALLINT DEFAULT 0 NULL, 
`nDue` INT DEFAULT 0 NOT NULL, 
`nDueTime` INT DEFAULT 0 NOT NULL, 
`sLastMessageDownloaded` VARCHAR(255) DEFAULT '' NOT NULL, 
`dtLastChecked` DATETIME DEFAULT '2000-01-01 12:00:00' NOT NULL, 
`nInterval` INT DEFAULT 15 NOT NULL, 
`fTrialMailbox` SMALLINT DEFAULT 0 NULL, 
`sAliases` VARCHAR(255) DEFAULT '' NOT NULL, 
PRIMARY KEY(`ixMailbox`)) ENGINE = MyISAM;

CREATE TABLE `MailQueue`
(`ixMailQueue` INT NOT NULL AUTO_INCREMENT, 
`dt` DATETIME NULL, 
`sHeaders` LONGTEXT DEFAULT '' NOT NULL, 
`sMessage` LONGTEXT DEFAULT '' NOT NULL, 
`cTries` INT DEFAULT 0 NOT NULL, 
`nType` SMALLINT DEFAULT 0 NOT NULL, 
`ixOther` INT DEFAULT 0 NULL, 
PRIMARY KEY(`ixMailQueue`)) ENGINE = MyISAM;

CREATE TABLE `Notification`
(`ixNotification` INT NOT NULL AUTO_INCREMENT, 
`sShortDesc` LONGTEXT DEFAULT '' NOT NULL, 
`sLongDesc` LONGTEXT DEFAULT '' NOT NULL, 
`sURL` VARCHAR(255) NULL, 
`fLongDescHtml` INT DEFAULT 0 NOT NULL, 
PRIMARY KEY(`ixNotification`)) ENGINE = MyISAM;

CREATE TABLE `PasswordResetCode`
(`ixPasswordResetCode` INT NOT NULL AUTO_INCREMENT, 
`ixPerson` INT NOT NULL, 
`sPasswordResetCode` VARCHAR(255) DEFAULT '' NULL, 
PRIMARY KEY(`ixPasswordResetCode`), 
INDEX `PasswordResetCode_Compound1`(`ixPerson`,`sPasswordResetCode`)) ENGINE = MyISAM;

CREATE TABLE `Person`
(`ixPerson` INT NOT NULL AUTO_INCREMENT, 
`sFullName` VARCHAR(50) NULL, 
`sEmail` VARCHAR(255) DEFAULT '' NULL, 
`sPassword` VARCHAR(50) NULL, 
`fNotify` INT DEFAULT 0 NULL, 
`fEscalationReport` INT DEFAULT 0 NULL, 
`sVersion` VARCHAR(40) NULL, 
`sComputer` VARCHAR(80) NULL, 
`sPhone` VARCHAR(32) NULL, 
`fExpert` INT DEFAULT 0 NULL, 
`fAdministrator` INT DEFAULT 0 NULL, 
`fDeleted` INT DEFAULT 0 NULL, 
`sFrom` VARCHAR(255) DEFAULT '' NULL, 
`fGridView` INT DEFAULT 0 NULL, 
`ixArea` INT NULL, 
`ixBugWorkingOn` INT DEFAULT 0 NOT NULL, 
`sVersionSeen` VARCHAR(255) DEFAULT '' NULL, 
`sContractSeen` VARCHAR(255) DEFAULT '' NULL, 
`sPasswordVersion` VARCHAR(255) DEFAULT '' NULL, 
`sSnippetKey` VARCHAR(2) DEFAULT '`' NOT NULL, 
`sLDAPUid` VARCHAR(50) NULL, 
`fMostRecentEventFirst` INT DEFAULT 0 NOT NULL, 
`fCommunity` SMALLINT DEFAULT 0 NOT NULL, 
`fConfirmed` SMALLINT DEFAULT 0 NOT NULL, 
`fVirtual` SMALLINT DEFAULT 0 NOT NULL, 
`sHomepage` VARCHAR(255) DEFAULT '' NULL, 
`dtRegistered` DATETIME NULL, 
`FILTER_fOpenBugs` VARCHAR(4) DEFAULT 'ON' NULL, 
`FILTER_fClosedBugs` VARCHAR(4) DEFAULT 'OFF' NULL, 
`FILTER_ixProject` INT DEFAULT -1 NULL, 
`FILTER_ixArea` INT DEFAULT -1 NULL, 
`FILTER_ixPersonOpenedBy` INT DEFAULT -1 NOT NULL, 
`FILTER_ixPersonAssignedTo` INT DEFAULT -1 NOT NULL, 
`FILTER_ixPersonResolvedBy` INT DEFAULT -1 NOT NULL, 
`FILTER_ixPersonClosedBy` INT DEFAULT -1 NOT NULL, 
`FILTER_ixPersonLastEditedBy` INT DEFAULT -1 NOT NULL, 
`FILTER_ixStatus` INT DEFAULT -1 NOT NULL, 
`FILTER_ixPriority` INT DEFAULT -1 NOT NULL, 
`FILTER_maxrecords` INT DEFAULT 0 NULL, 
`FILTER_sort1` INT DEFAULT 0 NOT NULL, 
`FILTER_sort2` INT DEFAULT 0 NOT NULL, 
`FILTER_sort3` INT DEFAULT 0 NOT NULL, 
`FILTER_ixPluginSort1` INT DEFAULT -1 NOT NULL, 
`FILTER_ixPluginSort2` INT DEFAULT -1 NOT NULL, 
`FILTER_ixPluginSort3` INT DEFAULT -1 NOT NULL, 
`FILTER_fDescendingSort1` SMALLINT DEFAULT 0 NOT NULL, 
`FILTER_fDescendingSort2` SMALLINT DEFAULT 0 NOT NULL, 
`FILTER_fDescendingSort3` SMALLINT DEFAULT 0 NOT NULL, 
`FILTER_ixFixFor` INT DEFAULT -1 NOT NULL, 
`FILTER_openInLast` INT DEFAULT -1 NOT NULL, 
`FILTER_priorityRange` INT DEFAULT 0 NOT NULL, 
`FILTER_sentBy` VARCHAR(255) DEFAULT '' NOT NULL, 
`FILTER_sComputer` VARCHAR(255) DEFAULT '' NOT NULL, 
`FILTER_sVersion` VARCHAR(255) DEFAULT '' NOT NULL, 
`FILTER_resolvedInLast` INT DEFAULT -1 NOT NULL, 
`FILTER_closedInLast` INT DEFAULT -1 NOT NULL, 
`FILTER_dueInNext` INT DEFAULT -1 NOT NULL, 
`FILTER_ixCategory` INT DEFAULT -1 NOT NULL, 
`FILTER_fFlatView` INT DEFAULT 0 NOT NULL, 
`FILTER_fNoParent` INT DEFAULT 0 NOT NULL, 
`FILTER_fNoChildren` INT DEFAULT 0 NOT NULL, 
`FILTER_fMissingEstimate` INT DEFAULT 0 NOT NULL, 
`FILTER_fSubscribedBugs` INT DEFAULT 0 NOT NULL, 
`FILTER_fSeenByMe` INT DEFAULT 0 NOT NULL, 
`FILTER_ixGroup` INT DEFAULT -1 NOT NULL, 
`FILTER_sFilterName` VARCHAR(40) DEFAULT '' NOT NULL, 
`FILTER_sSearchFor` LONGTEXT NULL, 
`sLocale` VARCHAR(11) DEFAULT '*' NOT NULL, 
`sLanguage` VARCHAR(11) DEFAULT '*' NOT NULL, 
`sTimeZoneKey` VARCHAR(255) DEFAULT '*' NOT NULL, 
`dtLastDailyTask` DATETIME DEFAULT '2000-01-01 01:00:00' NOT NULL, 
`dtLastScheduleMaint` DATETIME NULL, 
`dtLastActivity` DATETIME NULL, 
`FILTER_sTags` LONGTEXT NULL, 
`bfHelpTips` INT DEFAULT 0 NOT NULL, 
`cFailedLogons` INT DEFAULT 0 NOT NULL, 
`fRecurseBugChildren` SMALLINT DEFAULT 1 NOT NULL, 
`fPaletteExpanded` SMALLINT DEFAULT 0 NOT NULL, 
`fPaletteModified` SMALLINT DEFAULT 0 NOT NULL, 
PRIMARY KEY(`ixPerson`), 
INDEX `IX_PersonCompound`(`ixPerson`,`sFullName`,`sPhone`,`sEmail`,`fNotify`), 
INDEX `Person_sFullName`(`sFullName`), 
INDEX `PersonSuggested2`(`fDeleted`,`sFullName`), 
INDEX `PersonSuggested3`(`ixPerson`,`fAdministrator`,`sFullName`,`fDeleted`), 
INDEX `IX_IxPersonFDeletedFCommunity`(`ixPerson`,`fDeleted`,`fCommunity`), 
INDEX `IX_FCommunityFDeletedFVirtualIxPerson`(`fCommunity`,`fDeleted`,`fVirtual`,`ixPerson`,`fAdministrator`), 
INDEX `IX_FVirtualSEmailIxPersonFDeleted`(`fVirtual`,`sEmail`,`ixPerson`,`fDeleted`)) ENGINE = MyISAM;

CREATE TABLE `Plugin`
(`ixPlugin` INT NOT NULL AUTO_INCREMENT, 
`fDeleted` SMALLINT DEFAULT 0 NULL, 
`sPluginId` VARCHAR(255) NOT NULL, 
`ixSchemaVersion` INT DEFAULT 0 NOT NULL, 
`fEnabled` INT DEFAULT 0 NOT NULL, 
`sFilename` VARCHAR(255) DEFAULT '' NOT NULL, 
`rgbFile` LONGBLOB NULL, 
`dtUpload` DATETIME DEFAULT '2000-01-01 12:00:00' NOT NULL, 
`sVersionLatest` VARCHAR(64) NULL, 
`fBlacklisted` INT DEFAULT 0 NOT NULL, 
PRIMARY KEY(`ixPlugin`)) ENGINE = MyISAM;

CREATE TABLE `PluginKeyValue`
(`ixPluginKeyValue` INT NOT NULL AUTO_INCREMENT, 
`ixPlugin` INT DEFAULT 0 NOT NULL, 
`sKey` VARCHAR(128) DEFAULT '' NOT NULL, 
`sValue` LONGTEXT NULL, 
PRIMARY KEY(`ixPluginKeyValue`), 
INDEX `PluginKeyValueIxPluginSKey`(`ixPlugin`,`sKey`)) ENGINE = MyISAM;

CREATE TABLE `Prediction`
(`ixPrediction` INT NOT NULL AUTO_INCREMENT, 
`ixBug` INT NULL, 
`ixAreaA` INT NULL, 
`ixAreaB` INT NULL, 
`dProb` DOUBLE DEFAULT 0 NULL, 
`sCluesA` VARCHAR(255) DEFAULT '' NULL, 
`sCluesB` VARCHAR(255) DEFAULT '' NULL, 
`fWinner` SMALLINT NULL, 
PRIMARY KEY(`ixPrediction`), 
INDEX `IX_IxBug`(`ixBug`)) ENGINE = MyISAM;

CREATE TABLE `Priority`
(`ixPriority` INT NOT NULL AUTO_INCREMENT, 
`sPriority` VARCHAR(255) DEFAULT '' NULL, 
`fDefault` SMALLINT DEFAULT 0 NOT NULL, 
PRIMARY KEY(`ixPriority`)) ENGINE = MyISAM;

CREATE TABLE `Project`
(`ixProject` INT NOT NULL AUTO_INCREMENT, 
`sProject` VARCHAR(128) NULL, 
`ixPersonOwner` INT NULL, 
`fDeleted` INT DEFAULT 0 NOT NULL, 
`fAllowPublicSubmit` INT DEFAULT 0 NOT NULL, 
`ixGroup` INT DEFAULT 1 NULL, 
`fInbox` SMALLINT DEFAULT 0 NOT NULL, 
`ixWorkflow` INT DEFAULT 1 NOT NULL, 
PRIMARY KEY(`ixProject`), 
INDEX `ProjectIxGroup`(`ixGroup`)) ENGINE = MyISAM;

CREATE TABLE `ProjectPercentTime`
(`ixProjectPercentTime` INT NOT NULL AUTO_INCREMENT, 
`ixPerson` INT NOT NULL, 
`ixProject` INT NOT NULL, 
`nPercent` INT NOT NULL, 
PRIMARY KEY(`ixProjectPercentTime`), 
INDEX `ProjectPercentTimeixPerson`(`ixPerson`)) ENGINE = MyISAM;

CREATE TABLE `ProjectView`
(`ixProjectView` INT NOT NULL AUTO_INCREMENT, 
`ixPerson` INT NULL, 
`ixProject` INT NULL, 
`ixFixFor` INT NULL, 
`ixPriority` INT NULL, 
`nGraphType` INT NULL, 
PRIMARY KEY(`ixProjectView`), 
INDEX `ProjectViewixPerson`(`ixPerson`), 
INDEX `ProjectViewixProject`(`ixProject`)) ENGINE = MyISAM;

CREATE TABLE `Repository`
(`ixRepository` INT NOT NULL AUTO_INCREMENT, 
`sName` VARCHAR(255) DEFAULT '' NOT NULL, 
`nType` INT DEFAULT 0 NOT NULL, 
`sDiffURL` VARCHAR(255) DEFAULT '' NOT NULL, 
`sLogURL` VARCHAR(255) DEFAULT '' NOT NULL, 
`sRandomKey` VARCHAR(128) DEFAULT '' NOT NULL, 
`sRepo` VARCHAR(255) DEFAULT '' NOT NULL, 
`fDeleted` SMALLINT DEFAULT 0 NOT NULL, 
PRIMARY KEY(`ixRepository`), 
INDEX `RepositorySRepo`(`sRepo`)) ENGINE = MyISAM;

CREATE TABLE `Revision`
(`ixRevision` INT NOT NULL AUTO_INCREMENT, 
`ixWikiPage` INT DEFAULT 0 NULL, 
`ixTemplate` INT DEFAULT 0 NULL, 
`ixPerson` INT DEFAULT 0 NULL, 
`sRemoteIP` VARCHAR(128) DEFAULT '0.0.0.0' NULL, 
`nRevision` INT DEFAULT 0 NULL, 
`sTitle` VARCHAR(128) NULL, 
`sBody` LONGTEXT NULL, 
`sComment` VARCHAR(255) NULL, 
`fDiff` SMALLINT DEFAULT 0 NULL, 
`dt` DATETIME DEFAULT '2000-01-01 12:00:00' NOT NULL, 
`dblStrength` DOUBLE DEFAULT -1 NOT NULL, 
`ixTagEventLatest` INT DEFAULT -1 NOT NULL, 
PRIMARY KEY(`ixRevision`), 
INDEX `RevisionIxWikiPage`(`ixWikiPage`)) ENGINE = MyISAM;

CREATE TABLE `Scout`
(`ixScout` INT NOT NULL AUTO_INCREMENT, 
`Description` VARCHAR(255) DEFAULT '' NOT NULL, 
`ixBug` INT DEFAULT 0 NOT NULL, 
`sMessage` LONGTEXT DEFAULT '' NOT NULL, 
`fStopReporting` SMALLINT DEFAULT 0 NOT NULL, 
PRIMARY KEY(`ixScout`), 
INDEX `IX_IxBug`(`ixBug`)) ENGINE = MyISAM;

CREATE TABLE `SearchLog`
(`ixSearchLog` INT NOT NULL AUTO_INCREMENT, 
`ixPerson` INT DEFAULT -1 NOT NULL, 
`sSearchFor` VARCHAR(255) DEFAULT '' NOT NULL, 
`nLogType` INT DEFAULT 0 NOT NULL, 
PRIMARY KEY(`ixSearchLog`), 
INDEX `IX_Person`(`ixPerson`,`sSearchFor`)) ENGINE = MyISAM;

CREATE TABLE `Setting`
(`ixSetting` INT NOT NULL AUTO_INCREMENT, 
`sKey` VARCHAR(64) DEFAULT '' NOT NULL, 
`sValue` VARCHAR(255) DEFAULT '' NOT NULL, 
PRIMARY KEY(`ixSetting`), 
INDEX `IX_sKey`(`sKey`)) ENGINE = MyISAM;

CREATE TABLE `ShipDate`
(`ixShipDate` INT NOT NULL AUTO_INCREMENT, 
`ixFixFor` INT DEFAULT 0 NOT NULL, 
`ixPriority` INT DEFAULT 7 NOT NULL, 
`dtCalc` DATETIME NOT NULL, 
`dtLow` DATETIME NOT NULL, 
`dtMid` DATETIME NOT NULL, 
`dtHigh` DATETIME NOT NULL, 
`hrsLow` DOUBLE DEFAULT 0 NOT NULL, 
`hrsMid` DOUBLE DEFAULT 0 NOT NULL, 
`hrsHigh` DOUBLE DEFAULT 0 NOT NULL, 
`hrsLowThis` DOUBLE DEFAULT 0 NOT NULL, 
`hrsMidThis` DOUBLE DEFAULT 0 NOT NULL, 
`hrsHighThis` DOUBLE DEFAULT 0 NOT NULL, 
`dtOfficial` DATETIME NULL, 
`fCompleted` INT DEFAULT 0 NOT NULL, 
PRIMARY KEY(`ixShipDate`)) ENGINE = MyISAM;

CREATE TABLE `Snippet`
(`ixSnippet` INT NOT NULL AUTO_INCREMENT, 
`ixPerson` INT DEFAULT 0 NOT NULL, 
`fGlobal` SMALLINT DEFAULT 0 NOT NULL, 
`sName` VARCHAR(16) DEFAULT '' NOT NULL, 
`s` LONGTEXT DEFAULT '' NOT NULL, 
`sComment` VARCHAR(80) NULL, 
`fDeleted` SMALLINT DEFAULT 0 NOT NULL, 
PRIMARY KEY(`ixSnippet`)) ENGINE = MyISAM;

CREATE TABLE `SorterSetting`
(`ixSorterSetting` INT NOT NULL AUTO_INCREMENT, 
`sKey` VARCHAR(15) DEFAULT '' NOT NULL, 
`nValue` DOUBLE DEFAULT 0 NOT NULL, 
PRIMARY KEY(`ixSorterSetting`)) ENGINE = MyISAM;

CREATE TABLE `SorterToken`
(`ixToken` INT NOT NULL AUTO_INCREMENT, 
`nLatestDoc` INT NULL, 
`sToken` VARCHAR(40) NULL, 
PRIMARY KEY(`ixToken`), 
INDEX `IX_SToken`(`sToken`)) ENGINE = MyISAM;

CREATE TABLE `Status`
(`ixStatus` INT NOT NULL AUTO_INCREMENT, 
`sStatus` VARCHAR(50) NULL, 
`ixCategory` INT NULL, 
`fWorkDone` INT DEFAULT 0 NULL, 
`fResolved` SMALLINT DEFAULT 0 NOT NULL, 
`fDuplicate` SMALLINT DEFAULT 0 NULL, 
`fDeleted` SMALLINT DEFAULT 0 NULL, 
`iOrder` INT DEFAULT 0 NOT NULL, 
PRIMARY KEY(`ixStatus`)) ENGINE = MyISAM;

CREATE TABLE `Subscriptions`
(`ixSubscription` INT NOT NULL AUTO_INCREMENT, 
`ixPerson` INT DEFAULT 0 NOT NULL, 
`ixBug` INT DEFAULT 0 NOT NULL, 
`ixWikiPage` INT DEFAULT 0 NOT NULL, 
`ixDiscussTopic` INT DEFAULT 0 NOT NULL, 
PRIMARY KEY(`ixSubscription`), 
INDEX `SubscriptionsixBug`(`ixBug`), 
INDEX `SubscriptionsixWikiPage`(`ixWikiPage`), 
INDEX `SubscriptionsixDiscussTopic`(`ixDiscussTopic`), 
INDEX `SubscriptionsixPersonixBug`(`ixPerson`,`ixBug`), 
INDEX `SubscriptionsixPersonixWikiPage`(`ixPerson`,`ixWikiPage`), 
INDEX `SubscriptionsixPersonixDiscussTopic`(`ixPerson`,`ixDiscussTopic`)) ENGINE = MyISAM;

CREATE TABLE `Tag`
(`ixTag` INT NOT NULL AUTO_INCREMENT, 
`sTag` VARCHAR(255) DEFAULT '' NOT NULL, 
PRIMARY KEY(`ixTag`), 
INDEX `TagsTag`(`sTag`)) ENGINE = MyISAM;

CREATE TABLE `TagAssociation`
(`ixTagAssociation` INT NOT NULL AUTO_INCREMENT, 
`ixTag` INT DEFAULT 0 NOT NULL, 
`ixBug` INT DEFAULT -1 NOT NULL, 
`ixWikiPage` INT DEFAULT -1 NOT NULL, 
PRIMARY KEY(`ixTagAssociation`), 
INDEX `TagAssociationCompound`(`ixTag`,`ixBug`,`ixWikiPage`), 
INDEX `TagAssociationIxBug`(`ixBug`), 
INDEX `TagAssociationIxWikiPage`(`ixWikiPage`)) ENGINE = MyISAM;

CREATE TABLE `TagEvent`
(`ixTagEvent` INT NOT NULL AUTO_INCREMENT, 
`ixTag` INT DEFAULT 0 NOT NULL, 
`fAdded` SMALLINT DEFAULT 0 NOT NULL, 
`ixBugEvent` INT DEFAULT -1 NOT NULL, 
`ixRevision` INT DEFAULT -1 NOT NULL, 
`sTags` LONGTEXT NULL, 
PRIMARY KEY(`ixTagEvent`), 
INDEX `TagEventIxBugEvent`(`ixBugEvent`), 
INDEX `TagEventIxRevision`(`ixRevision`)) ENGINE = MyISAM;

CREATE TABLE `Template`
(`ixTemplate` INT NOT NULL AUTO_INCREMENT, 
`ixRevision` INT DEFAULT 0 NOT NULL, 
`sTemplate` VARCHAR(128) NULL, 
`sBody` LONGTEXT NULL, 
`fDeleted` SMALLINT DEFAULT 0 NULL, 
PRIMARY KEY(`ixTemplate`)) ENGINE = MyISAM;

CREATE TABLE `TimeInterval`
(`ixInterval` INT NOT NULL AUTO_INCREMENT, 
`ixPerson` INT NOT NULL, 
`ixBug` INT NOT NULL, 
`dtStart` DATETIME NOT NULL, 
`dtEnd` DATETIME NULL, 
`fDeleted` SMALLINT DEFAULT 0 NOT NULL, 
PRIMARY KEY(`ixInterval`), 
INDEX `TimeInterval_ixBug`(`ixBug`), 
INDEX `IX_IxPersonCompound`(`ixPerson`,`ixBug`,`dtStart`), 
INDEX `IX_DtEndFDeleted`(`dtEnd`,`fDeleted`)) ENGINE = MyISAM;

CREATE TABLE `TitleWord`
(`ixTitleWord` INT NOT NULL AUTO_INCREMENT, 
`ixBug` INT DEFAULT 0 NOT NULL, 
`ixWord` INT DEFAULT 0 NOT NULL, 
PRIMARY KEY(`ixTitleWord`), 
INDEX `IX_IxWordIxTitleWordIxBug`(`ixWord`,`ixTitleWord`,`ixBug`), 
INDEX `TitleWordixBug`(`ixBug`)) ENGINE = MyISAM;

CREATE TABLE `TitleWordWord`
(`ixWord` INT NOT NULL AUTO_INCREMENT, 
`sWord` VARCHAR(30) DEFAULT '' NOT NULL, 
PRIMARY KEY(`ixWord`), 
INDEX `TitleWordWordsWord`(`sWord`)) ENGINE = MyISAM;

CREATE TABLE `TokenAssociation`
(`ixTokenAssociation` INT NOT NULL AUTO_INCREMENT, 
`ixToken` INT NULL, 
`ixProject` SMALLINT NULL, 
`ixArea` SMALLINT NULL, 
`cGood` INT NULL, 
`cBad` INT NULL, 
PRIMARY KEY(`ixTokenAssociation`), 
INDEX `IX_TokenAssociation`(`ixToken`,`ixArea`,`ixProject`)) ENGINE = MyISAM;

CREATE TABLE `Tokens`
(`ixToken` INT NOT NULL AUTO_INCREMENT, 
`fbToken` VARCHAR(30) NOT NULL, 
`sIPAddress` VARCHAR(50) NOT NULL, 
`ixPerson` INT DEFAULT 0 NOT NULL, 
`ixPlugin` INT DEFAULT 0 NOT NULL, 
PRIMARY KEY(`ixToken`), 
INDEX `IX_FBToken`(`fbToken`), 
INDEX `IX_IxPersonFbToken`(`ixPerson`,`fbToken`)) ENGINE = MyISAM;

CREATE TABLE `TrainingRequest`
(`ixRequest` INT NOT NULL AUTO_INCREMENT, 
`ixBug` INT NULL, 
`ixDiscussTopic` INT NULL, 
`ixAreaFrom` INT NULL, 
`ixAreaTo` INT NULL, 
PRIMARY KEY(`ixRequest`), 
INDEX `IX_TrainingRequest`(`ixRequest`)) ENGINE = MyISAM;

CREATE TABLE `Version`
(`ixVersion` INT NULL) ENGINE = MyISAM;

CREATE TABLE `Wiki`
(`ixWiki` INT NOT NULL AUTO_INCREMENT, 
`sWiki` VARCHAR(128) NULL, 
`sTagLineHTML` LONGTEXT NULL, 
`ixWikiPageRoot` INT DEFAULT 0 NOT NULL, 
`ixTemplate` INT DEFAULT 1 NOT NULL, 
`ixDictionary` INT DEFAULT 0 NOT NULL, 
`fDeleted` SMALLINT DEFAULT 0 NULL, 
`ixGroup` INT DEFAULT 0 NULL, 
PRIMARY KEY(`ixWiki`), 
INDEX `IX_fDeleted`(`fDeleted`)) ENGINE = MyISAM;

CREATE TABLE `WikiExternalLink`
(`ixWikiExternalLink` INT NOT NULL AUTO_INCREMENT, 
`ixWikiPage` INT DEFAULT 0 NOT NULL, 
`sHref` LONGTEXT NOT NULL, 
`fToWikiPage` SMALLINT DEFAULT 0 NOT NULL, 
PRIMARY KEY(`ixWikiExternalLink`)) ENGINE = MyISAM;

CREATE TABLE `WikiLink`
(`ixWikiLink` INT NOT NULL AUTO_INCREMENT, 
`ixWikiPageFrom` INT DEFAULT 0 NULL, 
`ixWikiPageTo` INT DEFAULT 0 NULL, 
PRIMARY KEY(`ixWikiLink`), 
INDEX `WikiLinkIxWikiPageFrom`(`ixWikiPageFrom`), 
INDEX `WikiLinkIxWikiPageTo`(`ixWikiPageTo`)) ENGINE = MyISAM;

CREATE TABLE `WikiPage`
(`ixWikiPage` INT NOT NULL AUTO_INCREMENT, 
`ixRevision` INT DEFAULT 0 NOT NULL, 
`ixWiki` INT DEFAULT 0 NOT NULL, 
`sHeadline` VARCHAR(128) NULL, 
`sBody` LONGTEXT NULL, 
PRIMARY KEY(`ixWikiPage`), 
INDEX `WikiPageSHeadline`(`sHeadline`), 
INDEX `WikiPageIxWiki`(`ixWiki`), 
INDEX `WikiPageSuggested1`(`ixWikiPage`,`ixRevision`,`ixWiki`,`sHeadline`)) ENGINE = MyISAM;

CREATE TABLE `WikiPageView`
(`ixWikiPageView` INT NOT NULL AUTO_INCREMENT, 
`ixPerson` INT DEFAULT 0 NOT NULL, 
`ixWikiPage` INT DEFAULT 0 NOT NULL, 
`ixRevision` INT DEFAULT 0 NOT NULL, 
`dt` DATETIME NULL, 
PRIMARY KEY(`ixWikiPageView`), 
INDEX `WikiPageViewIxWikiPage`(`ixWikiPage`), 
INDEX `IX_FullTextSearch`(`ixPerson`,`ixWikiPage`,`ixWikiPageView`,`ixRevision`,`dt`), 
INDEX `WikiPageViewPersonDtReverse`(`ixPerson`,`dt`)) ENGINE = MyISAM;

CREATE TABLE `Word`
(`ixWord` INT NOT NULL AUTO_INCREMENT, 
`sWord` VARCHAR(255) NOT NULL, 
`ixDictionary` INT DEFAULT 0 NOT NULL, 
`ixPerson` INT NULL, 
`sMetaphonePrimary` VARCHAR(255) NULL, 
`sMetaphoneSecondary` VARCHAR(255) NULL, 
PRIMARY KEY(`ixWord`), 
INDEX `WordIxDictionary`(`ixDictionary`), 
INDEX `WordSMetaphonePrimary`(`sMetaphonePrimary`), 
INDEX `WordSMetaphoneSecondary`(`sMetaphoneSecondary`), 
INDEX `WordIxPerson`(`ixPerson`), 
INDEX `WordCompound1`(`sWord`,`ixPerson`,`ixDictionary`,`ixWord`)) ENGINE = MyISAM;

CREATE TABLE `Workflow`
(`ixWorkflow` INT NOT NULL AUTO_INCREMENT, 
`sWorkflow` VARCHAR(255) DEFAULT '' NOT NULL, 
`fDeleted` SMALLINT DEFAULT 0 NULL, 
PRIMARY KEY(`ixWorkflow`)) ENGINE = MyISAM;

CREATE TABLE `WorkflowRule`
(`ixWorkflowRule` INT NOT NULL AUTO_INCREMENT, 
`ixWorkflow` INT DEFAULT 0 NOT NULL, 
`ixStatus` INT DEFAULT 0 NOT NULL, 
`nAction` INT DEFAULT 0 NOT NULL, 
`nAssignTo` INT DEFAULT 0 NOT NULL, 
`ixPersonAssignTo` INT DEFAULT 0 NOT NULL, 
`fForceAssignTo` SMALLINT DEFAULT 0 NOT NULL, 
PRIMARY KEY(`ixWorkflowRule`), 
INDEX `WorkflowRuleCompound`(`ixWorkflow`,`ixStatus`,`nAction`)) ENGINE = MyISAM;

CREATE TABLE `WorkingSchedule`
(`ixWorkingSchedule` INT NOT NULL AUTO_INCREMENT, 
`ixPerson` INT DEFAULT 0 NULL, 
`fSunday` INT DEFAULT 0 NULL, 
`fMonday` INT DEFAULT 1 NULL, 
`fTuesday` INT DEFAULT 1 NULL, 
`fWednesday` INT DEFAULT 1 NULL, 
`fThursday` INT DEFAULT 1 NULL, 
`fFriday` INT DEFAULT 1 NULL, 
`fSaturday` INT DEFAULT 0 NULL, 
`nWorkdayStarts` DOUBLE DEFAULT 9 NULL, 
`nWorkdayEnds` DOUBLE DEFAULT 17 NULL, 
`fHasLunch` INT DEFAULT 1 NULL, 
`nLunchStarts` DOUBLE DEFAULT 12 NULL, 
`hrsLunchLength` DOUBLE DEFAULT 0.5 NULL, 
`dtLastUpdated` DATETIME NULL, 
`fAutoClock` INT DEFAULT 1 NULL, 
`nPercentTimeAllOtherProjects` INT DEFAULT 100 NOT NULL, 
PRIMARY KEY(`ixWorkingSchedule`), 
INDEX `WorkingScheduleixPerson`(`ixPerson`)) ENGINE = MyISAM;

SELECT 'Importing Table ACL';
INSERT INTO `ACL` (`ixACL`, `sSectionName`, `ixSection`, `ixPerson`, `iPermission`) VALUES (1, 'Group', 1, -1, 2);
SELECT 'Imported Table ACL';
SELECT 'Importing Table Area';
INSERT INTO `Area` (`ixArea`, `ixProject`, `ixPersonOwner`, `sArea`, `fDeleted`, `nType`, `cDoc`) VALUES (1, 1, -1, 'Code', 0, 0, 0);
INSERT INTO `Area` (`ixArea`, `ixProject`, `ixPersonOwner`, `sArea`, `fDeleted`, `nType`, `cDoc`) VALUES (2, 1, -1, 'User Interface', 0, 0, 0);
INSERT INTO `Area` (`ixArea`, `ixProject`, `ixPersonOwner`, `sArea`, `fDeleted`, `nType`, `cDoc`) VALUES (3, 1, -1, 'Documentation', 0, 0, 0);
INSERT INTO `Area` (`ixArea`, `ixProject`, `ixPersonOwner`, `sArea`, `fDeleted`, `nType`, `cDoc`) VALUES (4, 1, -1, 'Miscellaneous', 0, 0, 0);
INSERT INTO `Area` (`ixArea`, `ixProject`, `ixPersonOwner`, `sArea`, `fDeleted`, `nType`, `cDoc`) VALUES (5, 2, -1, 'Not Spam', 0, 1, 0);
INSERT INTO `Area` (`ixArea`, `ixProject`, `ixPersonOwner`, `sArea`, `fDeleted`, `nType`, `cDoc`) VALUES (6, 2, -1, 'Spam', 0, 3, 0);
INSERT INTO `Area` (`ixArea`, `ixProject`, `ixPersonOwner`, `sArea`, `fDeleted`, `nType`, `cDoc`) VALUES (7, 2, -1, 'Undecided', 0, 2, 0);
SELECT 'Imported Table Area';
SELECT 'Importing Table Attachment';
INSERT INTO `Attachment` (`ixAttachment`, `sData`, `sFilename`, `fFileStatus`, `ixBugEvent`, `ixWiki`, `ixTemplate`) VALUES (1, 0x89504e470d0a1a0a0000000d49484452000001670000003b080200000028e1dce2000001d3694343504943432050726f66696c650000780185924d4b1b511486df891585da921631829b0b295ac1ca103f53ba484c422dcc224824b575d1c9648c81240e93d12a6e5cf9035c088260a1d05597a56e5cb8e8d276d3e2d7d2bf60716365fadeb98480103d97e13cf7f09e73ee9c7b81b657a6e3544200aa35cf9d793d25decebd131d67d0104617a2e837adba93cc660d4a5ad8d531d5b4df2f64ad16a256e1472e1b029aa0a0bba478547241f1b4e48f9ee351332fd95a348b64873ce4e66652e45df2e392e2af920b8a0f24af5825997b44d66bc5728dfc8f3c59b4eb161092bdf62cc7a526f4879ca8569758bfad9bfc5cce829ee64481f832e39f9ab10fabc0b74da077ab19eb7f093ced03beff6dc62e4f83f9683d9df5859158504e7bb80fb46ffbfe651ee818046e4e7cff7adff76fbeb0c7397078652dbb2b819607d67e02f7edd57faaea80ffac41ad58cd2250e9c0e74320b70118f43bf40311e0c93a904d309e80f6eb7de3537383b4483a63182213d3f5785ea4cc4ab9e09a9ecde9298b208d0c0c2e411f83ce15479ebb144c545046012ec9838d20e99e7a8dba777bcf5ee55d02a92567cd2d97163d91e4abb4c59b9a353c24e459efce57f72f3561bea5447a626c7cf6c7c5e083db59ff01438c886cba2a40bc000000097048597300000b1300000b1301009a9c18000014f9494441547801ed9d075c55c7d2c045050562a5d80b06c5a8449ff9ecd8bb06a3b1f7f87c9f893126d6186330f1b397d88dddd84b9267ef8a3d8a5162140b8a05c5dedba5a8c0fb5f37df7abc5cae80f7ddc69e1fbfcb9c39bbb3b3b367676766cf99e39498f830833a522d811ca9aea12a2809388a04323a4a47543f940494042c2401a5352c2468d58c9280c34840690d87194ad51125010b4940690d0b095a35a324e03012505ac3618652754449c04212505ac3428256cd2809388c0494d67098a1541d5112b0900494d6b090a055334a020e2301a5351c6628554794042c2401a5352c2468d58c9280c34840690d87194ad51125010b4920b385da51cd985502ddbb77cf962d5bc68c7aa5efe4e46456daa92096989848e9848484274f9ecc9f3f3f15359329eaa8fd4aa6bbf68a565ac32e47ee1f2f0f171717b8b7bad678f6ecd9b163c7cc224747ed975984631622ebd6af4b039d03bf1ff0f7f7efd2a98ba8abb4461a6468fd2a050a1478efbdf75c5d5dadcf4a860c313131b76fdf360b278eda2fb308c72c44743a5df8d90ccf9e1b21e6e29ca1a49f113ca87bf7ee614eca6bd6d11a9327ff54b26489468dea493e00860d1bd3b061ddca952b689126e0e0e03de7cf5ffaf4d36e26ca70e9e1c3873973e6345d467b75ca9499152a94af5ab59216696bb0b3b373d6ac596d446be0a7c08f5944e4a8fd328b70cc4504ada1d31921e6ee9eacd630286d9d68e8ac590b76eedc63c0cad8b1938f1cf9d30069e274dfbe838b162d3751804b3d7bf69d366d8ee9320657e1edf0e1a3064875aa24e030127073cdeceeeeece6e6ecea9a09e0259cc9cd2db3bb1b4adb3953a64cfa7f2f0f091b78c1d6b1352c3600478f1e6bd62c9fc59ab3584306a368b176936bc85cfc988b4e727ca6166f6bfca4967fa3e5674c6beaeeee1ead8b8eba1ce5574aef935cbe74d9cdddcdcbdb8bc076447844b1e2c5501ada02a17f866a49d9a2d6983a75968f4f91f0f073d823a54bbfd7ad5b477fffd282e9f3e72fce9bb7f8d8b1e3356a547bfefc9573061ecf223c3cc2d5352b3e4ebf7ebd30e0c78f9f12197965cd9a8dd40d0afa9adf9f7f5eba61c3d6d8d8d8dab5abf7e9f339a21164b76cd9b172e5bf1f3f7ed2bd7b6781e117c367e6ccf9e3c6fd9fa7a787442a40494049c016b506cae2e0c1c3c58bbfdbbbf7a7ab56adae53273034746fe1c285eeddbb5fbf7ef3fcf9f376edda61c99295a1a17f952be7cf105ebc1859b66cb5d6ad9b33e74f9c3889a773f7eebd891347952953ea9d77de2952a49028d6bbf740a81107c99123fbe4c93377efdebf79f36f54dfbc79fbc71f77eadcb95d4040e59e3dfbddb97357dc1610f9fdf71054cc1bef92fdfbf76fdbb6cda058b972e55ab56a65804c27a74141416253d6a0bf6ddab479fffdf70d90ead4c212b81a75356b96ac4faf465df8f7af516efa803a3779a68c999c0987262646c7c45ec99ad529a353427c426c5c9c28f0e0d2c542850a493e6d516bc0dcf3e72ff6efdf9a3973e60e1d5afbf97d3062c4843973a61043cd96ed9d0307b66137f6e8f1494040430c2a0a47445ca0d8ecd993797ea15dbb9677eedc0b093902be71e3fa9e9eb9cb972f1b18d8f8dcb9f33ffd346fe9d2b9eddbeb6772ab561ff9f894259e5ab76ead7efdbefdf6dbfe43870e028feaf1f5fd070007d5f913b0e9df43870e8d1d3bb64e9d3ada623972a4dfdca2478f1efdffa189b879f366f5ead58564ead5aba7159182ad220182e81c71191263ae5ef169a99f0e1783835df3787b97f18f7ff6ecec86f5051a35767177d7ddbef560ff7e51c0e5f53d32eb680dd4417c7cbc81c8c08017c87af56a49b841833a420b1c3b76a256ad00e96ab2e182674179809a35ab0507ef3d7d3afccc99b3dbb60527f529087024242412e6848868227bf66c582bb833281d1c1681c4a2617347c0a9fae599aba4e646aa283852e12d5bb688ee0c193264c58a154a323635b81e9e1ec435126fdfcce8ececdfbe23bcdd0a0b4365003fd7e922b66e29d9acb9bbb7f7ed9361512121a2807b5898b60bd6d11a842dae5dbba1e5e3f1e3c7cf9e3d2f5cb8a0404a80d35cb972ea74d1008f1e3d7ef1e285ac25a312c78f87356cf831818cead5ab54ab56393636eec48953b298001e3e7ce4ec9cd9cdcd552a9d2fbef85fc2254f9e3c459b68c94a6d6540216da793264df2f3f363dab0e4fef0c30fc58b179f3d7bf6d6ad5b5191356bd6ecdbb7af78526bead4a9254a94b878f1e2a64d9bf2e7cffff5d75fd3bb3163c6dcba750babbe5dbb7692edb4b16123b590b3d1eedb087be9848de7d1d144045fc4c4d05fd404bf8958868409753a71aa2fa0d31914d00ac73a5ac3cfaff8a64ddbb887e4140d09d16f7612cb10cceddab54f724998032f83537e376e7c153e907bb7c3868dc540080e5ecf4611c5084608f318584e365fdf62783d4d9a340808a8029e0244464b94f0cd9b374fbe7c79b66fdf55bb760df0844ed0419d3bb7054eeda18dced2aee8da8e1d3b264e9cf8eebbefe6ce9d1b7ba45bb76e1b376efcecb3cf80274f9ebc79f3e63d7bf65078e7ce9de3c68d2b5fbe7cd3a64de7cc99131818880dd9a449133448e7ce9d8b162d5aa58a9e6d7b3f92ebbebdf7cbbef8df3e68a0534c74627cfc8bb8b8b5ffd23feef42236f6fef973e7b66c26aef13c26465f20a393b6c0ddd8d8c2458abcea26df43b1fc5f68e81e7777b7b66d5becdfbf2532f2c4ba75cb7d7d7d02031bc5c7df8719005ead98376f6a74f48d050ba667c9e2b27dfb1af021213b5d5c9c274d1aa5d35d5fb5ea67f055aa5400fff9e7ddfdfd4b3d79723521e101a4c0fbf9f98a4e356c58a75dbb8faf5d3bf3ecd99d92258be38984851d8c89b9191434d0c323d7ad5b11141b3cb82fa6cdae5debefdf8f8414a299387124f83367fe183dfafb870f2f0b52afff12ec7b7510d47825d09750b162c5c4e5c68d1b6344a01f39fde38f3fb8b86edd3a71e9cf3ff50fa7fcf2cb2f9ca2263049d03bc014003f7efc78518c70c9a04183042c7f513d3ce4274fad0bc009fc18e58188918f8f8fb864a2fbb2aebdf44b326c77c0b2e5cb6e47463ebd752b72dfde5fdab602e06fdb807ea17367033cb87409e4ed53a780ef5c8a3c71e09028307040bfe93f4d979db5ce535ee5cb975bb366d9850b97d81f295af47d762eaa54a9b862c57cf13a1673a666cd80316326e5cc5978c890e1d3a78faf5fbf36c84a95fe67e1c2991327cec895ab48fffe43ba74690f92a36fdf5e3973e6f0f6f6f5f4f4993265d6840923d870e591502eb56811b87af5868a15eb60f0af5dbb9c58b1bf7f550f0f9f1d3b762f5e3cdbdbdb8b322346041119090c6c97376ff12b57ae56a8f07734143767f0e061f7ef3fd0b7f1a603db8198a83c7efb4dbf3b238e0f3ef8401841bcac91254b96ba75eb0a3cef5cf00035814371cae682304f304cc0a06e04decbcb0bef46c076fd6bbafb76dd35fb62decdd393b0856bae5c98e200fc11e0e0612f3dece505521470f3f272c9954b16d0f6d13a1e0a1ca008f88b8b8b63a7b360c1025a9e80b10b76efde78eddaf5fcf9f3492f033c3b20fc19e0f13ef6eddb82738125c2eca5d8175ff41004d967e5710f11b6c02d3a7870c7a3478f5ebc88f7f0c82d0af08baa628366ead4b1c438bcbc3c25be4d9b16fcc953d30013be72e5ca46cbe09b083c8a8c8d1537373759ccdbdb5b3a531e1eaf3d15223a224b3a0060bafb0ed0417be9c2ddb3e13a17173653096710f2846da2183a5e253a19462c03644c748c932e3a3646ffcc01cf7af12bef52d147ab690dd13c6b6f5295212ef15ba0407e096b01a378ad22d01626dc28228e0299dc8628c1540e6d45b3c38442191a965ce2171027d2f9d75f7ff5efdfdfec0dd926c174de7ddb1994c3d3a711d72084419a83bd2387c3584262e2935b37a3420e0183bc71fd864b74acf047787e14645c6c9c967f2b6b0d2d2b12664f94a7b3e4a9c300381dc435bffffefb1f7ffc118b835d494f4fcf5ab56a394c074d77249d77dfb4702c79b5e9b419a97da2dcf5e5c36092495bd41a3c8b25f97324005b66fdfaf59f7cf2092fb9e348962e5d9aad13421b8ed447137d49e7dd372119bbbbe4c4d680dd316d030cbfd5739ff7efdf2758938b70545a0f1eeba85dbbb6364492564a66a8171d1dbd7bf76ef68c5348cb44f7edba5f29ecbe758bfdf35ffff4f4f0cc9829230f8c13551446847ca21caf847006fa5d3c512e0b5cbc74b1668d9abd7af612ccdba2ad615db15aa075191fb5405b36d8443aefbe754764c1bc056fcf8075765edf9e6f4541494049c05a12505ac35a9257ed2a09d8ab0494d6b0d791537c2b09584b024a6b584bf2aa5d25017b9580d21af63a728a6f25016b4940eda1584bf26fd5ae786e4f3ce7ab7de2fead88a6bef2cbc70bf50f190a20f5040c6b08528ed72fc37edaf9b9d21a7639806ca4938c83e7f1e1deea5a036638cc2247e83864bfcc221cdb21a29ef24adb58bcd5535e696b52d55212b01109a8b8868d0c84624349c06e24a0b486dd0c95625449c04624a0b4861906825c5be4d4d512220157444484169342f8ce9d3b274ee8f321935f73c68c1906b5e6ce9d3b7dfa7403644a4e4d546cdfbefda95386695653429332842d7bf4e841b6aee5cbdff011bc141214c55ab66c999cf4c8b7ca3b2fa2d8db702ef921ff8a48aa263112d0b625910a40022a1a6a86db805947c62d2da183070f92e8448b4921dcbb776fde9d27afd7e5cb97f956bb412d9125d0009992531315434343b51ffe4d093559864464bffefaebe1c3870b16fc3b4db4bcf436c09123479e3e7d6a9402e91151a6bcb9c75504f5366f000afaa4381169df9236a76d2be9d5f48c515ae3bf3bfa67cf9e252339e90c1a366c28bf4343629e7dfbf691c8ab458b16da5440e1e1e1280be68cfc8008b988b9adc912261285f1996b16403826a5fbead5abb9dd2b56ac58b56a556d1f8e1f3fcede0a3b1190a2513298725556043e79f224adf39e7e404080484d28aa9f3f7f9eb660092426cf860d1bd8d110493128c03bfefefefe7cb2a051a3468226df195fbb762df316bd23b216debd7b77cd9a35e44611fde2dd5696715eccc57068ddbab57c43d78054d2b6043ffcf2362d9944af5cb952b870e1e6cd9b93930dcec966041b304692017a4a3e6732b31679990bf7c18307488cd63182e01f21907eb1460d7d1e698323848f651c39a24d6e62ba2daa271d35a3836bd090439e2a0fe5bf38accc4f56456e656eafb265cb72f7d31829c83ffae823927acd9f3f9fcce3bca42c39400bb0c6328b986f20972e5d3a6ddab4a8a8286608af908359b56ad592254b00b8ddf7eedd4b5d3298435052106598d8a222ba0643405b119a7ccae8ead5aba444efd0a183ac88c2c2ab228f212a83494eb631e627fca39548864ab1afbefa8a4fc9a101418a5ab47ee3c60d34cb850b1778ce8254ecf41178d6ac59cc553ac2a4259948af5ebd70dfc42318a2a29694d1b6247d52abd2716caed1a347f38507b4062a83e98d4c28d3af5f3faaa326b82aaa2c5ebc1811c10ce9dde920f2ecd2a5cbd0a143c555f90bab6ddbb6251b2b3e0e4c82a72fa6db4a3a6a46075736e1e0c0eba9b7ad90afdc3e19108f23fdfd4b6a0999525ca05803599a162d5a845ec02e00c9d287d6e0eecc9e3dfbae5dbb443174cacc9933ffa6f2f21f734360060f1ecc0753c425dc962fbffc129894df7c42850949521fee5a300441f85ea428267ea958aa5429018b2fc2018b8a009806cc7c0038e1030b64512531dfc2850b894d303f45ad4e9d3af5ecd953c030833601260b1921158194bfacf3e8174ee92369160f1c38202e81a4691673260f93539617809694d1b630ca3052504023468c1055d07dbc5f0f8c4324f8018673341a8a834b282f30b44beff02cf2e5cb87ae018396612cb43c501256e18dab683d380c0e0e36dd96d1514b3ab8104c2787f250ccb02a607b73634942acabac8a7cd0a459b3669806843c300d500738ff2ce94cb06fbef9463c9a851e11b14f59570bc84fa2fafafa0a93415cc5dff9eebbef2a54a8805f80dd8e42d1d602c6311118f2a1b3e4caab2cd1681c61b13397d008e2529f3e7de0a74c9932e2143f85ee089f88f24c3c81c79490a40c008c298420aa7009e3282c2c8ce99d97efcde4c963509853492ab9b628831f54a952254c157c2e8c23ede766b404110ede165f96c14fc182ab5fbf3eba06d520bd3c0a9f397346b2c1103034e817f0b087867d635bd82349476dd4a8510683abe5cab161a535cc30be2c7a041124215630d61c565466264bdff5ebd7f1f649178aabc2ee002ec082050b44661af40b2a40563400b449920d2e917374c08001b8f7cc7c167cbc746d011a12a74c366d9896480a1306bb9d5f0ab050938b10009f82b5bd7bf7ee90e294504bd7ae5d3b76ec080c87f27313da100c97b407bd40bf708864ce7499094981e4aa487c726d5117d1b1c181d61b3870203c6bb580b669608ab18983fac01f815b7a87065cb972a5284617c8cf2aab207902d5048005ab22126cba2d08261d35424506839b7e1247abb886bc9dd20ee04a60390bfb9c658d8d58d67354066e36ab2e2606e6006b20010ba27adcdc043259fab8ed0831504bdb302b36734f8b490a43070b5ce820ee544e0dcaf081480c044c74e612edcaabb084c34f68034c6464245143a11108250e1b360cc5c7762f971a3468008770422b7c7112cb4852480ea053b8156843d4250614eaccc424d71231d1d6e9d3a7cb952b273e3dc7aa2e6c0da3f221d48a9b869a208c0271a48a421452a29b8466b49620c3818d867f414936714588c4745b46472de9e06afbe5d8b0b235cc30bedcfac3870f27b8c8b602a63e7b137c510dba60f0b19951ac54acf923478e6496121a044f2894d02361d10f3ffc50cb010a889802773c55b4782d0ca9a0a0204ab25b41494869af02338189ed411f4740eba1700915c01c433bb0c8f3c948822ca22ea73cd3814b4524952008fb29106182a138962d5b66403fe9297116fa8579c2076b59c9717920253f1095b4bcc498680b7d4168938e602ca0e068027d84d78622c0b8239c21892007b43318f020a942d71805663b02c71c33f89c05a61f04a74c998289c4c61055ded856d251c30935185cc98fc303ea3d94b40db1f1f750d87ac48260ba6a89b2e613f607af455292c0a451d5804f0ede8088b6ae8471e3713ae4a9009887b4c897a599bd06b3459644d7683d1789d702f0cc2e6f6a3fe6044bb803c284d152330d9b680b454c2fb4d2c09c898989c1e8304d135d435d13dde4aac197abded856d251333ab8a6197380ab4a6ba46d108d6b8db4d1326f2da135264c98605eb28a9a928094c06baba2c42ac07e2580cbc3326bbffc2bce6d5f02cad648db18d9aead91b6fea85a4a02299780da4349b9ac544925012501bd0494d650f78192809240ea24a0b446eae4a54a2b09280928ada1ee0125012581d449e03fba43710e95dcafda0000000049454e44ae426082, 'relativePicker.png', 0, 3, -1, -1);
SELECT 'Imported Table Attachment';
SELECT 'Importing Table AutoResponseRecord';
SELECT 'Imported Table AutoResponseRecord';
SELECT 'Importing Table Bug';
INSERT INTO `Bug` (`ixBug`, `fOpen`, `dtOpened`, `sTitle`, `sOriginalTitle`, `ixBugEventLatestText`, `sLatestTextSummary`, `ixProject`, `ixArea`, `ixPersonOpenedBy`, `ixPersonAssignedTo`, `ixPersonResolvedBy`, `ixPersonClosedBy`, `ixPersonLastEditedBy`, `ixPersonEstimator`, `ixStatus`, `ixPriority`, `ixFixFor`, `sVersion`, `sComputer`, `hrsOrigEst`, `hrsCurrEst`, `hrsElapsed`, `hrsElapsedExtra`, `c`, `sCustomerEmail`, `ixCategory`, `dtResolved`, `dtClosed`, `ixMailbox`, `ixBugEventLatest`, `fTrained`, `fReplied`, `fForwarded`, `fEstLocked`, `ixOriginalPrediction`, `nStatType`, `sTicket`, `sReleaseNotes`, `ixDiscussTopic`, `dtDue`, `ixTagEventLatest`, `ixBugEmail`, `ixBugParent`, `ixBugRoot`, `iSetLeft`, `iSetRight`) VALUES (1, 1, '2009-12-18T09:19:33', '\"Welcome to FogBugz\" Sample Case', '', 3, 'Adding attachments to test export and import.', 2, 5, 2, 2, 0, 0, 2, 0, 1, 1, 1, '', '', 0.0, 0.0, 0.0, 0.0, 0, '', 1, NULL, NULL, 0, 3, 0, 0, 0, 0, 0, 0, '', '', 0, NULL, -1, 0, 0, 0, 0, 1);
SELECT 'Imported Table Bug';
SELECT 'Importing Table BugEmail';
SELECT 'Imported Table BugEmail';
SELECT 'Importing Table BugEvent';
INSERT INTO `BugEvent` (`ixBugEvent`, `ixBug`, `sVerb`, `dt`, `ixPerson`, `s`, `fEmail`, `fExternal`, `sChanges`, `sHTML`, `fHTML`, `ixPersonAssignedTo`, `sStatus`) VALUES (1, 1, 'Opened', '2009-12-18T09:19:33', 2, 'Welcome to FogBugz!', NULL, NULL, '', NULL, 0, 0, '');
INSERT INTO `BugEvent` (`ixBugEvent`, `ixBug`, `sVerb`, `dt`, `ixPerson`, `s`, `fEmail`, `fExternal`, `sChanges`, `sHTML`, `fHTML`, `ixPersonAssignedTo`, `sStatus`) VALUES (2, 1, 'Assigned to Administrator', '2009-12-18T09:19:33', 2, '', NULL, NULL, '', NULL, 0, 0, '');
INSERT INTO `BugEvent` (`ixBugEvent`, `ixBug`, `sVerb`, `dt`, `ixPerson`, `s`, `fEmail`, `fExternal`, `sChanges`, `sHTML`, `fHTML`, `ixPersonAssignedTo`, `sStatus`) VALUES (3, 1, 'Edited', '2009-12-18T09:41:08', 2, 'Adding attachments to test export and import.', 0, 0, '', '', 0, 0, '');
SELECT 'Imported Table BugEvent';
SELECT 'Importing Table BugRelation';
SELECT 'Imported Table BugRelation';
SELECT 'Importing Table BugView';
INSERT INTO `BugView` (`ixBugView`, `ixPerson`, `ixBug`, `ixBugEvent`, `dt`) VALUES (1, 2, 1, 3, '2009-12-18T09:41:10');
SELECT 'Imported Table BugView';
SELECT 'Importing Table BugViewPinnedField';
INSERT INTO `BugViewPinnedField` (`ixBugViewPinnedField`, `ixPerson`, `ixPlugin`, `sField`) VALUES (2, 2, -1, 'estimate');
INSERT INTO `BugViewPinnedField` (`ixBugViewPinnedField`, `ixPerson`, `ixPlugin`, `sField`) VALUES (1, 2, -1, 'priority');
INSERT INTO `BugViewPinnedField` (`ixBugViewPinnedField`, `ixPerson`, `ixPlugin`, `sField`) VALUES (3, 2, -1, 'tags');
SELECT 'Imported Table BugViewPinnedField';
SELECT 'Importing Table Category';
INSERT INTO `Category` (`ixCategory`, `sCategory`, `sPlural`, `ixStatusDefault`, `fIsScheduleItem`, `fDeleted`, `iOrder`, `nIconType`, `ixAttachmentIcon`, `ixStatusDefaultActive`) VALUES (1, 'Bug', 'Bugs', 2, 0, 0, 0, 1, 0, 1);
INSERT INTO `Category` (`ixCategory`, `sCategory`, `sPlural`, `ixStatusDefault`, `fIsScheduleItem`, `fDeleted`, `iOrder`, `nIconType`, `ixAttachmentIcon`, `ixStatusDefaultActive`) VALUES (2, 'Feature', 'Features', 8, 0, 0, 1, 2, 0, 17);
INSERT INTO `Category` (`ixCategory`, `sCategory`, `sPlural`, `ixStatusDefault`, `fIsScheduleItem`, `fDeleted`, `iOrder`, `nIconType`, `ixAttachmentIcon`, `ixStatusDefaultActive`) VALUES (3, 'Inquiry', 'Inquiries', 11, 0, 0, 2, 3, 0, 20);
INSERT INTO `Category` (`ixCategory`, `sCategory`, `sPlural`, `ixStatusDefault`, `fIsScheduleItem`, `fDeleted`, `iOrder`, `nIconType`, `ixAttachmentIcon`, `ixStatusDefaultActive`) VALUES (4, 'Schedule Item', 'Schedule Items', 15, 1, 0, 3, 4, 0, 23);
SELECT 'Imported Table Category';
SELECT 'Importing Table CVS';
SELECT 'Imported Table CVS';
SELECT 'Importing Table DBCopier';
SELECT 'Imported Table DBCopier';
SELECT 'Importing Table DbSession';
INSERT INTO `DbSession` (`ixDbSession`, `sSessionId`, `dtLastAccess`) VALUES (1, '', '2009-12-18T09:19:38');
INSERT INTO `DbSession` (`ixDbSession`, `sSessionId`, `dtLastAccess`) VALUES (2, '', '2009-12-18T09:40:53');
INSERT INTO `DbSession` (`ixDbSession`, `sSessionId`, `dtLastAccess`) VALUES (3, 'tdeilmglmmedlv5988l5kkij2gvjmd', '2009-12-18T09:41:57');
SELECT 'Imported Table DbSession';
SELECT 'Importing Table DbSessionData';
INSERT INTO `DbSessionData` (`ixDbSessionData`, `ixDbSession`, `sKey`, `sValue`, `fSerialized`) VALUES (1, 1, 'fbCookies', '1', 0);
INSERT INTO `DbSessionData` (`ixDbSessionData`, `ixDbSession`, `sKey`, `sValue`, `fSerialized`) VALUES (2, 1, 'ixPerson', '-1', 0);
INSERT INTO `DbSessionData` (`ixDbSessionData`, `ixDbSession`, `sKey`, `sValue`, `fSerialized`) VALUES (3, 1, 'DBID', '', 0);
INSERT INTO `DbSessionData` (`ixDbSessionData`, `ixDbSession`, `sKey`, `sValue`, `fSerialized`) VALUES (4, 2, 'fbCookies', '1', 0);
INSERT INTO `DbSessionData` (`ixDbSessionData`, `ixDbSession`, `sKey`, `sValue`, `fSerialized`) VALUES (5, 2, 'ixPerson', '-1', 0);
INSERT INTO `DbSessionData` (`ixDbSessionData`, `ixDbSession`, `sKey`, `sValue`, `fSerialized`) VALUES (6, 2, 'DBID', '', 0);
INSERT INTO `DbSessionData` (`ixDbSessionData`, `ixDbSession`, `sKey`, `sValue`, `fSerialized`) VALUES (7, 2, 'RelativeListBug', '1', 0);
INSERT INTO `DbSessionData` (`ixDbSessionData`, `ixDbSession`, `sKey`, `sValue`, `fSerialized`) VALUES (8, 2, 'RelativeListSearchParamsBug', '', 0);
INSERT INTO `DbSessionData` (`ixDbSessionData`, `ixDbSession`, `sKey`, `sValue`, `fSerialized`) VALUES (9, 3, 'fbCookies', '1', 0);
INSERT INTO `DbSessionData` (`ixDbSessionData`, `ixDbSession`, `sKey`, `sValue`, `fSerialized`) VALUES (10, 3, 'ixPerson', '-1', 0);
INSERT INTO `DbSessionData` (`ixDbSessionData`, `ixDbSession`, `sKey`, `sValue`, `fSerialized`) VALUES (11, 3, 'DBID', '', 0);
INSERT INTO `DbSessionData` (`ixDbSessionData`, `ixDbSession`, `sKey`, `sValue`, `fSerialized`) VALUES (12, 3, 'RelativeListBug', '1', 0);
INSERT INTO `DbSessionData` (`ixDbSessionData`, `ixDbSession`, `sKey`, `sValue`, `fSerialized`) VALUES (13, 3, 'RelativeListSearchParamsBug', '', 0);
INSERT INTO `DbSessionData` (`ixDbSessionData`, `ixDbSession`, `sKey`, `sValue`, `fSerialized`) VALUES (14, 3, 'dblSessionTimeStamp', '66348.7692994', 0);
SELECT 'Imported Table DbSessionData';
SELECT 'Importing Table DBUpdate';
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (1, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'Setting', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (2, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'Setting,IX_sKey', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (3, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'ACL', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (4, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'ACL,ACLsSectionNameixPersoniPermission', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (5, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'ACL,ACLixPersonixSectioniPermissionsSectionName', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (6, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'ACL,ACLixSectioniPermissionixPersonsSectionName', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (7, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'TitleWord', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (8, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'TitleWord,IX_IxWordIxTitleWordIxBug', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (9, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'TitleWord,TitleWordixBug', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (10, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'TitleWordWord', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (11, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'TitleWordWord,TitleWordWordsWord', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (12, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'Area', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (13, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'Area,AreaIxAreaNTypeSArea', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (14, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'AutoResponseRecord', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (15, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'BugEvent', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (16, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'BugEvent,IX_BugCompound', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (17, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'BugEvent,IX_Person', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (18, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'Attachment', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (19, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'Attachment,AttachmentixBugEvent', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (20, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'Bug', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (21, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'Bug,BugixBugEmail', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (22, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'Bug,IX_IxPersonResolvedBy', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (23, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'Bug,IX_IxPersonClosedBy', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (24, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'Bug,IX_IxPriority', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (25, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'Bug,IX_DtResolved', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (26, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'Bug,IX_DtClosed', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (27, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'Bug,IX_DtOpened', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (28, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'Bug,IX_DtDue', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (29, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'Bug,IX_IxDiscussTopic', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (30, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'Bug,IX_IxBugParent', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (31, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'Bug,IX_IxStatusCompound', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (32, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'Bug,IX_IxBugRootCompound', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (33, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'Bug,IX_IxPersonAssignedToCovering1', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (34, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'Bug,IX_IxPersonAssignedToCovering2', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (35, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'Bug,IX_IxPersonAssignedToCovering3', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (36, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'Bug,IX_BugCompoundfOpen', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (37, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'Bug,IX_FOpenIxPersonAssignedToHrsEstElapsed', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (38, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'Bug,IX_BugCompoundixArea', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (39, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'Bug,IX_BugCompoundixBugEventLatestDesc', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (40, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'Bug,IX_BugCompoundixProject', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (41, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'Bug,IX_BugCompoundixBug', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (42, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'BugEmail', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (43, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'BugEmail,BugEmailsEmail', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (44, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'BugRelation', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (45, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'BugRelation,BugRelationIxBugFrom', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (46, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'BugRelation,BugRelationIxBugTo', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (47, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'BugRelation,BugRelationIxWikiPageTo', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (48, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'Category', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (49, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'CVS', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (50, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'CVS,CVSIxBug', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (51, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'Repository', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (52, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'Repository,RepositorySRepo', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (53, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'DiscussGroup', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (54, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'DiscussGroup,IX_ixGroup', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (55, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'DiscussLayout', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (56, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'DiscussTopic', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (57, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'DiscussTopic,DiscussTopicSUniquePost', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (58, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'DiscussTopic,DiscussTopicDt', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (59, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'DiscussTopic,DiscussTopicGetChild', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (60, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'DiscussTopic,DiscussTopicSuggested1', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (61, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'DiscussTopic,IX_DiscussTopicCompound', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (62, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'DiscussTopic,DiscussTopicSuggested2', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (63, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'DiscussTopic,DiscussTopicSuggested4', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (64, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'DiscussTopic,DiscussTopicGetSpam', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (65, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'DiscussTopic,DiscussTopicSuggested3b', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (66, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'DiscussTopic,DiscussTopicSuggested5', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (67, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'DiscussEmail', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (68, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'DiscussEmail,DiscussEmailSUniqueID', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (69, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'DiscussEmail,DiscussEmailSUniqueEmail', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (70, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'DiscussEmail,DiscussEmailIP', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (71, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'Duplicates', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (72, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'Duplicates,IX_IxBugDupeIxBugDupeOf', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (73, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'EmailWildcard', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (74, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'Notification', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (75, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'Filter', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (76, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'Filter,FiltersFilterName', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (77, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'Filter,FilterixPerson', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (78, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'FixFor', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (79, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'FixForDependency', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (80, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'FixForDependency,FixForDependencyixFixFor', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (81, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'Groups', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (82, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'Holiday', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (83, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'IndexDelta', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (84, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'IndexDelta,IX_sType', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (85, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'IndexFile', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (86, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'IndexFile,IX_sFilename', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (87, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'IndexFile,IX_ixFirstGeneration', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (88, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'IndexFile,IX_ixLastGeneration', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (89, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'IndexFilePage', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (90, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'IndexFilePage,IX_ixIndexFile_nPage', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (91, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'Licenses', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (92, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'Mailbox', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (93, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'MailQueue', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (94, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'DbSession', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (95, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'DbSession,DbSession_sSessionId', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (96, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'DbSessionData', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (97, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'DbSessionData,DbSessionData_ixDbSession', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (98, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'ID', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (99, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'TimeInterval', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (100, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'TimeInterval,TimeInterval_ixBug', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (101, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'TimeInterval,IX_IxPersonCompound', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (102, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'TimeInterval,IX_DtEndFDeleted', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (103, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'PasswordResetCode', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (104, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'PasswordResetCode,PasswordResetCode_Compound1', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (105, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'Person', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (106, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'Person,IX_PersonCompound', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (107, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'Person,Person_sFullName', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (108, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'Person,PersonSuggested2', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (109, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'Person,PersonSuggested3', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (110, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'Person,IX_IxPersonFDeletedFCommunity', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (111, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'Person,IX_FCommunityFDeletedFVirtualIxPerson', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (112, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'Person,IX_FVirtualSEmailIxPersonFDeleted', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (113, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'Prediction', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (114, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'Prediction,IX_IxBug', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (115, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'Priority', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (116, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'Project', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (117, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'Project,ProjectIxGroup', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (118, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'ProjectView', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (119, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'ProjectView,ProjectViewixPerson', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (120, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'ProjectView,ProjectViewixProject', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (121, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'Scout', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (122, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'Scout,IX_IxBug', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (123, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'ShipDate', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (124, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'Snippet', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (125, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'SorterSetting', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (126, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'SearchLog', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (127, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'SearchLog,IX_Person', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (128, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'SorterToken', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (129, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'SorterToken,IX_SToken', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (130, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'Status', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (131, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'Subscriptions', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (132, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'Subscriptions,SubscriptionsixBug', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (133, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'Subscriptions,SubscriptionsixWikiPage', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (134, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'Subscriptions,SubscriptionsixDiscussTopic', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (135, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'Subscriptions,SubscriptionsixPersonixBug', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (136, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'Subscriptions,SubscriptionsixPersonixWikiPage', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (137, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'Subscriptions,SubscriptionsixPersonixDiscussTopic', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (138, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'TokenAssociation', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (139, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'TokenAssociation,IX_TokenAssociation', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (140, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'Tokens', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (141, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'Tokens,IX_FBToken', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (142, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'Tokens,IX_IxPersonFbToken', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (143, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'TrainingRequest', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (144, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'TrainingRequest,IX_TrainingRequest', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (145, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'Version', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (146, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'WorkingSchedule', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (147, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'WorkingSchedule,WorkingScheduleixPerson', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (148, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'ProjectPercentTime', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (149, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'ProjectPercentTime,ProjectPercentTimeixPerson', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (150, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'GridColumn', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (151, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'GridColumn,GridColumnCompound5', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (152, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'GridColumn,GridColumnCompound4', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (153, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'GridColumn,GridColumnCompound1', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (154, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'GridColumn,IX_IxPersonIType', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (155, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'GridColumn,IX_IxFilterCompound', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (156, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'FBLanguage', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (157, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'FBLanguage,LanguageName', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (158, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'FBLanguage,LanguageLCID', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (159, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'FBLanguage,LanguageLocaleCode', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (160, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'Revision', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (161, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'Revision,RevisionIxWikiPage', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (162, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'WikiExternalLink', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (163, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'WikiLink', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (164, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'WikiLink,WikiLinkIxWikiPageFrom', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (165, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'WikiLink,WikiLinkIxWikiPageTo', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (166, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'Template', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (167, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'WikiPage', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (168, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'WikiPage,WikiPageSHeadline', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (169, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'WikiPage,WikiPageIxWiki', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (170, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'WikiPage,WikiPageSuggested1', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (171, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'Wiki', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (172, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'Wiki,IX_fDeleted', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (173, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'Dictionary', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (174, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'Word', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (175, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'Word,WordIxDictionary', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (176, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'Word,WordSMetaphonePrimary', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (177, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'Word,WordSMetaphoneSecondary', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (178, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'Word,WordIxPerson', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (179, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'Word,WordCompound1', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (180, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'IgnoredWord', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (181, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'BugView', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (182, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'BugView,BugViewIxPersonCompound', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (183, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'BugView,BugViewIxBug', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (184, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'BugView,BugViewSuggested1', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (185, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'BugView,BugViewPersonDtReverse', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (186, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'BugView,IX_BugViewCompound', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (187, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'WikiPageView', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (188, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'WikiPageView,WikiPageViewIxWikiPage', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (189, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'WikiPageView,IX_FullTextSearch', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (190, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'WikiPageView,WikiPageViewPersonDtReverse', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (191, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'DiscussTopicView', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (192, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'DiscussTopicView,DiscussTopicViewPersonDtReverse', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (193, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'DiscussTopicView,DiscussTopicViewSuggested1', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (194, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'DocList', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (195, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'DocList,DocListIxPerson', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (196, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'DocListItem', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (197, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'DocListItem,DocListItemSType', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (198, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'DocListItem,DocListItemIxItem', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (199, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'DocListItem,DocListItemIxDocListInOrder', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (200, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'DocListItem,IX_DocListCompound', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (201, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'Draft', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (202, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'Draft,DraftIxPerson', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (203, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'Draft,DraftIxItem', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (204, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'Draft,DraftSType', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (205, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'FragmentCache', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (206, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'FragmentCache,FragmentCacheIxPerson', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (207, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'FragmentCache,FragmentCache_SearchCompound', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (208, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'FragmentCache,FragmentCache_Compound', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (209, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'FragmentDependency', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (210, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'FragmentDependency,FragmentCacheSKey', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (211, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'FragmentDependency,FragmentCacheSDependency', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (212, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'FBLock', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (213, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'FBLock,FBLockSLockSKey', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (214, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'Plugin', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (215, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'PluginKeyValue', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (216, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'PluginKeyValue,PluginKeyValueIxPluginSKey', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (217, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'Tag', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (218, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'Tag,TagsTag', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (219, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'TagAssociation', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (220, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'TagAssociation,TagAssociationCompound', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (221, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'TagAssociation,TagAssociationIxBug', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (222, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'TagAssociation,TagAssociationIxWikiPage', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (223, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'TagEvent', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (224, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'TagEvent,TagEventIxBugEvent', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (225, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'TagEvent,TagEventIxRevision', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (226, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'Workflow', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (227, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'WorkflowRule', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (228, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'WorkflowRule,WorkflowRuleCompound', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (229, 'jatj1v684566i3t35dqej77jhlsi3o', 1, 'BugViewPinnedField', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (230, 'jatj1v684566i3t35dqej77jhlsi3o', 3, 'BugViewPinnedField,BugViewPinnedFieldIxPersonSFieldIxPlugin', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (231, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'PopulateSetting', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (232, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'PopulateACL', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (233, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'StartBackfillTitleWords', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (234, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'PopulateArea', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (235, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'StartBackfillBugEventAttachment', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (236, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'PopulateBugIxLatestTextSummary', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (237, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'StartBackfillBugIxPersonResolvedBy', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (238, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'StartBackfillBugIxPersonClosedBy', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (239, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'StartBackfillBugIxPersonLastEditedBy', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (240, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'BackfillBugHrsElapsedExtra', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (241, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'BackfillBugDtResolved', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (242, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'BackfillBugDtClosed', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (243, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'PopulateBugIxBugEventLatest', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (244, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'BackfillBugFEstLocked', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (245, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'StartBackfillBugEmail', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (246, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'StartBackfillBugRelation', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (247, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'PopulateCategory', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (248, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'PopulateCategorySPlural', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (249, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'PopulateCategoryIOrder', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (250, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'PopulateCategoryNCategoryIcon', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (251, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'PopulateRepository', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (252, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'PopulateDiscussGroupSPostHelpHTML', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (253, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'PopulateDiscussGroupFRequireApproval', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (254, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'PopulateDiscussGroupIxAreaUndecided', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (255, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'PopulateDiscussTopicUserAgent', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (256, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'StartBackFillDiscussTopicIPs', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (257, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'BackFillDiscussEmailIPs', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (258, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'PopulateFilterIxGroup', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (259, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'PopulateFilterFGlobal', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (260, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'PopulateFixFor', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (261, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'PopulateFixforInactive', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (262, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'PopulateGroups', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (263, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'PopulateHolidayDtHolidayEnd', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (264, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'PopulateMailboxFTrialMailbox', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (265, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'PopulatePerson', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (266, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'PopulatePersonsSnippetKey', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (267, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'PopulatePersonFILTER_ixGroup', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (268, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'PopulatePersonFILTER_sFilterName', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (269, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'PopulatePersonDtDailyTask', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (270, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'PopulatePersonDtLastScheduleMaint', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (271, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'PopulatePriority', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (272, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'SetDefaultPriority', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (273, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'PopulateProject', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (274, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'AddTokenCaseSensitivity', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (275, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'PopulateStatus', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (276, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'PopulateStatusFWorkDone', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (277, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'PopulateStatusFDuplicate', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (278, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'PopulateStatusIOrder', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (279, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'PopulateVersion', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (280, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'PopulateWorkingScheduleLastUpdated', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (281, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'PopulateWorkingScheduleAutoClock', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (282, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'PopulateWorkingSchedulenPercentTimeAllOtherProjects', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (283, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'PopulateLanguage', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (284, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'BackFillRevisionIPs', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (285, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'StartBackfillRevisionStrength', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (286, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'PopulateTemplate', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (287, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'PopulateDictionary', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (288, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'PopulateBugView', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (289, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'PopulateWikiPageView', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (290, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'PopulateDiscussTopicView', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (291, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'ClearDrafts', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (292, 'jatj1v684566i3t35dqej77jhlsi3o', 9, 'PopulateWorkflow', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (293, 'jatj1v684566i3t35dqej77jhlsi3o', 15, 'FinalUpdates', 0);
INSERT INTO `DBUpdate` (`ixDBUpdate`, `sUpgradeKey`, `nChangeType`, `sChangeSpecifics`, `fReversed`) VALUES (294, 'jatj1v684566i3t35dqej77jhlsi3o', 16, 'FinalUpdates', 0);
SELECT 'Imported Table DBUpdate';
SELECT 'Importing Table Dictionary';
INSERT INTO `Dictionary` (`ixPKDictionary`, `ixDictionary`, `sDictionary`, `sDescription`) VALUES (1, 1, 'en', 'English');
SELECT 'Imported Table Dictionary';
SELECT 'Importing Table DiscussEmail';
SELECT 'Imported Table DiscussEmail';
SELECT 'Importing Table DiscussGroup';
SELECT 'Imported Table DiscussGroup';
SELECT 'Importing Table DiscussLayout';
SELECT 'Imported Table DiscussLayout';
SELECT 'Importing Table DiscussTopic';
SELECT 'Imported Table DiscussTopic';
SELECT 'Importing Table DiscussTopicView';
SELECT 'Imported Table DiscussTopicView';
SELECT 'Importing Table DocList';
INSERT INTO `DocList` (`ixDocList`, `ixPerson`, `sName`, `fFavorites`) VALUES (1, 2, 'Starred', 1);
SELECT 'Imported Table DocList';
SELECT 'Importing Table DocListItem';
SELECT 'Imported Table DocListItem';
SELECT 'Importing Table Draft';
SELECT 'Imported Table Draft';
SELECT 'Importing Table Duplicates';
SELECT 'Imported Table Duplicates';
SELECT 'Importing Table EmailWildcard';
SELECT 'Imported Table EmailWildcard';
SELECT 'Importing Table FBLanguage';
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (1, 'Afrikaans (South Africa)', '1078', NULL, 'af-za', 'af');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (2, 'Albanian (Albania)', '1052', NULL, 'sq-al', 'sq');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (3, 'Arabic (Algeria)', '5121', NULL, 'ar-dz', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (4, 'Arabic (Bahrain)', '15361', NULL, 'ar-bh', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (5, 'Arabic (Egypt)', '3073', NULL, 'ar-eg', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (6, 'Arabic (Iraq)', '2049', NULL, 'ar-iq', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (7, 'Arabic (Jordan)', '11265', NULL, 'ar-jo', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (8, 'Arabic (Kuwait)', '13313', NULL, 'ar-kw', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (9, 'Arabic (Lebanon)', '12289', NULL, 'ar-lb', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (10, 'Arabic (Libya)', '4097', NULL, 'ar-ly', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (11, 'Arabic (Morocco)', '6145', NULL, 'ar-ma', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (12, 'Arabic (Oman)', '8193', NULL, 'ar-om', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (13, 'Arabic (Qatar)', '16385', NULL, 'ar-qa', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (14, 'Arabic (Saudi Arabia)', '1025', NULL, 'ar-sa', 'ar');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (15, 'Arabic (Syria)', '10241', NULL, 'ar-sy', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (16, 'Arabic (Tunisia)', '7169', NULL, 'ar-tn', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (17, 'Arabic (U.A.E.)', '14337', NULL, 'ar-ae', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (18, 'Arabic (Yemen)', '9217', NULL, 'ar-ye', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (19, 'Armenian (Armenia)', '1067', NULL, 'hy-am', 'hy');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (20, 'Azeri (Cyrillic, Azerbaijan)', '2092', NULL, 'az-cyrl-az', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (21, 'Azeri (Latin, Azerbaijan)', '1068', NULL, 'az-latn-az', 'az');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (22, 'Basque (Basque)', '1069', NULL, 'eu-es', 'eu');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (23, 'Belarusian (Belarus)', '1059', NULL, 'be-by', 'be');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (24, 'Bosnian (Latin, Bosnia and Herzegovina)', '5146', NULL, 'bs-latn-ba', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (25, 'Bulgarian (Bulgaria)', '1026', NULL, 'bg-bg', 'bg');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (26, 'Catalan (Catalan)', '1027', NULL, 'ca-es', 'ca');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (27, 'Chinese (Hong Kong S.A.R.)', '3076', NULL, 'zh-hk', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (28, 'Chinese (Macao S.A.R.)', '5124', NULL, 'zh-mo', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (29, 'Chinese (People\'s Republic of China)', '2052', NULL, 'zh-cn', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (30, 'Chinese (Singapore)', '4100', NULL, 'zh-sg', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (31, 'Chinese (Taiwan)', '1028', NULL, 'zh-tw', 'zh');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (32, 'Chinese (Traditional)', '31748', NULL, 'zh-hant', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (33, 'Croatian (Bosnia and Herzegovina)', '4122', NULL, 'hr-ba', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (34, 'Croatian (Croatia)', '1050', NULL, 'hr-hr', 'hr');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (35, 'Czech (Czech Republic)', '1029', NULL, 'cs-cz', 'cs');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (36, 'Danish (Denmark)', '1030', NULL, 'da-dk', 'da');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (37, 'Divehi (Maldives)', '1125', NULL, 'div-mv', 'div');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (38, 'Dutch (Belgium)', '2067', NULL, 'nl-be', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (39, 'Dutch (Netherlands)', '1043', NULL, 'nl-nl', 'nl');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (40, 'English (Australia)', '3081', NULL, 'en-au', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (41, 'English (Belize)', '10249', NULL, 'en-bz', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (42, 'English (Canada)', '4105', NULL, 'en-ca', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (43, 'English (Caribbean)', '9225', NULL, 'en-029', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (44, 'English (Ireland)', '6153', NULL, 'en-ie', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (45, 'English (Jamaica)', '8201', NULL, 'en-jm', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (46, 'English (New Zealand)', '5129', NULL, 'en-nz', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (47, 'English (Republic of the Philippines)', '13321', NULL, 'en-ph', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (48, 'English (South Africa)', '7177', NULL, 'en-za', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (49, 'English (Trinidad and Tobago)', '11273', NULL, 'en-tt', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (50, 'English (United Kingdom)', '2057', NULL, 'en-gb', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (51, 'English (United States)', '1033', 'en-US', 'en-us', 'en');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (52, 'English (Zimbabwe)', '12297', NULL, 'en-zw', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (53, 'Estonian (Estonia)', '1061', NULL, 'et-ee', 'et');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (54, 'Faroese (Faroe Islands)', '1080', NULL, 'fo-fo', 'fo');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (55, 'Finnish (Finland)', '1035', NULL, 'fi-fi', 'fi');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (56, 'French (Belgium)', '2060', NULL, 'fr-be', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (57, 'French (Canada)', '3084', NULL, 'fr-ca', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (58, 'French (France)', '1036', 'fr-FR', 'fr-fr', 'fr');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (59, 'French (Luxembourg)', '5132', NULL, 'fr-lu', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (60, 'French (Principality of Monaco)', '6156', NULL, 'fr-mc', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (61, 'French (Switzerland)', '4108', NULL, 'fr-ch', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (62, 'Galician (Galician)', '1110', NULL, 'gl-es', 'gl');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (63, 'Georgian (Georgia)', '1079', NULL, 'ka-ge', 'ka');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (64, 'German (Austria)', '3079', NULL, 'de-at', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (65, 'German (Germany)', '1031', 'de-DE', 'de-de', 'de');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (66, 'German (Liechtenstein)', '5127', NULL, 'de-li', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (67, 'German (Luxembourg)', '4103', NULL, 'de-lu', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (68, 'German (Switzerland)', '2055', NULL, 'de-ch', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (69, 'Greek (Greece)', '1032', NULL, 'el-gr', 'el');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (70, 'Gujarati (India)', '1095', NULL, 'gu-in', 'gu');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (71, 'Hebrew (Israel)', '1037', NULL, 'he-il', 'he');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (72, 'Hindi (India)', '1081', NULL, 'hi-in', 'hi');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (73, 'Hungarian (Hungary)', '1038', NULL, 'hu-hu', 'hu');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (74, 'Icelandic (Iceland)', '1039', NULL, 'is-is', 'is');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (75, 'Indonesian (Indonesia)', '1057', NULL, 'id-id', 'id');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (76, 'Italian (Italy)', '1040', NULL, 'it-it', 'it');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (77, 'Italian (Switzerland)', '2064', NULL, 'it-ch', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (78, 'Japanese (Japan)', '1041', NULL, 'ja-jp', 'ja');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (79, 'Kannada (India)', '1099', NULL, 'kn-in', 'kn');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (80, 'Kazakh (Kazakhstan)', '1087', NULL, 'kk-kz', 'kk');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (81, 'Kiswahili (Kenya)', '1089', NULL, 'sw-ke', 'sw');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (82, 'Konkani (India)', '1111', NULL, 'kok-in', 'kok');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (83, 'Korean (Korea)', '1042', NULL, 'ko-kr', 'ko');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (84, 'Kyrgyz (Kyrgyzstan)', '1088', NULL, 'ky-kg', 'ky');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (85, 'Latvian (Latvia)', '1062', NULL, 'lv-lv', 'lv');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (86, 'Lithuanian (Lithuania)', '1063', NULL, 'lt-lt', 'lt');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (87, 'Macedonian (Former Yugoslav Republic of Macedonia)', '1071', NULL, 'mk-mk', 'mk');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (88, 'Malay (Brunei Darussalam)', '2110', NULL, 'ms-bn', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (89, 'Malay (Malaysia)', '1086', NULL, 'ms-my', 'ms');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (90, 'Maltese', '1082', NULL, 'mt-mt', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (91, 'Maori', '1153', NULL, 'mi-nz', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (92, 'Marathi (India)', '1102', NULL, 'mr-in', 'mr');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (93, 'Mongolian (Cyrillic, Mongolia)', '1104', NULL, 'mn-mn', 'mn');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (94, 'Northern Sotho', '1132', NULL, 'ns-za', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (95, 'Norwegian, Bokmal (Norway)', '1044', NULL, 'nb-no', 'no');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (96, 'Norwegian, Nynorsk (Norway)', '2068', NULL, 'nn-no', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (97, 'Persian (Iran)', '1065', NULL, 'fa-ir', 'fa');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (98, 'Polish (Poland)', '1045', NULL, 'pl-pl', 'pl');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (99, 'Portuguese (Brazil)', '1046', 'pt-BR', 'pt-br', 'pt');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (100, 'Portuguese (Portugal)', '2070', NULL, 'pt-pt', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (101, 'Punjabi (India)', '1094', NULL, 'pa-in', 'pa');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (102, 'Quechua (Bolivia)', '1131', NULL, 'quz-bo', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (103, 'Quechua (Ecuador)', '2155', NULL, 'quz-ec', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (104, 'Quechua (Peru)', '3179', NULL, 'quz-pe', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (105, 'Romanian (Romania)', '1048', NULL, 'ro-ro', 'ro');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (106, 'Russian (Russia)', '1049', NULL, 'ru-ru', 'ru');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (107, 'Sami, Inari (Finland)', '9275', NULL, 'smn-fi', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (108, 'Sami, Lule (Norway)', '4155', NULL, 'smj-no', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (109, 'Sami, Lule (Sweden)', '5179', NULL, 'smj-se', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (110, 'Sami, Northern (Finland)', '3131', NULL, 'se-fi', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (111, 'Sami, Northern (Norway)', '1083', NULL, 'se-no', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (112, 'Sami, Northern (Sweden)', '2107', NULL, 'se-se', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (113, 'Sami, Skolt (Finland)', '8251', NULL, 'sms-fi', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (114, 'Sami, Southern (Norway)', '6203', NULL, 'sma-no', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (115, 'Sami, Southern (Sweden)', '7227', NULL, 'sma-se', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (116, 'Sanskrit (India)', '1103', NULL, 'sa-in', 'sa');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (117, 'Serbian', '31770', NULL, 'sr', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (118, 'Serbian (Cyrillic, Bosnia and Herzegovina)', '7194', NULL, 'sr-cyrl-ba', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (119, 'Serbian (Cyrillic, Serbia and Montenegro)', '3098', NULL, 'sr-cyrl-sp', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (120, 'Serbian (Latin, Bosnia and Herzegovina)', '6170', NULL, 'sr-latn-ba', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (121, 'Serbian (Latin, Serbia and Montenegro)', '2074', NULL, 'sr-latn-sp', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (122, 'Slovak (Slovakia)', '1051', NULL, 'sk-sk', 'sk');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (123, 'Slovenian (Slovenia)', '1060', NULL, 'sl-si', 'sl');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (124, 'Spanish (Argentina)', '11274', NULL, 'es-ar', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (125, 'Spanish (Bolivia)', '16394', NULL, 'es-bo', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (126, 'Spanish (Chile)', '13322', NULL, 'es-cl', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (127, 'Spanish (Colombia)', '9226', NULL, 'es-co', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (128, 'Spanish (Costa Rica)', '5130', NULL, 'es-cr', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (129, 'Spanish (Dominican Republic)', '7178', NULL, 'es-do', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (130, 'Spanish (Ecuador)', '12298', NULL, 'es-ec', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (131, 'Spanish (El Salvador)', '17418', NULL, 'es-sv', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (132, 'Spanish (Guatemala)', '4106', NULL, 'es-gt', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (133, 'Spanish (Honduras)', '18442', NULL, 'es-hn', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (134, 'Spanish (Mexico)', '2058', NULL, 'es-mx', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (135, 'Spanish (Nicaragua)', '19466', NULL, 'es-ni', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (136, 'Spanish (Panama)', '6154', NULL, 'es-pa', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (137, 'Spanish (Paraguay)', '15370', NULL, 'es-py', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (138, 'Spanish (Peru)', '10250', NULL, 'es-pe', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (139, 'Spanish (Puerto Rico)', '20490', NULL, 'es-pr', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (140, 'Spanish (Spain)', '3082', 'es-ES', 'es-es', 'es');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (141, 'Spanish (Uruguay)', '14346', NULL, 'es-uy', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (142, 'Spanish (Venezuela)', '8202', NULL, 'es-ve', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (143, 'Swedish (Finland)', '2077', NULL, 'sv-fi', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (144, 'Swedish (Sweden)', '1053', NULL, 'sv-se', 'sv');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (145, 'Syriac (Syria)', '1114', NULL, 'syr-sy', 'syr');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (146, 'Tamil (India)', '1097', NULL, 'ta-in', 'ta');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (147, 'Tatar (Russia)', '1092', NULL, 'tt-ru', 'tt');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (148, 'Telugu (India)', '1098', NULL, 'te-in', 'te');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (149, 'Thai (Thailand)', '1054', NULL, 'th-th', 'th');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (150, 'Tswana', '1074', NULL, 'tn-za', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (151, 'Turkish (Turkey)', '1055', NULL, 'tr-tr', 'tr');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (152, 'Ukrainian (Ukraine)', '1058', NULL, 'uk-ua', 'uk');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (153, 'Urdu (Islamic Republic of Pakistan)', '1056', NULL, 'ur-pk', 'ur');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (154, 'Uzbek (Cyrillic, Uzbekistan)', '2115', NULL, 'uz-cyrl-uz', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (155, 'Uzbek (Latin, Uzbekistan)', '1091', NULL, 'uz-latn-uz', 'uz');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (156, 'Vietnamese (Vietnam)', '1066', NULL, 'vi-vn', 'vi');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (157, 'Welsh', '1106', NULL, 'cy-gb', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (158, 'Xhosa', '1076', NULL, 'xh-za', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (159, 'Zulu', '1077', NULL, 'zu-za', NULL);
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (160, 'Pig Latin (United States)', '512', 'pig', 'pig-latin', 'pig');
INSERT INTO `FBLanguage` (`ixLanguage`, `sName`, `sLCID`, `sLangFile`, `sLocaleCode`, `sGenericLocaleCode`) VALUES (161, 'Pig Latin 2 (United States)', '511', 'altpig', 'altpig', NULL);
SELECT 'Imported Table FBLanguage';
SELECT 'Importing Table FBLock';
INSERT INTO `FBLock` (`ixFBLock`, `sLock`, `sKey`, `dtExpires`, `fBrokeLock`) VALUES (1, 'CPluginModule Init', '', NULL, 0);
INSERT INTO `FBLock` (`ixFBLock`, `sLock`, `sKey`, `dtExpires`, `fBrokeLock`) VALUES (2, 'site secret rotation', '', NULL, 0);
INSERT INTO `FBLock` (`ixFBLock`, `sLock`, `sKey`, `dtExpires`, `fBrokeLock`) VALUES (3, 'SessionWriteLock_tdeilmglmmedlv5988l5kkij2gvjmd', '', NULL, 0);
SELECT 'Imported Table FBLock';
SELECT 'Importing Table Filter';
SELECT 'Imported Table Filter';
SELECT 'Importing Table FixFor';
INSERT INTO `FixFor` (`ixFixFor`, `sFixFor`, `dt`, `fDeleted`, `ixProject`, `fInactive`, `dtStart`, `sStartNote`) VALUES (1, 'Undecided', NULL, 0, -1, 0, NULL, NULL);
SELECT 'Imported Table FixFor';
SELECT 'Importing Table FixForDependency';
SELECT 'Imported Table FixForDependency';
SELECT 'Importing Table FragmentCache';
SELECT 'Imported Table FragmentCache';
SELECT 'Importing Table FragmentDependency';
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (1, 'AboveBanner', 'person');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (2, 'NavMainLinksCacheable', 'filter');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (3, 'NavMainLinksCacheable', 'project');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (4, 'NavMainLinksCacheable', 'discussgroup');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (5, 'NavMainLinksCacheable', 'wiki');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (6, 'SearchHistory', 'searchlog');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (7, 'MainMenuListFiltersOldVersion', 'filter');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (8, 'MainMenuListFiltersOldVersion', 'project');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (9, 'GetStatusEditInfo', 'status');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (10, 'GetStatusEditInfo', 'category');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (11, 'JSRgSnippet', 'snippet');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (12, 'AllSimsCache', 'fixfor');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (13, 'AllSimsCache', 'fixfordependency');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (14, 'AllSimsCache', 'workingschedule');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (15, 'RawAllSimsCache', 'fixfor');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (16, 'RawAllSimsCache', 'fixfordependency');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (17, 'RawAllSimsCache', 'holiday');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (18, 'RawAllSimsCache', 'workingschedule');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (19, 'AllTasks', 'fixfor');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (20, 'AllTasks', 'fixfordependency');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (21, 'RawAllTasks', 'fixfor');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (22, 'RawAllTasks', 'fixfordependency');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (23, 'GetCachedFixFor', 'fixfor');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (24, 'GetCachedFixFor', 'fixfordependency');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (25, 'ActiveFixForDict', 'fixfor');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (26, 'ActiveFixForDict', 'fixfordependency');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (27, 'FixForExecutionOrder', 'fixfor');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (28, 'FixForExecutionOrder', 'fixfordependency');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (29, 'JSDBCacheKey', 'project');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (30, 'JSDBCacheKey', 'area');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (31, 'JSDBCacheKey', 'category');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (32, 'JSDBCacheKey', 'status');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (33, 'JSDBCacheKey', 'person');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (34, 'JSDBCacheKey', 'fixfor');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (35, 'JSDBCacheKey', 'priority');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (36, 'JSDBCacheKey', 'setting');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (37, 'JSDBCacheKey', 'workingschedule');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (38, 'JSDBCacheKey', 'mailbox');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (39, 'JSDBCacheKey', 'workflowrule');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (40, 'GenerateJSDBCacheable', 'project');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (41, 'GenerateJSDBCacheable', 'area');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (42, 'GenerateJSDBCacheable', 'category');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (43, 'GenerateJSDBCacheable', 'status');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (44, 'GenerateJSDBCacheable', 'person');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (45, 'GenerateJSDBCacheable', 'fixfor');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (46, 'GenerateJSDBCacheable', 'priority');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (47, 'GenerateJSDBCacheable', 'setting');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (48, 'GenerateJSDBCacheable', 'workingschedule');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (49, 'GenerateJSDBCacheable', 'mailbox');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (50, 'GenerateJSDBCacheable', 'workflowrule');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (51, 'DlgListOfNamesImpl', 'person');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (52, 'DlgListOfProjects', 'project');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (53, 'DlgListOfProjects', 'person');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (54, 'DlgListOfAreasImpl', 'area');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (55, 'DlgListOfAreasImpl', 'project');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (56, 'DlgListOfFixFors', 'fixfor');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (57, 'DiscussRSS', 'discusstopic');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (58, 'DiscussRSS', 'discussgroup');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (59, 'DiscussRSS', 'person');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (60, 'SQLUsersGroups', 'group');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (61, 'SQLUsersGroups', 'person');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (62, 'SQLUsersProjects', 'project');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (63, 'SQLUsersProjects', 'person');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (64, 'SQLUsersWikis', 'wiki');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (65, 'SQLUsersWikis', 'person');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (66, 'SQLUsersDiscussGroups', 'discussgroup');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (67, 'SQLUsersDiscussGroups', 'person');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (68, 'SQLUsersPeople', 'person');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (69, 'SQLUsersWritableWorkflows', 'workflow');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (70, 'SQLUsersWritableWorkflows', 'person');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (71, 'SQLUsersWritableTemplates', 'template');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (72, 'SQLUsersWritableTemplates', 'person');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (73, 'SQLUsersReadableWorkflows', 'workflow');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (74, 'SQLUsersReadableWorkflows', 'person');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (75, 'SQLUsersReadableTemplates', 'template');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (76, 'SQLUsersReadableTemplates', 'person');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (77, 'CanReadAtLeastOneProject', 'project');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (78, 'CanReadAtLeastOneProject', 'person');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (79, 'CanWriteAtLeastOneProject', 'project');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (80, 'CanWriteAtLeastOneProject', 'person');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (81, 'CanSeeCases', 'project');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (82, 'CanSeeCases', 'person');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (83, 'IsAdmin', 'person');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (84, 'IsSectionAdmin', 'person');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (85, 'IsSectionAdmin', 'project');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (86, 'IsSectionAdmin', 'wiki');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (87, 'IsSectionAdmin', 'discussgroup');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (88, 'IsSectionAdmin', 'group');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (89, 'CanSendEmail', 'mailbox');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (90, 'GetProject', 'project');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (91, 'FB_CASE_InSiteLanguage', 'setting');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (92, 'MemoizeMe3', 'testdependency');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (93, 'MemoizeMe4', 'testdependency2');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (94, 'GetCPerson', 'person');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (95, 'FindPersonByName', 'person');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (96, 'CPermissionToken_InternalGetSToken', 'discussgroup');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (97, 'CPermissionToken_InternalGetSToken', 'mailbox');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (98, 'CPermissionToken_InternalGetSToken', 'project');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (99, 'CPermissionToken_InternalGetSToken', 'groups');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (100, 'CPermissionToken_InternalGetSToken', 'wiki');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (101, 'CPermissionToken_InternalGetSToken', 'person');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (102, 'GetCProject', 'project');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (103, 'CategoryNextIOrder', 'category');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (104, 'GetCategoryByName', 'category');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (105, 'GetCategoryByPluralName', 'category');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (106, 'GetCCategory', 'category');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (107, 'GetCFixFor', 'fixfor');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (108, 'GetCStatus', 'status');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (109, 'GetCStatusByName', 'status');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (110, 'StatusNextIOrder', 'status');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (111, 'StatusResolvedInClause', 'status');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (112, 'StatusActiveInClause', 'status');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (113, 'GetReadonlyDiscussGroup', 'discussgroup');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (114, 'GetWorkingScheduleDict', 'workingschedule');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (115, 'GetWorkingScheduleDict', 'projectpercenttime');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (116, 'RawGetWorkingScheduleDict', 'workingschedule');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (117, 'RawGetWorkingScheduleDict', 'projectpercenttime');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (118, 'GetFutureHolidays', 'holiday');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (119, 'GetAllFutureHolidays', 'holiday');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (120, 'RawGetAllFutureHolidays', 'holiday');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (121, 'CalculateDt', 'workingschedule');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (122, 'CalculateDt', 'holiday');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (123, 'SQLVisibleFilterClauses', 'acl');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (124, 'GetEstimator', 'person');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (125, 'GetEstimatorDict', 'person');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (126, 'GetCachedEstimatorDict', 'person');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (127, 'GetCWorkflow', 'workflow');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (128, 'GetCWorkflowByName', 'workflow');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (129, 'GetCWorkflowRule', 'workflowrule');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (130, 'FindPrimaryContact', 'project');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (131, 'FindPrimaryContact', 'area');
INSERT INTO `FragmentDependency` (`ixFragmentDependency`, `sKey`, `sDependency`) VALUES (132, 'FogCreek.FogBugz.CPermissionManager.GetPersonIDsForPerson', 'person');
SELECT 'Imported Table FragmentDependency';
SELECT 'Importing Table GridColumn';
INSERT INTO `GridColumn` (`ixGridColumn`, `ixPerson`, `ixFilter`, `ixPlugin`, `iType`, `iOrder`, `pxWidth`, `fVisible`) VALUES (1, 2, -1, -1, 1, 0, 16, 1);
INSERT INTO `GridColumn` (`ixGridColumn`, `ixPerson`, `ixFilter`, `ixPlugin`, `iType`, `iOrder`, `pxWidth`, `fVisible`) VALUES (2, 2, -1, -1, 29, 1, 15, 1);
INSERT INTO `GridColumn` (`ixGridColumn`, `ixPerson`, `ixFilter`, `ixPlugin`, `iType`, `iOrder`, `pxWidth`, `fVisible`) VALUES (3, 2, -1, -1, 2, 2, 50, 1);
INSERT INTO `GridColumn` (`ixGridColumn`, `ixPerson`, `ixFilter`, `ixPlugin`, `iType`, `iOrder`, `pxWidth`, `fVisible`) VALUES (4, 2, -1, -1, 23, 3, 350, 1);
INSERT INTO `GridColumn` (`ixGridColumn`, `ixPerson`, `ixFilter`, `ixPlugin`, `iType`, `iOrder`, `pxWidth`, `fVisible`) VALUES (5, 2, -1, -1, 4, 4, 100, 1);
INSERT INTO `GridColumn` (`ixGridColumn`, `ixPerson`, `ixFilter`, `ixPlugin`, `iType`, `iOrder`, `pxWidth`, `fVisible`) VALUES (6, 2, -1, -1, 22, 5, 150, 1);
INSERT INTO `GridColumn` (`ixGridColumn`, `ixPerson`, `ixFilter`, `ixPlugin`, `iType`, `iOrder`, `pxWidth`, `fVisible`) VALUES (7, 2, -1, -1, 6, 6, 100, 1);
INSERT INTO `GridColumn` (`ixGridColumn`, `ixPerson`, `ixFilter`, `ixPlugin`, `iType`, `iOrder`, `pxWidth`, `fVisible`) VALUES (8, 2, -1, -1, 7, 7, 100, 1);
INSERT INTO `GridColumn` (`ixGridColumn`, `ixPerson`, `ixFilter`, `ixPlugin`, `iType`, `iOrder`, `pxWidth`, `fVisible`) VALUES (9, 2, -1, -1, 14, 8, 150, 1);
SELECT 'Imported Table GridColumn';
SELECT 'Importing Table Groups';
INSERT INTO `Groups` (`ixGroup`, `sName`, `sNotes`, `fDeleted`) VALUES (1, 'Internal', '', 0);
SELECT 'Imported Table Groups';
SELECT 'Importing Table Holiday';
SELECT 'Imported Table Holiday';
SELECT 'Importing Table ID';
INSERT INTO `ID` (`id`) VALUES ('jmcmsm701bdkc1hodp7m98u3n6ea8f');
SELECT 'Imported Table ID';
SELECT 'Importing Table IgnoredWord';
SELECT 'Imported Table IgnoredWord';
SELECT 'Importing Table IndexDelta';
SELECT 'Imported Table IndexDelta';
SELECT 'Importing Table IndexFile';
INSERT INTO `IndexFile` (`ixIndexFile`, `sPrefix`, `sFilename`, `sLockKey`, `nLastModifiedLo`, `nLastModifiedHi`, `cbLengthLo`, `cbLengthHi`, `ixFirstGeneration`, `ixLastGeneration`, `dtExpires`) VALUES (6, 'MainIndex', 'transaction.lock', '', 0, 0, 0, 0, 4, 6, '2009-12-18T09:57:14');
INSERT INTO `IndexFile` (`ixIndexFile`, `sPrefix`, `sFilename`, `sLockKey`, `nLastModifiedLo`, `nLastModifiedHi`, `cbLengthLo`, `cbLengthHi`, `ixFirstGeneration`, `ixLastGeneration`, `dtExpires`) VALUES (7, 'MainIndex', 'write.lock', '', 0, 0, 0, 0, 5, 6, '2009-12-18T09:57:12');
INSERT INTO `IndexFile` (`ixIndexFile`, `sPrefix`, `sFilename`, `sLockKey`, `nLastModifiedLo`, `nLastModifiedHi`, `cbLengthLo`, `cbLengthHi`, `ixFirstGeneration`, `ixLastGeneration`, `dtExpires`) VALUES (8, 'MainIndex', 'tcommit.lock', '', 0, 0, 0, 0, 5, 6, '2009-12-18T09:57:12');
INSERT INTO `IndexFile` (`ixIndexFile`, `sPrefix`, `sFilename`, `sLockKey`, `nLastModifiedLo`, `nLastModifiedHi`, `cbLengthLo`, `cbLengthHi`, `ixFirstGeneration`, `ixLastGeneration`, `dtExpires`) VALUES (9, 'MainIndex', 'segments', '', 556432919, 587, 20, 0, 5, 5, NULL);
INSERT INTO `IndexFile` (`ixIndexFile`, `sPrefix`, `sFilename`, `sLockKey`, `nLastModifiedLo`, `nLastModifiedHi`, `cbLengthLo`, `cbLengthHi`, `ixFirstGeneration`, `ixLastGeneration`, `dtExpires`) VALUES (10, 'MainIndex', 'commit.lock', '', 0, 0, 0, 0, 5, 6, '2009-12-18T09:57:14');
SELECT 'Imported Table IndexFile';
SELECT 'Importing Table IndexFilePage';
INSERT INTO `IndexFilePage` (`ixIndexFilePage`, `ixIndexFile`, `nPage`, `sPage`) VALUES (2, 9, 0, 0xffffffff08cc4db399c76a7d0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
SELECT 'Imported Table IndexFilePage';
SELECT 'Importing Table Licenses';
SELECT 'Imported Table Licenses';
SELECT 'Importing Table Mailbox';
INSERT INTO `Mailbox` (`ixMailbox`, `sEmail`, `sFullName`, `sUser`, `sPass`, `sServer`, `sPort`, `sURLPrefix`, `sTemplate`, `ixProject`, `ixArea`, `ixFixFor`, `ixPriority`, `ixPersonOpenedBy`, `ixPersonAssignedTo`, `nDeleteSPAM`, `nDeleteInquiries`, `fDeleted`, `fAutoSort`, `fAutoReply`, `sReplySubject`, `sReplyMessage`, `fDueDate`, `nDue`, `nDueTime`, `sLastMessageDownloaded`, `dtLastChecked`, `nInterval`, `fTrialMailbox`, `sAliases`) VALUES (1, 'cases@catfooding.fogbugz.com', 'FogBugz On Demand', '', '', '', '', '', '\r\n\r\n-- \r\n{fullname}\r\n{email}\r\n---------------------------------------------------------------------------\r\nPowered by FogBugz from Fog Creek Software. http://www.fogcreek.com/FogBugz', 2, 7, 1, 3, -1, -1, 7, NULL, 1, 1, 1, 'Re: (Case {case}) {subject}', 'Thank you for your message. We have received it and will get back to you as soon as possible.\r\n\r\nWe use FogBugz to keep track of our incoming email. You can check the status of your message at the following URL:\r\n\r\n{ticketurl}\r\n\r\nYou may want to save your case\'s tracking ticket: {ticket}\r\n\r\nPlease reply to this message if there\'s anything else we can do for you.\r\n\r\n\r\n--\r\n{fullname}\r\n{email}\r\n---------------------------------------------------------------------------\r\nPowered by FogBugz from Fog Creek Software. http://www.fogcreek.com/FogBugz', NULL, 0, 0, '', '2000-01-01T12:00:00', 15, 1, '');
SELECT 'Imported Table Mailbox';
SELECT 'Importing Table MailQueue';
SELECT 'Imported Table MailQueue';
SELECT 'Importing Table Notification';
SELECT 'Imported Table Notification';
SELECT 'Importing Table PasswordResetCode';
SELECT 'Imported Table PasswordResetCode';
SELECT 'Importing Table Person';
INSERT INTO `Person` (`ixPerson`, `sFullName`, `sEmail`, `sPassword`, `fNotify`, `fEscalationReport`, `sVersion`, `sComputer`, `sPhone`, `fExpert`, `fAdministrator`, `fDeleted`, `sFrom`, `fGridView`, `ixArea`, `ixBugWorkingOn`, `sVersionSeen`, `sContractSeen`, `sPasswordVersion`, `sSnippetKey`, `sLDAPUid`, `fMostRecentEventFirst`, `fCommunity`, `fConfirmed`, `fVirtual`, `sHomepage`, `dtRegistered`, `FILTER_fOpenBugs`, `FILTER_fClosedBugs`, `FILTER_ixProject`, `FILTER_ixArea`, `FILTER_ixPersonOpenedBy`, `FILTER_ixPersonAssignedTo`, `FILTER_ixPersonResolvedBy`, `FILTER_ixPersonClosedBy`, `FILTER_ixPersonLastEditedBy`, `FILTER_ixStatus`, `FILTER_ixPriority`, `FILTER_maxrecords`, `FILTER_sort1`, `FILTER_sort2`, `FILTER_sort3`, `FILTER_ixPluginSort1`, `FILTER_ixPluginSort2`, `FILTER_ixPluginSort3`, `FILTER_fDescendingSort1`, `FILTER_fDescendingSort2`, `FILTER_fDescendingSort3`, `FILTER_ixFixFor`, `FILTER_openInLast`, `FILTER_priorityRange`, `FILTER_sentBy`, `FILTER_sComputer`, `FILTER_sVersion`, `FILTER_resolvedInLast`, `FILTER_closedInLast`, `FILTER_dueInNext`, `FILTER_ixCategory`, `FILTER_fFlatView`, `FILTER_fNoParent`, `FILTER_fNoChildren`, `FILTER_fMissingEstimate`, `FILTER_fSubscribedBugs`, `FILTER_fSeenByMe`, `FILTER_ixGroup`, `FILTER_sFilterName`, `FILTER_sSearchFor`, `sLocale`, `sLanguage`, `sTimeZoneKey`, `dtLastDailyTask`, `dtLastScheduleMaint`, `dtLastActivity`, `FILTER_sTags`, `bfHelpTips`, `cFailedLogons`, `fRecurseBugChildren`, `fPaletteExpanded`, `fPaletteModified`) VALUES (1, 'CLOSED', '', NULL, 0, 0, NULL, NULL, NULL, 0, 0, 0, '', 0, NULL, 0, '', '', '', '`', NULL, 0, 0, 0, 0, '', NULL, 'ON', 'OFF', -1, -1, -1, -1, -1, -1, -1, -1, -1, 0, 0, 0, 0, -1, -1, -1, 0, 0, 0, -1, -1, 0, '', '', '', -1, -1, -1, -1, 0, 0, 0, 0, 0, 0, -1, '', NULL, '*', '*', '*', '2009-12-18T06:00:00', '2009-12-18T08:19:26', NULL, NULL, 0, 0, 1, 0, 0);
INSERT INTO `Person` (`ixPerson`, `sFullName`, `sEmail`, `sPassword`, `fNotify`, `fEscalationReport`, `sVersion`, `sComputer`, `sPhone`, `fExpert`, `fAdministrator`, `fDeleted`, `sFrom`, `fGridView`, `ixArea`, `ixBugWorkingOn`, `sVersionSeen`, `sContractSeen`, `sPasswordVersion`, `sSnippetKey`, `sLDAPUid`, `fMostRecentEventFirst`, `fCommunity`, `fConfirmed`, `fVirtual`, `sHomepage`, `dtRegistered`, `FILTER_fOpenBugs`, `FILTER_fClosedBugs`, `FILTER_ixProject`, `FILTER_ixArea`, `FILTER_ixPersonOpenedBy`, `FILTER_ixPersonAssignedTo`, `FILTER_ixPersonResolvedBy`, `FILTER_ixPersonClosedBy`, `FILTER_ixPersonLastEditedBy`, `FILTER_ixStatus`, `FILTER_ixPriority`, `FILTER_maxrecords`, `FILTER_sort1`, `FILTER_sort2`, `FILTER_sort3`, `FILTER_ixPluginSort1`, `FILTER_ixPluginSort2`, `FILTER_ixPluginSort3`, `FILTER_fDescendingSort1`, `FILTER_fDescendingSort2`, `FILTER_fDescendingSort3`, `FILTER_ixFixFor`, `FILTER_openInLast`, `FILTER_priorityRange`, `FILTER_sentBy`, `FILTER_sComputer`, `FILTER_sVersion`, `FILTER_resolvedInLast`, `FILTER_closedInLast`, `FILTER_dueInNext`, `FILTER_ixCategory`, `FILTER_fFlatView`, `FILTER_fNoParent`, `FILTER_fNoChildren`, `FILTER_fMissingEstimate`, `FILTER_fSubscribedBugs`, `FILTER_fSeenByMe`, `FILTER_ixGroup`, `FILTER_sFilterName`, `FILTER_sSearchFor`, `sLocale`, `sLanguage`, `sTimeZoneKey`, `dtLastDailyTask`, `dtLastScheduleMaint`, `dtLastActivity`, `FILTER_sTags`, `bfHelpTips`, `cFailedLogons`, `fRecurseBugChildren`, `fPaletteExpanded`, `fPaletteModified`) VALUES (2, 'Tony Atkins', 'duhrer@gmail.com', 'm357p5jlc30f81aea078c4457b4f8d9051384b0b', 1, 0, '', '', '', 0, 1, 0, '', 1, NULL, 0, '', '', '600', '`', '', 0, 0, 1, 0, '', '2009-12-18T09:19:33', 'ON', 'OFF', -1, -1, -1, -1, -1, -1, -1, -1, -1, 50, 3, 11, 8, -1, -1, -1, 0, 0, 0, -1, -1, 0, '', '', '', -1, -1, -1, -1, 0, 0, 0, 0, 0, 0, -1, '', NULL, '*', '*', '*', '2009-12-18T06:00:00', '2009-12-18T09:42:03', '2009-12-18T09:41:57', NULL, 0, 0, 1, 1, 0);
SELECT 'Imported Table Person';
SELECT 'Importing Table Plugin';
INSERT INTO `Plugin` (`ixPlugin`, `fDeleted`, `sPluginId`, `ixSchemaVersion`, `fEnabled`, `sFilename`, `rgbFile`, `dtUpload`, `sVersionLatest`, `fBlacklisted`) VALUES (1, 0, 'filterexport@fogcreek.com', 0, 1, 'hostedplugin.zip', 0x504b030414000000000052a28e3b0000000000000000000000000300000062696e504b0304140000000800979e8e3bb478e78937220000007000001400000062696e2f46696c7465724578706f72742e646c6cedbd07601c499625262f6dca7b7f4af54ad7e074a10880601324d8904010ecc188cde692ec1d69472329ab2a81ca6556655d661640cced9dbcf7de7befbdf7de7befbdf7ba3b9d4e27f7dfff3f5c6664016cf6ce4adac99e2180aac81f3f7e7c1f3f22bef8a93fe9d7f8b57f8d5fe3d7f875e8fffff7fffd6bfc1a7fd7af21cfefa93f373d7f10fdff37f95dfe9edfe4d7f8db7eec9fff5dffae5ff3f93fffbbbe99174dbaaaab8b3a5ba4d36cb9acda7492a7f57a9916cbf4e997afd34535cbc7bff16f9cfc6e0ae3e5e9aff16b3cff357fed5fe3cffdd3ffc5ef18b8ffd1aff16bfdaebfe1aff91b0812a97cf60ffc3efafb1f80bf7e4ff9fd3713bcf1989fbfc65f249fe3f9b57f8ddff30fe73ff86ff3d3fee0a724b85fe2973fe0d7f835feaa5f5b3ff49f3fe8d7f8357e23faf13ffddebfc6aff13b45be1e7cd25fe3d7f80dbc3f7f03fafbdbdedfe3367fd7d2cf7feca1b4e5b1fe665e03f9f80f18d74d3dfd3514b73f40dbbc0cdbfd9ef4bf719d97d55470fd35fe206d87f661bb27e1273f7a7ef4fce8f9d1f3a3e747cf8f9e1f3d3f7a7ef4fce8f9d1f3a3e7e7cbf317fd3ef2f3dbf4ff5febd7f8757f8d7f6fefd7f8357eab5ff86bfc1abfa67eff47edfe1abfc62bf3c72d9edf72e7d7fa35e815bcff9bff1abfd52fa51fbfcefff56bfe36ffd7aff91bfefadbbfedafd15094feebfd41f88cbfa828a6fdf57e8d5f837f4f3ef9357ebd6f7df46bfc56fcedb7925fe35bbfe0d7dafa4d7f8d5f23a1cfb67e2d34c307bf193e401fbf0ec7ecf4f96ffe6bfdda5bbf397d4a4827bf564defaeb67e0bfab3f92de99f5f42dfff3abfd66ff34ba8975fa7fedde9abe4d7dba216bfde2ffeade8cbeab7a67f04afdfe0d7d8fa6d18c427bfc6b708f6affd6b7cfe6b207700fc93dfea37acff9581377fe31f736ffeb67f3cfdf36bfe96bfce6ffeebfc36bfd616fdfaebfd25bff9aff31b7ef26bfcfabfd127bfc66f0098bfeeaff1e7fd1a9ca31098bfd56f54bff835e35001c3c11560bfe1afff3bfef13f0ef8bfee6ffeebfe36bffe2ffe6de9abbfe437ff757fdbfa9f2118f4cb6ff76b6dfd76f451fd2fd09fd56f2f5ffef6f57f205ffe0ebff6d6ef201f6dfd8ea0095e566c7fbddffcd7fb6d7efdbfe437fff580e46ffcc9aff163df025d6bc2f3d7b563ff4f06b0f4c72ebd57bf13fef99de99f5feb1783eef58b5f8bb0f905f8db7d5fff343efc5de8b7ad14b3f4bbd23f8e4c3cafbff4d7609ed0feffa05feb16fdff624cb07cf8d9aff13bfcf1bfa19d89dfe577d8fa4d642e7edb5feb77f99dccefbfddaf657ffded7faddfe5b732bfff869ffc3abf5580cbaff76bfcf5d4efafefe6ecb7f98d7f9bdff2d7f96d7ecb5ff7b7f92d7fbd1fb7ecfeebff56bfe56f50ff0f0368fe96c96f9e784cf2ebfc16bfe1fff55b53a3dff137ff0db73ea28f7e6f9ed5dff0d7aee847f2bbfc0e7fdc6f4c7f6d51622c6189e1977fcb5fa3a169fbf57ead2d9ad75fef37fa350efe1874aa2ffc4eb1177eb35fa3f905fcc2efc42f7cf23d6d3dd4f877e5c6bf8b34de36a07fab58ebdfe4d7687e376efd11b7a6e7b7f92d13faffafd31dd76ff9ebfeb6c45cbfce6ffcc94ffe1abfc1aff3637f4ef5bbe3b35fff37fff54b4bb6ffebd76688bfd1aff1ebff583dffb589517f8d4f7e37fcfed3f4fb6ffbc7ff5a98c1dfe837ff8d7e9bdffcd7ffe3682a7ecdbfe437ff8db67e2198f8d7f8357eec37fff57eefdff8c77ef35ff7fffab50c567fdeaff1ebff96bfc127bfc66ffe1bfc963f46fffed8b75407fd91bf06e7df3077bfcd6f58ffccaf7d1b69fb6d7ea35ffb37fa0d7e97df41468c6f7edd5fe3b7fd0d3f39fa357e83dfe577ea7cf6ad5fe337e87ef4db52b3dfaaf3197276bf3e8b16f3f65f447ffe98e3a7dfea37ae7ff9105e24e91e87ffda5b341dbf1e7ff8ebfe1abf15d15565ea63fae7d7aeb62045de27d51dfae737fa0d7efd8a6861a4f1a77f1d95c6ad4fd06204b8d402935d6df31f40f3b7fc758884bfceb740bf935f83bb5639fcc37e9d5bc8a16030c63f777f0d5fb0fbf0fef70f86b74ff07e433bbfef7edd9be1fd7616c0ef4873f1dbff5a9c2b157c7e1b92eddfeab7fc757eabdff2d7fdad7ecb5fefb76299fead7ecb1fabffb701a8e04d0fcfdf962d8cc177e7d7b02a6ff7d750ad2c44dfc3207eebdf68a05dfdebf9ed7e8b5f6beb1efdf885bfbeb0d46ffc63a6db5fe7d7f8ad7fa35fe3d7fa0db67e4b30c4af633ffe9d4df76080dffcd7f9f57fdb8a084482f86b1cfcc190b7dfe0b7118141d3dfda34bd4ffffc06d5a768f7ebfd1abff9afa7cc8b26bf95dfa47a605afcb6d501464c66a37a28bffcb6d523f3097f152081af0f058b5febd7a23f7fddea31fd05aa910e217afe7a5bbf3506f1ebff1affc14f901e5146fdc37e3d65d45ffa99f9e7374faa23bcf87b00d66fa05dfc9ea0d99f84c6c7e878eb091afe06d509dafcd87f706030e1667f0535abff05b47dea21c95ffd26bfbe81f09bfffa5020a4417e4be293dffc37841e39fe9d40bb5fe3d738a3ff7f465cf047d0ff7f827ebf0ffd4436fdb7a0bf7f639f87c43e100fd5e9af3fc03abfc16ffe1b38d6f9ad7ec35f5b27061f5baa8b589fd2bfbfe1afa10cc00d1e9b06cff0cfe7f8e7dbf4cff66fe10b3f219b7cf29bf99f7c8701fd36bfe56ff06bfc36bff1afff5bfc98aaea1f1355fdebfcb6bfe5affb63bfd127bbbfc6aff5ebff067f4ef57b81ced035a6cbdff2d7f8f57f03f70d9b4ae2a6dffcd7fdbd7fa3dfe037ff751ceaff3029e15f8fc846b349fffefa6c3f7fed5fe3efa18e7e938e8cd57fdc1065c840f484bf2b24fffbaf1f08d3afbff5dc7b9970ddfa0268bee0811d7cfa6b0ec2f98d7e031f4efd11fe248f321912ce5f18b6df31ed219aa4357efdad97e892f473bdef7dc558fdc6bf46f31382cf5f015ea226bf67a4c92b69f2876a93ef749bfc86bfc68f35afb9cd27133478631a6cffe6f4d71fe035ffe4d7fc6df88ddfe8d7f80d7eac7923afdcc52bab2e4c6ef195b4f88dd1310b91d80099cd6f891ff48fd077bfa96fb7308f3ff31b0ccc23b9956e1e7f9d5f9b45f237fc75aa9f04797fdb5fffb7f8f595ff7e7de6bfdfa0f3f7effddbfedebff71f4f42ff6bfec6bfc18f75bffb6d7fefadef02e8afffdb44beea02a6c6bf371aab4dfb2d7f5dfaf7d7e5f1fcbabfc6dff46bf2f258c4af23d2919cfc36bfe58f9167f3dbfc96bfe16ff35bfe46bfcd6f49dffe26bfd56ff99bd6ffd5d0807ff3dffc3777036e7e1f0c77eba7d0e07bf8e7f7c5b87f9bdff23787a3f46bff16bf8522f95b848ed2eff96bfcfabfd6aff56bffd89fb3f5db422d12dffd7ad5f7e9fb5ff863dd37b43b22c26f202dba2e11befd5b7e8d5fff97fe7ee89b5b48dfbfc1aff3db36bf3ffd29fdfed86f4bbed36ff05bfefac270d2e237fa757e3bafc56ffcdbfe96bfc96ffe1b912e046abfce6ffeeb936bf707e04b87db6ffe1bfa2f4410fbcd7fc3dffc37f9bd7fcbdf907efcc60eb7bf39c08d74c56f9efcdee0c6dffcc76c9b476fff6f5a89fef559e9ff96bf29cddb6ffa5bfe66f4ef6fc67e0974f16f6efd88173f76b3ddffb5ab8c7e8e7e03f9f9c9aff76bb35fe4b9fac4133ff66bfc807efe1616eedf770bb8f52f4cacb38a70e3d7aef7e883fa53fae7b7faad7eabad09354aff2282fac78de14a4fe9cffab1f71d851c5bb31011e8ccdf1ef8008f5febd7fe25bf0ee2d7ffebd7fb1d088b26a7a61c23ff1ae2dffe9ef4f3b7127cad57fd1bd6bf677233debf76754e3fcbdf50866fa2ea6edfbfaef4fd3bdfbeef7ffe567d5fdca2ef5f4ffa4e637d63fefb7dffd46f789bbe79dcbf7635c78fdfa78b04c30ff1f8f5058f1fbf3d0dfecb5be1c10874baa77cc0aff12ffc33ffe33f403f7e8d3f99fe5fbebe6eda7c317e9537d5ba9ee68dfded559ecdf27a942e9a695597c56494fe645e3745b5fc6c6fbc83ff46e9c9ba6cd775fed9325fb775568ed297eb49594c7faffcfa4df5365f7e3679f020bb3fbdffe9eec37bfbf9cec1c31fef77b65eb6c522371fbcce5be2732445f87979fc14fffbfdfefe5feb2ffdf77e9b5fffeff8f37ffbdfec372226878de0e7b7a54124a7bfc62bfaef4bfa3f9edfe1f4d7f8bd7f8d97fce79b5fe3f7a7ff7f49ff9efc1aaf7f8d9ffc35e064fd76dfa60fbea22f5fd3c7afe9b767f4df19bdb24d5ffe9abfc3f132cddf4df3554ba34ce7599356d3e9baaef3d9f8d7fc4d4fdfadaaba4ddb2a3da526e5aff91ba4dbe9b709e9e6d7f8359ebcfece935f533359bf11fdff1204babff360ef013ef9757f8d92fefd977e835fe3d7f8f15ffa6bfc1a8f7fecd7f835fea2df907e7fddd6c5f2a2418b7f8fa6b0a5177ffcabd7bfc6cbdf956dc6aff1e39f7f75f6947efe01f4f7df4602fae34fca6aa2e3862af8ee6ffb97fcd88f814efffbaf79efd7f86d248f76fc6b702c8a5cc2aff1bbd1ff7fc75f837341bfc6fcd760ff087cc4edccff7f6dfdf9ebea4fb405ebc8487ebd5fe3dffe35fe19faeb97ff1aff3dbdfd3bfd9abff6aff99bfc1a9fff9a3f4efffebefcef2fe27fff18fa97dafc9aff29fdbef76bfdd6bfd66ff26bbcf8b53ea37fffda5feb8fa57fff51fef7dfe14f3ef9b5935ffb37f9357e9f5ffbb35f2bf935feca5ffbcffdb57fbd5fe3bffbb5ff19ca81fdca5f1b1af123526dbfc5af7142ff26bfc62ffe750afafdcfe24ffe61fee4bfa44f925fe3d7f975f1efeffcebe2dbfd5f179f9fffba3ff9eb26bfc65ff8ebfe71bfeed5aff1b7febac0fd3ff975ff11fae4d7faf5f06ffaebfdf7f4c9a35f0f6ffd01fcfbead7fbe37edddfe6d7f8bb7fbdbfe1d7fb4d7e8d7fe3d7fbad0993835fffbfa7919efcfaff0cfdfb07fcfa18efd5af8ff1fe09bf3ec6f2eff3bfbfd56ff06bd318cf7e037cfe7bff06184bfb1be0f33fe637c0e8fe7afae4d7fb357ee31ffb67e8dbdffdc7d072f96368f967fc18dafc753ff6c7522fa3e4cffdb50913fef773fef70dff3be37ffff804b8fd29fcefdfcc9ffc6bc93f9824bfc62fa37f3113321fc261bf19cdeaef463386bf7ecd5ff337fb359ed05f3fc619d55f93befb09faeb37a6bf7e7dfafb37fb35c8fed1771483f25fd7fcd7af4b7280bffe34feebd7fb357e17feeb6fe4bf7efd5fe32352347fdeaff93b11ac5fe7d7daa37f7fecd7fa94fefdcf7fedbf33f2efcb1458fd19bfc15ff16ba6f4c91f2f7ffd1a7fdbaff9bbd35f7f06fff587fe1a7fdfaf7987fefab3f9af3fe2b7fbe7f9afbf585bfefbdcf2af09befbdbec5f0f319edf157ffd17bfe64ffd5abf078d69a67f2d7ead67c4b9bfd147f8eb0ffe35fea05feb0b1ae11ff7917cf777fe5aafe8afdfeec7e5af7fead7fabde9af7fed779396fff5af35a511ce7f77eee1d7f8df7fad8264051968b4bcff6baf68fc33fdebf4d7bea299f8dbf4afe2d7fe8388a6bf5cfffaa5bff61f4e7f1ddc11987fd2affdc7d05fbff7b7e4afbfe9d7fe9369ded391fcf5f7fdda7f06fdf53fe95fffe4affd17109dffbab1fcf52ffeda7f1df1fcaf7357fefa777fedbf856cc11fc77ffda1bfc6aff5ebfcbd24a97f9b7ef71bfe3affe4af41ca7d87b1662afd36bfc66fb0e35afe36bfc60eff252d7fdb5fe367bc96bfddaff187792d7fbb5fe3aff35afef6bfc6afb9eb5afe0ebfc66fb4eb5afe0ebfc6feae6bf93bfe1a7f90d7125af4d7fc353efdf5f0ef1fc8fffed1fcef8ffffad04b1ffffad02adbbf3e3ef9c3bd7f7fdcfefb6bfd1abf8adbfcbabf013e79f763f8b74ef0f9bb04bffff9fcfb5f99b8b73efd0df1ef7ffe6be3df57b7fafdd7212ea6fc0573feaff36bfccebfc69ffd6bfcf3bfe6bff16bfcc5fcef5fcdfffecdf4efbffb6bfcddfcef3fcc9ffcd3fcefbfccfffedbfcef7ffc6b60bcff35fdfb1ffd1abf8a5bfe9abf263ef931f997bffdcdf9dfdffed700bffee6bfe6c9aff73f930efee77fcd5f49dffedebfdefffd6bfcf6bfe6c5aff76bfd9abfebaf79fdebfdee24997f323ef935fe8c5fef77f835cf7e8dbfe0d7fb5b7e8d3bbfe63f4e16fcb7ff35ffc55f6f9b3ef90f7ebdd35f73f7d7fc2f7ebddfebd73cfe35fe77fa76f7d7fc757e7db4f9ed7efdad5ff32708e697bfe6f1aff9e5afdffe9abfcfaff193bffe1ff86b9efd9a6f7ffd3ff4d7fcad7e8dd5afff2711845ffaebff9904e1cffcf5ff895ff3f7f935ffa25fbff8357e9f5ff36ff8f5ff396af90ffefabf17c3ff97e9f77ffad7ff377e8ddfe7d7f8577ffd7f97ccdd7ffeebff67bf66f66bfef7bffe7f436ffdf86ff06bfe5a67bfc6dddfe0f7fa358b5ff3f7fc0dfe16d2ea5ffe06bffeaff5fbfc9a93dfe037a1cfffc0dfe0b7ffb5fee05ff34ff90d7e17faf7cffb0d7ee1aff527ff9affd06f30fab5fee85ff3dff80dfedd5fe38ffe35ff73fafdf7f9357fd96fb0fb6b5dff9abfee8f1dfd5a7ff6aff95bffd8ff4d34f99d7e4cfafd3641b8ff632f7fadbff8d77cf263ff0671d3ab1ffbc95feb0ffe35bef763dfa34f663f96d1bb7ff08ffd3184cf5ffc637fc8aff537ff9a7fdb8ffd51bfd6dffd6bfee33ff627d0e7ffea8fbda251fc17f8f7d7f8d53ff6a7fc5ac7bf6692fc8dbfd62ffa357fabe46ffbb520677ff7aff5dbff9abf43f20f528fbf30d9fa35ff619e917f9afffd97e9dfd1aff56fd3bffff8aff51ff3bf7ff0aff107277ff8aff13fff9a7f56f26ffd5af8f73ffdb57e15b7fc357fadff28f9757fed5ff3d7fa3f92dff0d7feb15febc77ec3dfebd7fc55bfe6eff81bfee6bff69ffd6b7ef41bfedf64c7fff95ff3b7fbb57fa75fe3e3dff017fedabfcfaff1097dfb67ff9a07bfe14bfaf6f7fc0d7f8afe3dfd0dff4ca2ff3fff6bce7fedecd7f8c9dff01dfd9bf3bf2dfdfbbbfe1acdaff15ffc1ae35fe31ed9b63149f6df4efffe8ebfc6bf45fffe38f1e898d67ffe07faf737fc35fe50faf7f0d778f8eb8cc943f909faf7f7fa3566f4ef6b7ef77bbfc61f4abf4f7f8d3f8efe7dfb6bfce9bfce7ffb6bfcfabfe66ff46bdefb357ff2d7fcfd7fcdbfe0d7fcfb7fcd7ff3d7fc1f7fcdffedd7bcf8b5fecc5feb9ffdb5fea75f6bf46b9ffddabfffafbdfcb57fe6d7feb57e0d58897ff5d7dcfe35f0dbaffd6b2c7ecd3fead7fc05bff6aff307fd1a9de7277e0db1ffbf81fefd6b92adc7f36be9df78925fe33fd3efdcf35bfe1abfbaf7d93f4f812f7efaeffe2ebfe6dff0eb99dfd1f60ffd0de167fc3a64717e1dd2c2bf0ef52bdec6aff1f88b6ab62ef3a35fe35951b6792d6ed6785696bfc6effffb7f4e3e4f56fe1acfaa8b933acfdf8e5f96eb8b62d98cfda6bf86343a6e9aac698a6500e6d7789e2d26b3ecf7ffbc2e662755b95e2c9f16cdaaccae7fff9de1af7687bfda1bfeeadeaff1ddacc92685f16815ad271979f4c683fe35c4fdfd35be9cfc743e6d31ac27eb8b1fb8e1e9076698bf86fc1cfc7e7cb6a4919e67e447ff1a67f2990cfe4d559593ac361fbeceb37a3aef7cf8a45866f5f5cbec22d711982fdcd06802d8fb5db6bfc645defefebfffef7fa27ffdfebfffabd3d7a76f0252fffe5759f36b8ca76d55ff1aaea134eb3afdbf86f9ed8b6c49fdd7bf46992d2f7e8d7387d1f0888f57c5af71227fe0d76ebb5fe3c41140b1d3619f1106cdaf1150423e12ece585a15e4f6946dbeb5fe3c4238dfbb5f9354ea8b1f781a1a7fbe4cdf52aff35ce9a57397d3ecd2d88bc950ef4ef5ef74fb3369b10ffd8fee9d39f58e7b50fbafbf76b1a8c7cf632af17458378ed797e9997bf8623ef4f164d31294a80ec73016165c6a5f3f6267fd7fe1aa7cb6935a37805dfdbdff9979ce89cff1a27cd2590f83574c0452b9f4990431cd1ce8be6d778b65e4e115a41a4f5d73f600fec52e7599b83add61e198c149064e78b49796dbef86e3e698a363f6e09f6644def751b9c2eb2a23c9ecdeabc695c2bcb85e765ce5dbbf768001ada0e03fda25856b5b6a2df3734cc7eda36ecb77a9a37d3bae000b3ffe549b55865cbebfe174ccfe12e855267b3de605fe724c098e7e3b2acae5e66755b642581abd7f4f5ec847e273c7b6f3d2db28b65d5b4c5b4f9359ee693f5c54536f1bb97cf685e4973e7964d54ef8d31082268fd3aaf2f0b48bb7c9061c8aff2327bc7bf79bdea8b3cf85619d37dfb664ecc317bddd25753f76946c26fa8c02cf98e46da124af6c3dfbf61347f0de5c0d3e5acf96ed1ce1579523a4f08eedb5fe31c5cfb93457ef56b34a21c7e8de6abba647dc77dcc6642dc97757e5ebc33632516fc35beddb6abaf5a11237a45648106bb9c66edaf71429f4041010ee075752e3e23b4153955d33c463023befd76bb289fe60c734abaa9864af835ce5f9659b164817cb12e4b4ccb1fb0fb6b9c2dcfab7ac164fd35be7a52ad9733eeb760b543085d0a33fe1a27cfa9afb3e525a5667e8da715656aa068f1e2af011524ad410e83380bf48bfcca537b22a9de0768d7bcc8c8de35c16fda39216da0017f026675d83944215fb222393f5b4ecbf58cd23f904da3e15fe5bf689d37627cfcdf8319c107d0e434b0f6dedeaff106f4adc9e69e3c2f9a962716d8cadc1a1da756c260267f994f312fee37b564a6c9cbba7a778dc4d897cbf29a6d3b067b46e252e74ee136fce9227b57d304d633f9f3fc19c9804548007a4a17ca5e99b5f9352e2727f5f3f35fe34da50c6209d2ac087aae14d13f009c66b9253499e8cc736f9e1d00ea93eb962490b8f8db9cccfb3590ba62e5f36b14efcc209d25236eb003259ea9d8c632c5f92ff3a94717fd006d9c2479109fe6e719e5083b9d786f0506f2c57a91d7c5f4d79019ac56bfffe92f5a672c60cf4f40ebe3d7276767d6fad0181ff87f1cb83f960504c7fff2de9efdab6183957b068d5889dc3afa10e4fa358eeb1a3c52adae49ea8c2dac2fea8bc69ba327eba20441552188b357fc408450d3a2904b19a4104b3ffe3520bff6bbe00ff0eceb7c95d519fca8e3d58ae48398815881b0145913d30a1f8a9d895fe3645e7f57c55899055a0f4de775838e4f556ae8cf2febe2c2fbf3b4cc564d3e0b1d6ff862e3daba6a94787cf66b1494c16c7f8dfcd720fef935defd1aab5fa3a2df5a8a51ca5f23fb35681a7f8d5fe30ffa6b9f515ef5730a635e5193530a64c694847d4ef9d5cf29bc7b4121cd98f3accf29217bca6d5c9276f337df3cd45fe317ff6c400dbf41daf94bfaeb09a5035ed1e7f8f40b82fcb3d5f76bfa1b3d9dfc1adf1eeefbd7a60cd66f4ae69a2632a3099c222dfc6b7ff66bfc1a6f7f7670f2ff3238fd1abfe3707afed7f8adf380b92e88ed682165f1b383dde74c9ba704f74b86f605c3fa35ae7f78bd3da54f5e33f4634a72508cfc9bff62caf23da2ff234df0e3bfc62ff9357e8dab9f1d6cd02f3e93be4fe8b710b35f63fdb3d3efe7f4f79b0052d0eb6f3fb436f3b3874f7f567e827ea225cdc82ff9e1f5fa5abff57aff037f767a7fc26f1f731f2fe927e6e4279923cef8bbe7bf0634c6eff3b32609b1fe3b92f09b17a4077ca3f36bfc8680a36b7cbf353e7b47dfdc255d0103549009fa353e3e21bdb1e4f6f8779b60166424a14d1afaada5ffe3fb5ff3f7a0041dfd97b1f65b68ebc35f23254d83fef077c69f7f166080441c7965849beb5d3ff959d29e222b1dedf4b3a60b4ff97391c7a70ceb731a2ba83125bacd98c664e67feb739a3ff208a9ed923f85f9ff357e6d5a1df8317cf325e1f96bfcda3b345f19d1664adf17f4cd9aa875fe6b3cb0bf1dd0f7f2dbeeaff12959a435c128b49fdc7e77efd7d8fb59a3ad1be9a9b63afd357e8dfc67a72fb16d46e67fb666d0e793372cc13ca6e267ab378ce935fdfe8ae110affc861ffd1ab05ebf8416107f8d5f9bfeffeb7ec4bfa5e41afeb13f3b4840597c414cf7947efefe51a51aaa95df1f4b68ffef4166f7ff4dc8ecfdbf09997bbfc6aff1e22ffccfffa65ffd6ffd66c77ff5bff21bfd4f3ffe377efce3bfc66f90defb47ffd8dfe17ffa6bfff7dfe0effcc1effb93bffdfe7ff447ff067ff57ffbe6ef59fc293ff5efffdabfde6ff11bd04ac26ff11b60ed8f18eed7fc757e03fcf1ebfd16bfebaff5ebfd5abf6efa6bfe9abfc5effeeba5bfe6effc5bdcf9b5e4c76ff2eba4bfc66f71e7d74d7f8ddff9b7d84ed25ffb77fe4d7e8beddff9b7d845cb5feb37bf4f4d7e8b6df9f1f0b7d8fe0dd25f1b3f7ead5f8b5ef9cd3fa37f7ee75f97616cff068071fceba7bfd6effcebfe26bfc5f16f9cfe5abf097df85bfd26bf161640081081fc75e8dfdf8490f8cd7ec3f4d7fcad7f8bb35febb7d8fd8d7f8bdf8cbefa8d7f8bdddfe0dffaf417ffd5977feeaff9d7519b5ff337c13fbf01d0fccdaf7f1d2c93fcbabffeaff55bfc06bfd6af4b03fa83fe68ea8060fd417ff4aff5eba1d9aff59bfc3abffeaff59bfc5abff1afffeb526f773020fa3f10f9dd7f83bfe9f7f8fdffc0dffc5f4f1efd3abf06f5faebd23fbff36ff29bfffabffe6fc2adb821dea021ff167fd09f4d14fa4d7ebdf4d7a676bfc96ff0ebff3ad484be169044866d02b9fdebfdd6bff91ff4e7ff9abf41f26bfc5abfc1ef24bfd23b44e25ff337f89d7e7d1d0a51e1b7fc357f4b5acaf9b57e93dfe477fe9d7ec1afff1b5387fad56f40cf6f4cfdfd26bf96bcfb3bff4ebf014127d2fe5abf1623f0d703e3ed5f176ffe26bfd1afffeb11a9e43ff9f66fc6b70f19b187bfc5c35f0bbffce69ffde69fc9977f3bf5f76bfd26bfd96f40b3f65bfc417f3f61fa9bc8e7ff30a6eb0ffac77f03fee31f07417faddfc834a10f7ead1f4b7f0d9d1b5a77fa4df070cb7f195c734ca4a749fc7541e9dfe477a081fc26bfc1afc5affdfdf4267df13bffbabfc51ff4afffcebfae74f46ff3bfff3e918339e2fe6ffbeb27a01b86ace4933113ad7eaddf0904c35cfc16c7bfc1af0bbcb98f5febd7fa8d7efddfe037f94d7ead5febb73826c6f9b5925fe3d726cc7f15fdef37f88d7e8d5f17bffe06f8ff6ff05b51a3dff9d735ff2954f0c41ffc6b02853ff8d7e511ff9fbf09f8e6b7fc357e7dcb79bfd66ff21bd024fd96bf09befb0dbce73731b3f1ebfdfa20c0aff563bfc6af0732fc4ebf13b0fc4d7886e8d3dff977028abfd36ff763bfbe61591ae96f8c577ee3dff8d7dafd357f8dd19c329e8feedebdbaba1a9f5717534ed24fabc55d5dafb8dbac579c429853eaf2d7f8353efa357f8ddf794a79e68a723adb8d24837f4fffbd5fe3d7f88d7ecd5fe3d7df1defd17fa49b7f03b3a2f81b60d912cff1aff96b3c96ac44dacef3744a29a026a53cc7744e698ef49a3214a9ae4fa5e79cc248db2acdd293d73f89bff3f1aff16bfcb6bfe6aff15b1076e909fa4c5f57e7ed5556e744c85ff3d7f88d25eb91ea42e1aff10b7ecd5fe3b71728397fd2419590faf57f4dc5ee3760ece8855ff3d778f36bfd36dfadb3d58b6a69336b94b0aeae1a6efbe7fee9ffe277f013eba2bf1ffdff3722eff6373afb357e8d57af9fbefefbfeef3fef1ffc63ff8b1f3bfb637e8bbfebc7ffd1bffa3ffe9f7f13fa7efae8f745deeaf7a5ae2989f383ed5f94fdbeba08f2fbe6efb2c5aacc9bdfd74fd6fcbe9362197c305ecd2604e74ffb7d9494f4fc0df83d757ffbcf5fe4b5fb357e0dcac5d54fcbf20bca30cb8a659ef3322c9efffb77ff35d2df3306e247cf8f9e1f3d3f7a7ef4fce8798fe7d7fc357e33faf7b7a3b8a3fb390ce74ee4733cdfa6ffffde7fc0aff16bbc14ff809f97bff63efd8b70f4f7a77f11802095f5250516bf3f072e086bf0fcfdbfcefff87f01ceafc5b07e2dfbf3f75038bf0eff153e14b053ab9fe474b9a48368958ad215e794acc0f3bbf15b6fe85b24421a4e479954933c7fd3aff337fd5a80f19a3eaf358dd287f4c7719b1dfbdffeaf31010d7e8d3f8dd250bfe6af81d4d6c226abb024e3afc2a4f4ff397d97520a056917ac0da5d41a9820c9257da6bfc635b55fd31b68879fb5c233a92f4974015a45ff66f47f09f35d6a6ccc23faf6aff15b5a9c563cee6ba2b224cdf03ca36f2ef86df490ff1a6fe9f7d7f4d93941be624a4abba7bfc66f42700c2d9e32de53a6d12aa0a19f864b8391834f7e030fc64f729bc67b779770ded3ff839e4f7f8ddf9cda9ff1b8d116c9bed2c37e78a56b469f8b27b4c59cf39cda5cf0dba0c48a6800cc2f88dec02ba5ff3fe7bebed4cf0bedcbe06ad28cb7eb739fc7f9923e47926c4d746a7ba3ed8ef580df39a616e0890571544958a6bdf776b8bdf9ff8f9e1f3d3f7a7ef4fce8f9d1f3a3e747cf8f9e1f3d3f7a7ef47cf843e1cbaff11b11987fe8e13700eb47cf8f9e1f3d3f7a7ef4fce8f9d1f3a3e747cf8f9e1f3d3f7a7ef4fce8f9d1f3ffcae7ff01504b030414000000000052a28e3b00000000000000000000000006000000737461746963504b0304140000000800979e8e3b1bf8ec9545030000e7030000110000007374617469632f6578706f72742e676966edbd07601c499625262f6dca7b7f4af54ad7e074a10880601324d8904010ecc188cde692ec1d69472329ab2a81ca6556655d661640cced9dbcf7de7befbdf7de7befbdf7ba3b9d4e27f7dfff3f5c6664016cf6ce4adac99e2180aac81f3f7e7c1f3f223e3f7b76f030fbcd7e8ddfecd7f895bf069edffde22ffdde1ff8a73ff8eb0f1fffa1ffe0c13ffe7fe77fec5f3cfb13ffde9ff94bffeedff30fff879ffc91ffe8c91ffb4f3eff33fe95d77ffebffdd59fff6fbffa8bfebdf22ffb977ff1dff21f7eff5ffebf7ffa5fffbf9b7febfffe83ffc65ffa47fe197fda9ffa97fc457fc95fffd7fcc57fd3dff057fe1d7fdb5ff377ff9d7fc3dff7f7fc097fefbff1e7fdedfffc9ffa4ffd497ff33ff4f7ff11fff0fff0a7fca7fff79ff99fffdf7fdb3ffa0ffd9dffc43ffaf7fc53ffc4dff7cffe53ffc03fffcffe7dfffc3ffff7ff0bffc23ff02ffe8b7fedbff63ffec3ffe23ff78ffc4bffc23ff42fffcbffc8bffaaffea3ffdabff68ffd2bffd23ffe6ffc1bffe4bff56ffd8bfff6bff14ffd5bffd63ff36fffdbfff4bff3effc73f4bf7fefdffb17fefd7fff5ffa0ffe83ffe497fdb2ffec97fff2ffe257fc8afffa7ffd5fffdb5ff92bff07fae557fdaaffe17ffbdffee75ff92bffe75ff5ab7ec5affa55bffc57ffea5ff97ffc1ffffbfff17ffcaafff3fffc3ffeafffebfffabfffef5fe347cf8f9edef3bbfeaa5fe7d7fc357e8dfffbd718e10fc8c4aff11bfc63bfc6db7feab7fbf6dff407fcc3bfc3f8cfd9fa7dffa93fe92ffe637f9b2f7ebd6fff79dffe89c99ffadb6cfd59bfd1fff637fdc9ffe9afff27fe4e7ff65f74f0373f9dfce17fead6ebf1c3eca37ffa9f48bef3a7fd737fd4affae8fc8ff9dd7ee177d2dd3ffa0ffdf5fec4df6ea7feeb5efec9bfd6d98ffd16cf7ebf5ff0706ffa5fffb17ff99d3fee4ffa358effb08ffff8dff9f7ac7ea32f8e7f9d5fe78f4ceffeb1bfd59ffdbbfeafa77ff26ff63bff21ab7febd7f8c7fe9adfe42ffaf4271fbffb87267fe81ff1bbdcfdc37f833ffb37ff877fcd5ffbd7ff4d9eedff9e7fd23ffc47feebbffd6ff8f4f99ff40ffd59bfd61ffc1b9efce0db7fc16ff4bbfec1fff9aff3ebfe56bfdd3ff407fcc57feb7ff92ffe36bfd6aff39bfd41fff15ff85fffab7fd517bfcbfff4073c4a7f8dc3ff07504b0102140014000000000052a28e3b000000000000000000000000030000000000000000001000b6810000000062696e504b01021400140000000800979e8e3bb478e7893722000000700000140000000000000001002000b6812100000062696e2f46696c7465724578706f72742e646c6c504b0102140014000000000052a28e3b000000000000000000000000060000000000000000001000b6818a220000737461746963504b01021400140000000800979e8e3b1bf8ec9545030000e7030000110000000000000001002000b681ae2200007374617469632f6578706f72742e676966504b05060000000004000400e6000000222600000000, '2009-12-18T09:22:22', NULL, 0);
INSERT INTO `Plugin` (`ixPlugin`, `fDeleted`, `sPluginId`, `ixSchemaVersion`, `fEnabled`, `sFilename`, `rgbFile`, `dtUpload`, `sVersionLatest`, `fBlacklisted`) VALUES (2, 0, 'wikiinfodetails@fogcreek.com', 0, 1, 'hostedplugin.zip', 0x504b030414000000000052a28e3b0000000000000000000000000300000062696e504b0304140000000800999e8e3b0e9aa9578d38000000a000001600000062696e2f57696b69496e666f44657461696c2e646c6cedbd07601c499625262f6dca7b7f4af54ad7e074a10880601324d8904010ecc188cde692ec1d69472329ab2a81ca6556655d661640cced9dbcf7de7befbdf7de7befbdf7ba3b9d4e27f7dfff3f5c6664016cf6ce4adac99e2180aac81f3f7e7c1f3f22bef8a93fe9d7f8b57f8d5fe3d7f875e8fffff7fffd6bfc1a7fd7af21cfefa93f373d7f10fdff37f95dfe9edfe4d7f8db7eec9fff5dffae5ff3f93fffbbbe99174dbaaaab8b3a5ba4d36cb9acda7492a7f57a9916cbf4e997afd34535cbc7bff16f9cfc6e0ae3e5e9aff16b3cff357fed5f63f68f7df73b06ee7ff46bfc5abfeb6ff86bfe06bfc6afb1a23f52f9ec3ff843f5f7bf087ffd9ef2fb6f2678e3313fe965fefcbf18fd9a34aedff30fe73f7e337c617eda1ffcfc4904f7f7c22f7fd1aff16bfc061688f7fc43bfc6aff11be11d6af73b45be1e7c5282e7fdf91bd0dfdff6fe1eb7f9bb967efe675369cb63fdcdbc06f2f11f30ae9b1a4d18b7bf48dbfc4161bbdf93fe37aef3b29a0aaec099dbfd49bd764fc24f7ef4fce8f9d1f3a3e747cf8f9e1f3d3f7a7ef4fce8f9d1f3a3e747cfcf97e71ffa43e5e7b7e9ffbfd6aff1ebfe1a3bf4cb7ff4e8d7f8357e4cbf4f8f7f8d5fe337fdf5294e4f7b6167f4f9edffa3e33fef8ffbef7ee2aff92dbef7b7ff8e7ffecf6ccffeb43ff2bff913febadff4dff8cbbff34ffe35ffe7dffe5ffd3dbbbfd77ff16b4dfff08bfff21ffbdb7edb778fffb81ffc6bffedbff7f8c1ffb8fb1bfedabfedbff4af1efcb62fff9ad77fc69ffa87ff8bdffebdfeb13fefd7fe577eeaf7fc2dffdbbff3effa8b3ffdce9ff5cbfea2ffe1ed7ff1d7fea7fff5fffdd72cffc7bff71ff8cdffcf3fe77ff94bffb8fff0dffa27ffb33ffafff81bfef97ff9ab5feb27ffd81ffbd3feb07ffc4ff8a9ff6bf27ffcd7bfcbeffc5beefc5abfc62ee1f16bfe1abfc66ffe6bfc56bf947efc3affd7aff9dbfc5fbfe66ff8eb6fffb6bf464341f4aff707e133fea2a2c4c7aff76bfc1afc7bf2c9aff1eb7deba35fe3b7e26fbf95fc1adffa05bfd6d66ffa6bfc1a097db6f56ba1193ef8cdf0c1aff16bfc963bbfceaff1c7fc1aa0d7aff19bff5abff6d66f4e9ffe1abfc66f95fc5a35bdbbaaefd03f5bbf057d56fd96f44ff35bd13fbf8420fd3abfd66ff34b7e33f9f19bcb8fdf023feacfa9f98fff397f369efff8f7d8faada9759dfc5a04e1b7c17b04e1d7a9ff20fa33f9f5b608f8aff78b7f5bc0fdede81f19d26ff06b6cfdf6dcfb27bf06e3f56bfd1afb84d7afcd634f7e9bdfb0fefb065efd8d7fccbdfadbfc869ffc1abffe6ff4c9aff11b7cebb7dcf9757f8defff1a9c4bc1fbbfd56f58ff5fb778ffb7fde3e99f5ff3b7fc757ef35fe7b7f9b57e31065a3ffdb57f8d55f53bd097441cfaeed76b7e47fafd2ff9cd7f1ddbd1af015c7ffd5fe32dfdfc756d5f6f7eed9bfbfab52bcac124f4c96ff26b6cfdce68f30be89fdff0931fffb57e3128f56bfddabfed6ff55bfd565bbf1120fc5698dfdf85bedd4ab989e91973f767ff1a3cefd2ef6ff51bd57fc240cf1893ebfbd7dafa5df1dd47f8e7c701f3d7afff3d0cf477c3b7bf7e9dfe3abfc6ead7ae7e777cfb0be5934ff9938fe98f3f6e9b285497f4f7d6161ae82b2bfaa0bac3bf5744930418fec69ffc1a3f66e8f3f71283fdfa662e7fabdfe8b7fa8d7fabdff2d7f9ad7ecb5ff7b7fa2d7fbddfeab7fcf57fab5f97f9fab7fcb1dffcc7b67fecd7a8ff0c82f59bfddabfc66ff59bfc3afd8f7f1dfa38d2fad7fd35ea3febd7191839da7954c7b07ec3fadfa3d6bfdd1fffeb61b693df3cf96d7efdad11e8bbcd939bfcb6322163f96beb2ec643f3ff1b12e8dff8c77e9b3fe7b7fc757eec4f287edb1da2e827bff68ffdb67fce6ff9ebfe3aa69becd7f8b5eadfe0d72552fdd6bfe9afbdf51b63667eadfab790bf7f1df3f7ef247fffbafaf7afbbb5c378fe5a2251bfc9af63ff66d1fa4ddcf790b15fa3fe16bdde10e57fbddff2d7fbcd7fbdfadbf49772eaeffbeb1a4efdcd7f1dc8ecaf87e9f8f57e0d6a54ba467f846bf4eb868dfe02fa4686bd4bfffcdad51e7e355ffe5df6cb7b785760fd6306d66febe8f81b187ad957ff3bfbea3e5e6515f3ebfd5abff66f2e6cbd45fffc7accd6f685ffdd61fb9bfc7a56f84cfbdfdac3993fa97f013552aaffbabfced6c7f8fe3ea6da7c7fc0dff32cfc26bf4eacc12b6ec0d3f29b7420fc96bffe27bfc66ffeebff96bf01fdcbf2f6ebfe1abfdbafc5b9502b6fab5fef1692cec0b73e35df3cfa93615d7e1de6c45fa77a40ff3243d32bbfedaff19bfc3a3af6bfcd8cfd277e8d4f3223b007f8e721fdf33bfc3ad523fc7ef86bb00af1defb4fbcf7b67e8d5fe7b7a91e0bfb4807bfb56b98fcfab6213d9ffc9e84e66f10a0b93d8ae2e881d8f741fc26bfce4b66d5eddfd803b4fd9bfdda4c7a03f5935ff3b7a1f1ff47e8f1d7dafa4d8868bfddfff5eb08d8dfbbdfff47aea7dfcff4f4db30af318bd10053d7e2cf8ab6f8353eb92411fb75aacfe82fd8c05fef37fcf57f2b86fdfb19921ed13fbf6ef57bd0bfbf9185f5af1858bfbd7036ec81c2f83d7f0d56ffbfed6f501d7b7ffe76bf7ef5447e33fdc28ac186fd7ebf06fb1fc22fbfcd6f5427bfc17be867e0569dfc1ad0cfbf4df514dffcfabf6d75ca3fab67bf46a0647fcb9d5f9bd73b12c79bbfd56f5cffd4506fbfee6ffeebf67afb1cff7c9b7babffb2dfc059837fcbfbfdb7fb31d801350abf90fef875aa33c5eb3b82d7ef05bc7e83d16ff71bfc16bfdefff55b53c7bfe36ffeeb6d3de75e7f1d997feefbd7fd357eabdff8935fffd7f80d7e9b3f07f8ff96bf0e09d8aff32dd809b2d2bfc66f18b513bf0dd989dff237f8ad7ecb1ffb6d7ecbe4b7fa2d7fc3dfeab7fc8dea473f3630bcdfe437ff4d7ac3fb82fed15f5fd03ff525bd2c9ae74bfcf987fc98f2de6ff86bd57f04fd2e6c4b4cf0ebfd46bf161bc4facffa31fd0038b1d9f92d7fdd1fdb7ae975f93bf8a4fcb1ad9fc0afafe89fdff2d7a1e1fd5662b5d0ce58fcd7f8eed7f567fb3757b9063f42c18f3efacd7fbdea0dfd31faed7f032748db3f46edbea25f3ef9357f5b50f4d7271de5c3fd4981fbeb6f7f3c30f6bf2018fb2789bcf65dbcf61b0cbcf2db05af90b5fb0d744050fb3a2e12aadfe037ff757e7319f96f612c9c00f9bd1dbc2ee8bf21005dfd3e80ef0fe7a76438bfc66f9e8c7ed3dfdcda43e52634fcdeaff1eb1b14764c7fdf03e47f8a2057bf2ffd2688fdbabfed16b1eeaff75b6d7d1f107fa3833f4ef410b7fffd80143782bbfaeb55bf3f37f9a4f446f49bff06bff9affbeb6ffdb6b0bdbfe1af4fa8fc86012abf2df7ff3b0ff4ff9bff8604ec77f1bffccd45b96efd01f820439b5fe337ff8d7e4b1287dffc37fe96f8e5d5afc16b60d6d6fc3b43ec3ea43b7e6dc74cbf619d2464e67e7d565bbf7e3541cfd4fed7abbf93a883ee9409fafee7a9efdf38d425c96d7409cbc56ff86b63f92ef96d9932fcfd6fff6bd47f0cbdff6bffb6d50c7461f7119dfe8606ddfcd7b03c815f7fedea1cbf5ee09f3990fb1dfef8df1d9a9844023ec6aff7dbaaa6fe1312d5d4f4d96ff76b5785fcf6dbfffaf44ffdd761643ffd6bc040aa82f93540d75ff7d7f83361adacaffe370d8ccbb7e0f5bf478d7e47670c14d3b7f8a7e43e7f9ddf563e63dd512de4b3df4e3f83fa309ffdf6bf36fdf33bc8dcb32f6d8c86efd7ff06bfc6cf108ebfa937f7bfce6f789bb9670b2aced0d6ef043f4bfca2addf12330d4f8cbd253273bf1911aff916db43c151ddfd4fa0ef0c23008f7feed7e0e5d7401fd78f8690a1e9e9bbdabf05e3f45b389c7e0b87139c3df6d008a7dfdce0f41bb1bf242e99bef23b755e7925affc16e695df186aebd7006763043fe6ffc19a4518e0b7fc75e9df5f9763c3e5af8141797edcade8fb6bfddabfceaffbdbb00e211bf937d02bd5129fd77f17fdfaeb5715e6fa9ff80d95b53d3f24b0d3bfdeaff105d9b8dfc297ad2016fa2d7f83fadf18428674ad43864205abb68dd784168f8ee945df9b8a3861dcee5779ea0feac2b33dbf61df3bfaf547bf1e543e141d5efebbf1f2aff3eb562be0f25bfdc6610fdce28ff7c0b36ff18b78227ef35f47fbe137490bd6f4f317e253385855239ffe3a558bbfd6e6af4bfc7585bf54f27f8bdf288c3e7ec3dffc37fc6d44bbfd25a49841f5dff837ff757eac7a27c07fb35febd7f8e4c77e0ded8bd022551c7ae54c5ab4b8461f1dfafdfaacd53ea160ecb7fc75bd81fa9fff7a1e38fff35fff37f9f50cf4ef743c5cfef0a35fe3d7fa757e9bdffcd7fdcd7fbddffcd777c13e8b6af50390eb37f8e47706d76dfd6ece6efd069f24a266252ef92d7f8cfed538fbd7e2dcd76f6975dba3dfe866ddf66bd72db5922ccf2fa67f5ae2cedfd1cba3fc3abfc6f7027df927dd02a61f5eb3f3ac91f5aff3dbfedac665eee9bc5ffbd7204dfa6bfc569e4cfe5d033d45ed5dc7a9f8b559ecd9a16097dfbcf6ebfe1abfce6ff4c9aff3eb7b3aeed7fd35b6a987df7a933cfef2214402796c7e069df1bfbf51d781ff8d7facdefb8d4985b1c6dffa25f8983dea1fab5ffdc6c6bbfeb1fa12bfdfe1dfab5f8a367fe0af01cfe7936f93d6aafe20cccd03a528fb840683ad5fe3d7a74fc0fad51f4cfffc42f258aa3fe4d750f3b2f587dacf7f0d80f9c300126ffdb5bfd6afbff5dbc197f9f57eaddf407e5153c0ae1e9b2b32a27f1ca1f49bfffabfd5d61ffe6b30e7f5f8edcffb35fcbcd79ff41bdfcc1bbd30cfb8797f04c8f7c9f35f2354255e833f921b7cd28ba76d833f8a1b24c60b713cfc6bfd1af300cf7feefdf08c46b1b6d77deef537e8f6f9ebfd1a7f562037c96ff20df47964d4df4ffe26aafe3c29fbb5d90d113dfaeb7040ca2e9e13b61e8ebffeaff12f138ebf8d9bbf6f02c7df8c541a6bf8addf1186f293aa3f61af95747ff4af61f53706e0ab0df21a7f1b1d84e88e5ff7b70d42f05f97c7e4c6a699c0302ffb6bfd1a30426edeff95f71b9f7c4390e135fd869f3ce9b3267d77c0dffdc2fe20e9bb57fc5d8f217f0df1ef49c47e8ddfd6d377bfcd6f7a1b7d4769e1e68fc1907f7dd885df851a577f2cbee03f7f01fefce3f44fd0f8d7abfe78feab9b8fbd43bdfc761d9d57ff7e4308047e9d8c25ee37fc467011d0fcd15f4f1d75e8c5600ac3c17fd36f1a1a700a627f9bfa5fa30f35e9f21bfce6bf41c800bf419874f90d7ebb801f7e03e5875f5ff8e1d7f864dcb5f0e8fdb7a3f9facd7e8dd56fc00150fdb7fd66360c7174fd8d7fecd717826ad4a04ea3ced95967cefeb9dfecfde6ecd7d6c90ae7e3d7f9357e403f7ffb20defacd7ef3dbc45b04f84ff8358419d855aefe44065ffd493c1960898ff0e91ffc6bc02e70f2f8b7dafa93018d3ff9f5bdec8be490ae7b78fcd43781c7afb3f5e3b74683e9f117517fbf4380c79f712b3c6e707bd1f63702b27f0acf3a89a641fcd70831f7d30cfcd66f4a83f9537f0d78c38c7240e2dfd58dad1b196efd69f8e74fb743d5062e4cfcb5b7fe8cde97365ef4c244b6e391b67f8301e4e559aa3f336cfb9bfc3a66143ffe6b98f72ecd7b92f9728d7f0d991f6df61798665b7f966de14f17ecdc2fa139fb1d3d99f8378666aa2313cd9f4dbffc864ae9dd5fff379104e16fcbcd7e4bccc7afbbf5bb83b27f0eb7ff843ffa753487a31f76e4e8d7fe35481fc95ae6d69f2bbd903bf35bc4d1f1d71c7fad5fbb214f26f925f0be75fdf1d7f935fe0582f53b053cf87b0e800a476678c73a9dbfdeaf71f08742c3347ffeaf213ae02f40bbe62ffc35c040f58480fe3af5eab7505d54fd45f8f237a8ff20faa0fa8b6dc3dff8c77e5df9e6c7ea3f06dffc25f8fdd7affe52faf11b547f194f0bfff163f2c7af25ab867f3900fe15bf066261fed8aead5ef4e9f4a7dd8a4ebfe4b726b8bfd6aff34b7e1bfcf8757fc96f8b1fbfc9aff34b7e3bfef9ebfe92df9e7ffe7abfe477e09fbffe2ff91d95a0e0939640ffce513fbbfe8786084b56c0ebfd17a3f3dff0d742935fe737aaff337a498d072dbefd36bf364bddaf5f1ffd96bf86a613ffca5fc31a8f1f9390f0d7fac540ecb752c03ff16bc8dfd55ff56b60558b71ffc518c96ff0635b7f357f14fff6d7fac5183d1b1e6ec7bd5192f7939ffa35ea6fff96c80bffe6bfaeba3140ec373038fcb63f661019f8de036c5a1ad8f5e56f697d23bcf46bfd6290d6849abf6efdafd0d700f19bff3ae6cddff2d7fbc42e61413c7e8ddff0d7ff357e8d7fe19ff91fff01a2f2aff127d3ffcbd7d74d9b2fc6aff2a65ad7d3bcb1bfbdcab3595e8fd24533adeab2988cd29fcceba6a8969fed8d77f0df283d5997edbace3f5be6ebb6ceca51fa723d298be9ef955fbfa9dee6cbcf260f1e64f7a7f73fdd7d786f3fdf3978f8e3fdced6cbb658e4e683d739224f04affcbc3c7e8afffdf37fd9dff087ff017fdb3ffd47feeb7fddde9ff0f1e3dffdaffceb7feb3ffc1fbc73f2d7fd8bbffbeff07bff6bbffafffe93ffad5ff78ff9e37eec37fdedffa1df6df5f1bffdf17fbefbfbfe9effd5feeff2eabffa1dffe4f2ab93df6b31fd0bbf585efed7ffc0f57ff27bfe53d7d53ff037ffe02ffc3505fcafa29f29fdff9fa6fe32fa7b89dfe9e75f80ffd367ff05fdfc8de9b37feed7644c7e0d9a8e5fe31efd8eb5bf8cfeff9fd1ffbff875c8b73ffe354e7e8d37e4127cf96bbcf8355e73d3ad27bf063efcbd7e8ddf9fbef892fe3dfe355e7193935fe3f9af714a7f9f51d367f4cd8f51e3dfe984c2f563fae073feea0bfafd29fff6e4d7f87d7e0d72ec7e8d0334f892fe7bcd1f7f97defebde8ffbf3f4378c5af7cf96bfc247f277f9fd0cf97f43219db5fe317ca1f67f4f5d308222fe8db37f4db8c9afe76e6bd6eb33f98befcc87d89df80fe193502b666ec64317f8ddfe4843e3ce50fd1e1df8f8f309a37f4d119017bfd6bfc13f4d1a7a7d4ea95627b4c1fcb3b4f237d03c563ea06d0fe457a75e4bf7ac2747b43bfa18fe7dc0f5ec1f718d7b769bab6e22f389a99c6bfa8db189384b17ec1bf7d4e9f3ce7df7e2f1ac59f458d7fa1dff88b5fe32bfa18909f30548c465efc17a9e981df1434fffdb9cb6fff1af8dc4de96bcb3086dabfe1aff5355e3663fb0ebdfc0b0d9374c9ea73ddeb5fe38fa2a6bfcd73fa40c6006a9fe91cfea5f4d56fe7c815c2f99be8cb5ff3d73f9eb6a4159a5ff3b77a924ddfa66d951ed76d312df3f46c795efd9abfd6e4fad7fc3d4ee655d5e4693bcfd3abe26d814657f3623a4fafab757a55adcb595a166f737cfe8b777e09b7cb14c82fdefd25e35ff3773ca956453e4bcfeb6ac1df7e44cd3e6258e35ff337a22faf4da7bfe6e8cdbc68ecdb57599336eb29a99ae67c5d96d7e954004947e35ff3d73fa9f3accd67bfe6afff346fb3a26c7ecdab37f3bcce53c028e9bbd9759a2d2db865b6a0978162b1643c083bc1227d9ca5f33a3fffeca35fbcf74b3e3af291787c373b4a17eba64d27795ae702a3aae9d7457589411575d38e7fcd8f7f1fa2c5345b7edca6b3bccc5b220183feb849ebaa6a0db4f1aff9bbbb860030d4ec7e0f1e937e955de40dfddace690cd36a512c2fe48bb258be6dc6bfe623bc66b015d06936a36645433abe25bc89760182aecbcf847619fd7f59a51511a8e6168d9bf0d69f1dc20ebdc89c8c7fcdc75fef75a6e2f8d7fced312de7849f7e4d0499ceb3258df6d7fc0d9f67349ed3598199fe8dbe00d1945d7e8d27afbff3e4d7fc3544c9ff46f4ff4b18b7fb3b0ff61ee0935f97f391ff1c7df1e3bf9444f1372693f45bd0efafdb9ac8d6a0c51f453afa979341f9f1af5eff1a3f73efd7f8357e33faecc73fffeaec29fdfce3e8ef37646f7ffc498958931f48cc777f97bfe4c77e0c5dfeefbfe63d245ef0eb97f47fb2ebf0a17f8d4fe8ffbf97b4fd35c8b5c01a1c7248f09bb8adf9ffafa53f7f5dfd09ff487efe7a94ebfa7de8af3f94d6907e935fe3ef24abf69bfc1affc9aff10fd0bfff27fd9bfc1abfe5aff933f4efb77eaddffed7fa4d7e8d3ffed75ad1bf7ff5aff567d1bfffe1aff5cfd2bfbfc5affdbfd0bf47fceffffd6bfffbbf76f26bfcdebfcee9aff39b50dcf33fd2bfbf37fffb27f3bf7f0dfdfb5bfc1a1fff7abfcdaff75bfc1adfa67f935fe30ffaf596f4fb9fcf9ffc13fcc97f479f90c7faebe3df8f7e7d7cfbf0d7c7e76f7ffdeffdfac9aff197fdfa7ff2af7ff56bfc5dbf3e70ff2f7ffd7f923ef9f57f03fcfbbbff06c0f0f7e07f9fff06cb5f8f9236bfc1e437487e8d3f983ff98b7e833ff9d7ff4d7e8d7ff43700cebfce8ffde7bfc16ff26b7cfbc7308a3ff4c7263ff69bfc1a7fff8ffda5f4ef7f4cffd24a41020afc06097efffd92df8312707f54f267fd5abfcdaff157247f6ef2ebfd1aff66f2fbd0b7ed6f8877ff98df10e3fd1b7e43c0fceff893ff8b3fb9f31b01e61ffa1be1933f9f7e4f7e8d7fe337fa19a2f07ffc1be1dd5ffe1bfd05f4fbbddf18bfffcc6f8c77ffeedf182d7f8ddfe42f203cb77f13d0edec37c1277f1efd9bfc1a7fc76f027cfe3bfefd9ffb4d31965fe3373bfd75925fe337facdd0f2e03703fdffabdf0cb4fd99dffcdfffb57f935fe3cffecd41ff7fec37c7b7ff1afdfe6bd8b916aefdcd982b7e5dfeebd7fc357fb35f83e222f22b7e2dfee437fb35ee33f7fc5abfc6afcf7f81277f7bcaae6ff15f2ff8afdf9afcf2dffcd7f81d7ecddfe9d7f8c93fe87bbfe61efdfbd3fcefcff0bf7f02fffb67f3bf7f39fffbb7f1bfff28fffbaff0bfff29fffb3ff2bfbf9afffdb15f6b8f7a78f46bedfc9abfe6aff17bfc5afbf4ef17fceff7f8dfb7f4edaff76bfc73bfee7ff76b120d7f5dfcfedff0bfff23fffbcbf9df5ffdebba36bfeeafb7ff6bfe4b2946fc67fc06bfdbaf9912e4dff877e5bf7e8dbd5ff377a7bf7e1bfeeb0ffd351efd9a77e8afdf9efffa237ebb53feeb7795bf7e8daff8af6f05dfeddbbf1e1056ff1cfff55ffc9a7ff7aff5d9aff96bfd1abfd147f2d7eff46b3fa1bfdef15f7fc4afb1f36b7fe7d7fcb57f8dff89fffa837f8d6fffda2f7fcd5fe7d7f8b37e5cfefa037eeddffbd7fc757f8d3fe0174acbe6d79efe9ac9aff1276dc9777fc4afbdf8357f935fe3ffd0bffec25ffb17d15fffd01de9e16fffb5dffd9abfd9aff1cf8de4bb7f8c7af8cd7e8d6f6fcb5ffffcaffd33bfe66ffe6bfc6e63f9ebdff8b5ff905ff3b7f835fe29fdeb37f975fee85ff3b7fa355ede95bf7e07faebb7f9351072e2af5ff8ebfcc9bfe66ff76bfc65fad7a7bfce9ffd6b9256b9277f4d7e9dbfecd7fc5d7f8d37fad7ead7f96b7fcd8f7e8dbf4fff5ad35fbfdbafb1bf2f7ffd61bfcedffc6bfec25f63755ffefad37e9dbfe3d7fcf8d7f8ed3e95bffe52fa6bebd7f8e3f4afbff5d7f94388a23b0fe4af7f86fefae4d7f8cd0ee4af7f8f5a6eff1a7f9dfef5dbfcba7fefaf39fe35b61eca5f9fd05f3bbfc61ff048fe3afd75c1557f97fe55febaff3429c7dff350fefa437edd7ff9d7bcff6bfc53fad79ffdebfe5bbfe6835fa3fd4cfefa7b7eddffe4d7a42f10f4f36cfe4fbfe6eff16b3c97bf7e8d7fe7d7fd15bfe6eff96b6cfd1ee6bbffe3d73cf935fe3cf9ebd7f84d7fbddfe0d7faceaf01393afc0df0efdf18fdf7d7fa357ef7e437fb357eed5f639ffea5208bfefd757f8d5f9ce0dba3df10dfa2cdaffd6b7c4ebfff3abfc68bdf109f7fce9f5fff460ece1ff99b84ed0de4dffa37edfeeec31468fe27bff037452fbbbf29e41ddffe7abfc6437eeb9fe27fff9ddf142dffc75f17bfffa7fcfb7fcd9fff2f16b2ffafc1a4fbfbf0b75d7cccef7d3cf1c9afa3b8f53f7ff99be3f339ff5bfee6f876f59be3db357ff21fffbaf8e4bff975f109c6f2eb9046c0787ff5af8bf1fe73f4efaf4f1a012d316bbfd6aff1ab7ef35f87f4d7af437aeccffe3530f77f31fffb57f3bf7f33fdfbdbfd5a7f37fffb0ff327ff34fffb2ff3bfff36fffb1fff1ad006ff35fdfb3bff5abf8a5bfe9abf263ef931f997bffdcdf9dfdffed780a6f8cd7fcda7bfc1bff46bfde6bfe657bfc1bff96b3da44ffefd5feb77fd35dbdfe03fffb5eefc9a7fd46ff0dffc5a3ff66bfc89bfc11ee5d5ffccdfe07ffeb5767fcdbffa37f8dd7f8d87bfc6dffd1bfc1dbfe64f50cb5fe7d77ef86bfe1bbfc16ff76b1fff9abfe98ffd4ef4efeff863ef7ecde2d7b84fffe2dd8f7eeddffed7f83d7feceeaf7dfc6b7cf563fbbff6d9aff9a7fcd8a35ffbf7f935ffe91ffb9f7ecddfe7d7f8577e6cf16b66bfe67ff563bfe7affdfbfc1abf9c7e47fb67a4457eebe47ffa357fe2d74c932f7eed6bc6f60ffe35ffb824fbb5ffe85ff36f492a82ff4f24ef7ecd3ff9d7fc0f93f6d7fe937fcdff2ef9c5f4c9ff449ffc3ebfc6afff1bbefb358f7fcddf9aff4d7f43e030fa0dffa05ffbceaff9d56ff8e713fcec375cfc9ac7bfc61ff81bfea5bff69ffd6bfe29bfe15f4d9ffca5f4c95ffc6bfeddbfe1df48bfff53bfe1df49fffe0778f7d7f815bfe1dff76bffcdbfe6aff31bfd23d4e36ff41b55bff6dffd6bfeb6bf11e0ffaef4efdffc6beeff46fffaaffd0fff9ac7bfd1bf4bff7e97fefd45bf66f31b01f29ff41bfd37bff63ffd6bfe75bfd1fff46b67bfe6dfff1bfd3af4f93ff71bfd76bfd6bf4ca3f85f7fedfff8d7fcef7fa35ffbd739fe357eeddff8c7e9dfdff4377ef76bfed7bf66fa1bff1dbfe67ffc6bdef98deffc3afff3af79f41bff627af7e4371eff3ac7bfe697f4eddffd6bfef46ffcdbfddabfead7fc237f6350f5cff88d31a2bf11fffe1affc46fbcffebfc9abfd6bffa1bffcfbfd6f1aff95ff227bfd96ff2e8d7f9b15feb77fe4dfe271aefc3dfe4f724f82f7f93b35fe7b7ffb5befb9bfc1dbfe61ffc6bfef46f92fdda3ff66bfd80befdbb7fcd3ff43779f76b664ce7ecd7f8937f9325b5fcab7f93e6d7c97e8d7ff037b9fe757ed75feb9ff84dfe40faf75ffe4dfe28fae4dffb4d40e1fff237f913a9cdeffa1bfd45bfceeeaff5cb7f13f4f5ebfea67fc7aff947ff1abfe36ffa3fd1bf98dfdfe7d7f83d7ed3dfeed7faa77fcdeffca6fffcaff3fbfc1a3ff99bfe7644c3efffa698d9b7bf29be5df3ef7fe06ffaafd0b77fe26ffa6fd2bf7fce6ffa3fff5abfcfaff1d7fda6777e8de2d7f80708da2ffa35fe95dff47ff9757e11f32166ff37fd75ff61a2d86ffdeb1eff5abfdd6ff63bfdba67bfd66ffa631ffdbabfe8d7f885bfd92ffc75ffee5f13f3f53fff9adffacd3ea1cfeffe66bfddaffd13bfd6d16fb6f3eb1eff9adff9cd409f9fe47f2ff8df35fd7b4d307f05fdfb27ff66ff13fdfb17f0bf7f13fdfb0733c7fed1bfc6dffb9b6114ffc46ff64b7fdde2d7f8977eb33ff4d7fd7d7e2df9fcffa04f7ee2d7faf57ff3ead7befe357edbdffccffc75af7f8d8f7ef33ff4d7fd357fadf16f0e8efa8c7eff9309c25f43ff7eef37ff5b7fdd5dc6bc6089cb7e2df9f74ff8cd692e7e2dfefcd7faebf8f7bf83ff05ddb25feb9ff9cdffb15ff717fd5a1851f16bfc97bff93ff3eb5eff5aff137db2fb6bfd3abfc5df41f07fbbdf02bda4bfc57ff0eb926f475ece6f42befbb7e9dfdf8c7239bf0979383fa07f7fbb5fe30fa77f7fa75fe34fa17fd35fe32fa77f7f37f680b77e8d7f93fe1dfd1abf9cfedd217ff837f935f67f8d5f8f2cf20179c5bfebafd1fc1afff8af35266359fc7a63ca137d4cfffe8ebfc677e8df1fff35be4bff7ef26bfc01f4ef6ff86bfc8a5f77fc6b1cfe1aff24fd7ef26bfc87f4efeff56bfcdff4ef6b7ef77bbfc6effaeb8f7f8de9aff12dfaf7edaf71efd7ff677eadfff5d7fad5bf16e5f87fedd7bff61ff96bffd3bff67ff46bff26bfce97bfceecd7f9d37f9dbfe2d7f91b7f9dbfebd7f9c77e9d7fffd7f9bf7e9d5fffd7fdecd7fdead7fd037eddb7bfee1ff3ebfef9bfeedffdebfe4bbfee7ff9ebfe5abf063cbcdf8bec277efbb57f8dffe3d7fed5bfceaff307fd1af6c1b73ffe6bc140ffdaf4ffdfc07efafbf0cf5f4bffc643f963fb86797e4bf2a0ba9ffda6bfd66f83202478f7fcd7fe7313f33bdadefd2df8d7c75f54b375991ffd1adfa5080d91be04d0e35959fe1abfffefff39453c59f96bc88fe3a6c99aa658769afe1a2fb3a27e934d280a9314c2d9b4a23659934d0a931854084fb226ff354c22f2d7902ce2aff145563773faeefa557efee5e4a7f369fb6b3cab2e9eac2f7e809f14d8e76fc7fac1f865b9be2896cdaf213f07bf1f9f2ddbbc3ecf285ff06b9cc967c0f925c5cc8c77d1accaecda7cf52abbc237e653c5e1f7fffda7eb9ac2fcf6d7b8c8dbdffff7fffd4ff4afdffff77f75fafaf4cdaf2183fffd2933f16b8ca7144fff1aae893478f5e5777fffb3a7bfffc9abd3e337a74fcd9fcf8f5fd35f67de27afbf7af2fae4d5d913f7c9abd7afcdafdf3dfbbdceccefc7276fcebe7cf1fad7787a76fcfccbcff1c9175ffee4a9f7e7c9972f7f1fefcfa7a7cf4fdf504a8e5f93b6fa3b37d4dfb5d59be327cf4f7fff27c7af4f7fff17c75f9ceae4b814efaf617efb225b12b1ea5fa3a498fcd73847104e84c3eccf7e8d736470dc5f4f39bb60ff6e4e6858833376bc2a7e8d13f903bf76dbfd1a2ff37a5134c85b3fcf2ff3f2d7d049fbc9a229264559b4d77dd05f517ecb9f760adfa76f873138254e2530f6955f23ca3206ce936a466d5fe5970570fa353ecfdb67c8ff1c2f674852f89f0ba338213999e7d3b72229c765595d11694e2a1293efd6458b06dfa59c8ef06b83d70d164faebf4d692ccaeee466ec06a757942f7a4e599f5f039911fee5ab57cf9f1147462832461bf4a2b8847fa22f4d03fe1ae8c1fcfe2a5fd21ac28b6af99dd74c999755d34e32330ac32b275559e6fac6715d67d7cf29d724bf3da3841fffc5e8bdca7fd13a6f8830e719ad3c70afaf73bc7ab65caddb5fe34dfeae25f44faac5225bce7e8de7d9242fbdbfcf9694c15a4b3fdec72715c9fcd27ff1699195d5c5d9ccfb28461169f66b9c6873a824f76b1f9cf97049f9be45c6e30fbe39ad6b22fdc96bca2c95399164bd586a0ff223feb27bb1df58c7279fbcc91734e96dce9c157e920773793c9bbdaaae7e8de66c71f1825295bf46734ca46e88337e8d863e3f237934f4214935322a13edc864f42da9fe7c3129afcd17dfcd270d65e18e5bcaa04dd6d477b7c1e982789e50a82963eb5a59a572ae8ce2de2bca5cd7a586817e512cab5a5bd1ef1b1a663f6d1bf65b3dcd9b695dacdae89744ee55b6bcee7ff1a668cb0d03164a9dcd7a837d9d931d816261617f89ac664619ec3735e566f3d909fd4e78f6dea2b9b958929415d3862ccd647d71810972cde433e23132dfa49c0d61c5da8e31082268fd3aaf2f0b286ff98019ee555e66eff837af577d9107dfaa4275dfbe992383febaa5afa6eed38cd4f49beb157322ff3424618369ffb0bc7452d5a4701a42b6bd2ef32f57d91454911c2ca4779a91716d7860bfc6e972d6400fea3889259f100a6f7f8dca2a67ead4bcfab2aede5d6399f3cb6579cd2e0610386bf0118b424feac51b297e201278f2bc9ae22fea052f1a2b8edf9f3d610b4ca6f7e4f4f56bb2952fce60a6594abedd2e4a6e0442584b00e3850fad05e875fe342329252cadc1314d7f629dd7d7bfc68bfc2afc601000992a24daa515c91affc59d17ef2c9d4ee46b5a9125d6cb16673ab0a5c58f3eb9b747fa8a15b085f5654d237c72fd6bb0d23e3f5b16e05ad50e0d6b2a58fe2edfb1db55ad2cdb7dc942469ea3651a79177e82fe2a4ec2aff1555d5a7bfbaa69f0a7c22655f36b7cbb6d575fb562e641760bef94963e66b9992af29b7eff37676f9e9f2a5735443ba8596594e7f9d2b4743ed7efffe4abcf5fff1aafd713e88449cef6c981f3990064e968dcc6286721b80ee9d7a856bfffe92f5a678c6e381d30d5c4b024f18e53e42ff329185b39503f7010c8657bfe5a15e759a3bf1d6351473c88b3e5847ecc4c670dbfda58b7813d1bd32bc3e34f8c93c194f508daf087f80db3c14d2d87ba3f1afafef4ddb45ccff2af96b591b8e0d3abc0b111547f8d0e5aec6d78a809ef9adf827edd0786a9757ed1e9f36251b4bfc60b5a23448f7fc02e3b6cc6d47ef504e4316ea67a212aadee77f9f6252d0216ef4493c025386b5eac17795d4ca1aa2ec5b490e6a06e3d1fcdb0cbc9975f3d7ffafbbff8f2cdefffecec853af127d9121e5eee66471497a7b08c0768c0bcf8f2f77ff9f9effff2f4d51767af5fb3ebaf5f7cf97b4160c5ae18aa593bf393c47833e24e71cede546f3db63f3df9ead5d99bdf0721cc574fbe387be368d1acc82048cff60f1054dd2a56f0674f0b869911ed4517883cfcdea4084fbe3a339890dffddd3a5b61ba31d89339397fa1370d867a45ee4a8d400b2e4965d5d109aff5b1189ebc219df253d5d23286f9fbd7200d98e30ffe744612f5e6a7e0617ef5e684bf527e806f5bd50cea3b15188fba05a820ea032a24d8c1a4b79687490666648544fc9e82431a521560b1f3e39fcede711b954d8f3b616ed18621583e6799e2b0a1b1bf41bdbec92e9ae386dde45fe3ab15660e9f280c1011bfc12089aa4420942de9efd24c02c85f5fa8cffd6bbca9e467a333f76b34e2fe196f5bd055e1fc35ce4e97606b1eb0f91dc12c31b5f717118818aead7f0d28fd17e49eb362254bee79edca621c669adf4f5f7c25b1a67ea0b1a6e1c6af5e9dea472c222f8f3f3f15da58d4f187efefcb271c11c8afec9559296d3c579c7c5a048cd6bbafd6938e3f8eb7586137303fc7082616cf8abc9c35bfc6b78bd92c5fb2e0ebaf3c46a28a2f55aeb32fdf92784f09a97306084784f17396020e37ad2637bf574edf9088aebbc1173beb189278e7e1972779a90366af4388d434272525647e8d3336d2180d9a359d5799cff0a5fd853a68940d249a63de17f70e7e3844829995d080f4bc9e57574a32bce32589900318d7364580e7e3ef527ef02dfdffecd758fe1ae7bf4645ab95f9afd1523eafa035f831fd3fa3cf2f68117c53bb5fe30ffe87d35fe33125bbda5fe39afecc29f187df56f4db67bfc647f47bfe6b9094fe1a77293d472c419f1c518be2d75810e0f1af31f30035bfc6ef4f3f97f41bfecde9df2975b5a4d6bf98fe3fa1df6b6e5fff1a8f288978489f5d519b19bd3fa74f767f8d4fa9cf77fcf99cdfbea09f6de79b4b7ebf65d819f5b4cdffa2ed925aa28f96feab083bb4fed60ded17dcff8c478df6bf84feffe3f429c643e112bd499e377dd650ff20657fbce48dd0cf8c7a068c19b5cd284dfa4d40313416ea81922553f011c1fed4fb0f78ff9a6bc17db8077c3ea3b70d55052a70243f9cf1dcf6bec5fc8c29459c2b1d01fb317180e311f0c0af79f85d62a8df8bfe7f460be3cf7e8d2f89ad28b745233efb359ed3fb9bbefd358e37bffb8a7efbeeaff192fefd9c3eff49faf435fdff097f7b46ed285d7b7abbde0d0cd70ab05e529b6340f94d7d5120a97ab819aaf9f409fdf52525b27f2ffa0d6d08d2179bdffc9cff7a467fbda2fef1f90b6a012cf0d72b6f945fd23714a8105e97cc17054bd1987ebefb358c20bf248c2f58563fa3ffff9ed1ef7e8ddf3afae9fd3ee4e5afd1fd2ce551a494f8df657efe357e6d5a7bffdd6ff326e5bb4f6e4309ffb397fcf315ff0dca9efe1abfc6278f5906e62c3de7ac897e3171e52f61fdf38b09ab5fc21c99610dfbc716d43324fdd7f831c8c98a78f4d7f88d2101e054e8af5fe3773e651d96137ef87c162ac0df125ae044e5b4e5ef7f8ddff484e7e49870a2acefaff16bfcf668f39cbe870c9cb2c46acbdfd6cce1efcf2dcf82375eff1a6b92ea86e417d23591377e437c032e784d2a1cf47945ef1ef3f8c975e5f1fffef4f3dbcc23a016b5fb8df18e994bc1f898a0b64a75e2dcdff498de0104f0cf6bedff0ba5cc536a97b106b9d06f4e9452c137bf33be016d0ce5826f6f9857607cca32e163724cdf4156be2b54d93ea571bed2319ff0084139407aced030767cff25fdfe6b7cecb7fee2d7f84ae9fc845b1dd35b5f302ebfc61dbf1d3e39a1dfe5bbcfe993e7fcdbef05aa042d5dff5fd0273f19f6fdd06ff9827efefefc39c6884f0c2d5ed3ef6ff85b03e3fddf04b62fa1431ef86f8272c283d02f7d0e016dbf10aa7e79d3cc7c49b4c348bf4b30cef81b9133bcf78630c37b0eaf5fe3ec3612dcd5b04f08cb6f2bbe4271a2c5bdaefe09f5584c7ffd1abf47ff1df212593a61abc5bb306ff6bf81ac78d07ecb488b1b2c57687d3a16e3373ca79f3f4df0de9156dcfd357e8ddfbc61595ab035857ef9357edd6dd24fbfe66fdaa8f4c3cb6849ea9a4062dfd0bf6f5923fd1abfb9f3b1de516bd248776fc24f78d4f0f5aff17bc07f13db0f5f018e1f7c3568cd9b3c01e8d35fe33715eb2e108e6eecdfe839dbffafbd45bac3d7589086637eebf767bef8357e6db2219f6c86fa158deb397ffe8a245fb4fd2f545dff19fdbca77fefe9dffbf4f3d7b87f3b2fa0a31b6f78cbcc7ce7adcf6e9a95d35f03361d32fc82dff90ef38dc0fa357eec1e8d081ed5aff11b3f6627bca6df0dedbdbf6fe0cd97f409b4e013c62ed4b5bfc6c7a249ce7886621a035c737aa39783f72003bf0f7d075efb82671abdfe1abfe36bb2190ddb86c5af81e5fb967989c38c8f3743b5dc72a3f49dfe1a3f41dc70ca3de2bb67f4dd57f4dd9b1be7c0e930b127429b174493aff0f6ef62b442570b3d668ff6d7f871f7fd79600767aa6f76c8ab726d1aa7657eed9d1bc705caffdebf067c4070b85828480978e6a67141f73ce13145dffebd6ef65ac5cbfc2ae0e828ac879063e817d0d059abdf5f5bfbb6d25851b55e37f8f468f782a9f062880a377818d03ab08a5f92449dd15f51189fbf0f0c60f3451cce4f7c081cbc018f16d0ac74feb8a1d4ef3fdc667a7bbff71169c3257b972b8ad236bfb7e7bdf76bfc62580bf14857c4dd47bf86f1674d04fac6fef6055b04b1c2358d9ad2736c518ee9db92ed33ec694371c21dc201f13c2c6045bf21fd5071d46d2cde67bfc6c7bfc6aff9db7eccb8deed60f06bbed7ccfbd4761ed34d5e8b0fe38699ba4192fb903c2c7e8ff77db7c377374891899e1c14a186f827acdd3feec75362d33a31d6ef1a6b07abfd94c7f25db6544b9abb09cd94b154dedf3f867c4b098fe7c77689d7767e8ddf9d6cbc6f8fce94c280dafff4d7f8f1785bdf8efe1abfcfe35fc3e4411aea751a70f64dbe4e2c1b85b7ee32f663ce7c9c534c727b99231bf1bdafef6ba551b89edff5bbde9419fa359efcf67ff4bff56bff71d7677fed7ff172e777fb87febabff3d7f80dd27bffe81ffb3bfc4f7fedfffe1bfc9d3ff87d7ff2b7dfff8ffee8dfe0affe6fdffc3d8b3fe5a7fefd5ffbd7fb2d7e835fe7d7f8357e8bdfe0d7a6a89c1cb05ff3d7f90de88f5febd7fb4d7e8b7ec0fbdb0dc5b7fc452c8c4d5c14fb1bf9c129030f635386110b457f3b41a41f89fe4e9b02d1dfc0c4fbbf8109f77f233fdaff9d3605fb4493dff9d7faf57ead5f37fd357fcddfe277fd75d25fe337ffdd7ffdf4d7fc9d7f8b3bbfc5367df49bfc16dbfcd7ee6fb19da4bfee6ff15bfd16dbbfd66ff29bfc263f96fe3af8e637f8cd7e13a2e16ff0eba5bf16fd8e5f7f137e63973ef84df8c55f8bfefd2deefffae9af8d3f7f9324fdf5f0f337f84d7e935febd72398bfc96ff1f0d745c3dfe4d7a1977e03fcf39bd01bbfc567bf09774c3ff1d731fdf5ebf14f74fa5b9c02ceaf85dfcef837c2fd3ebdf96bfe26bf5efa6bd3fbbfc96f98fefaf841dddcffb580c56ff1bbfe06bfc1bff5e92ffeab2fffdc5ff3af43bbdf00a3fccdafffa0bfe8d7f8dd7e8d5fe3d7f9837e8d5fe34fa39cf1aff76bd13ff4f7abd7c7bbbfc6af8374cdaff96bfc5e977fe6c7bfff7717fffecb3fe57ffd5bfe91fff3df3df8e7ffb77f60f48f9ffe45bfced517bfc9eff72ffde67fcc97fff67ff77fffe23fec7ffa339eff41bfecb7fb2d0e4f7f9dd3c577fea79fdaff0dffbdfb3ff64ffeab7fcc9ff7e7fcde7feb5f9efded8fcadff027ffecffe9ce6ff10ffdeadfe8d7fc47f67ee2f3b3bfe11f9efc51e3577fe2dfb8f51bfff88fff53bff93ff3a7fe99bfedefb6fd27ff9adfbbd7fe5dbfd57f7ff72ffbab3ff99b7eabfffbea2f7ff63fb5ffdae59ff637fd3abf26e1f4ebfefabf1698f3d7f8357f8b3fe88f26d2fe1abfc51ff4c7134d88c27fd01fffebfc1abfe66ff21bff7abfc6af8db1d2c07eaddfe4d7f9f57faddfe4d7fa0d7efd5fe737f9cd7ff7dffc77a7c9a466bfc96ffcebffbabf094d24fdefd7a2ffd3fcfc5abf2ef1fe1ff417ffbabf06c8feeb51639a0a9af1dfe27765e07f39fffb57f3bbbf0160ff4ebfd3ef441fd1e403107d43bfd1ff7e2df4fd1bfc067fd3eff1fbff81bff9bf9e3cc25fbfc9af0788bff3ef44bfff06bfd3afc7289efdd6bffe6ff89bfc06bf093807fffd56f8efd7fa9d7f27ea9a5a7247ff3cfffb2fd3887eaddffc0ffad7c100bfc1afc51ffddbc41dbfc51ff4efff06bf217adda6dff01ebef88f3185bfd68f3132fff16fa0adff73fef7bf6644b77fbddffa37ff83fefb5ff337487e8d5feb37f89de4d7dfead7fff5a9f57f4ddfe1bf5f4b3ee4577e0561fb6bfd4e60b56dfee00ffe35f9df5ff737a0b1fc16a7bfc51ffc63fce76ffc5bfdfabfe96fc2ecfc9b0093df04bfff268ac3bfcfe4fb357f1346e40ffecde9dfdffc0ffead7f83f4d7a47fe97f348adf847e80d8bfd36f92101a787eaddf9907ff07fff6bf0141c09fbf137ef92d7e3bfaf537a426bfc16ff1dbf1effce1a9cece36fd83d77e4d9299dfead7ff8dd031fa268c7e13054163f8837f676212820e16f89de9bf5febd7e70e0837f44f9342e4f983fe7deefb77274ef89d406eccd76ff23bfd46bf0635fc9df13f1af36f4bb3f65b3ca4fffea0ff18ddfcc1bf3b601194e4d7fff5a4afdff9774a80db67f8efd7fa2d7efd1ffb4d181df913df02e187c40e24bfbfc96f442ffd16c704ecf8b738263c20d3fcd1297d74fa5b9cfe5abf01718a529a74cf29033ec37f42d087fcef67cc7c7ff0ee6ff107dfa7fffd5abfc1afc1c3027327bf893ed4f1eeaff96b8ce66dbb7a74f7eed5d5d5f8bcba98d679fe763cad16779f55174fd6173fb8dbac57abaa6ec773ac61fd1a1ffd9abfc6ef3c5d372d2d0ed7db4d5e5f16d3fcf7f4dffb357e8ddfe8d7fc357efdddf10efefb357e8ddf001289877ef9b5f997efff9abfc6ef4d4b93e98256a3d2c22df4a7d9923ea4a5cabbd36a757d77c6eba6e9f97a29abd725ad92a76d95e6d9749e5ed18a569ad5b4f455e61f372916b7d21556c57e8ddff6d7fc357e0bc23c3d013ee9ebeabcbdca6afafc77f9357f8ddf01eb60e9b1bcc5ef3c4a65498c929ebfebaff96bfc4e800a8466f261675834805fffd7d491fc063c925f0095f7e6d7fa6db06efea25ad2ea6cbee275465a3bbf6a74e0b37fecbbdfc14f68cb29fd7ff487d2ff1ba8cda7affff437ffcc9ff85bfca17ff8e99f7b7aef37fbefff945ff96b2468f3e8f79d1206bf2f753e21f26fffa2ecf795a5bee6f7cddf65b4309937bfaf59d0fb7d05fddf77522ced67bac8b79a4d7e8d5fe3effa4395f8f4fc0bf83d757ffbcf3f64dbfdfe2755fdb42cbfc868e57dd14c2b1afe7846ab9878feefdffdd7487fcf38801f3d3f7a7ef4fce8f9d1f3a3e747cf8f9e1f3d3f7a7ef4fcbc7bc201ff9abfc66f46fffe76bfc6aff107753f4768b413f91ccfb7e9ffbff75ff46bfc1a7f9d448bfcfc75bff63efdfb939420fcfd79c108c94249f6fefe36b98de7efff75fec7ff4be098a8537efe1efa1765a9380ef39fa7dcea2729ab57139c82937f6794f1c3422a9edf8ddf7a43df669c82449ad62424e5f99b7e9ddf0879d16009b30fe9bffab5d066c7feb74fd9cf1dfafc9fa3659c5fd32efc23d7d8522f94bda77c23160b179a734c19b259de7538a48c97b49464e6dd5fc36433ef72ded2a433537a7b4d6d5d42157950a467afe9bb963e49398f3ba51473ca4b30b2a409cae08d2943fa98b04bedb8524e39635107cfb77f8ddfd28e4552d1d7343b198f01cf33cebaa69a31ce097e4a54ab08524bfd65fc299e3fe0d7f81d098ea121b2aefe228fa3bd5b763d0e7074f83da2dffdac6dc3efed5000efe0ffe4af8125a9c683bb4b8b073bf6ff665c80d9725ba19c1b99c1c3f4eaf738a639c012179e2de2be5f9392e3395101104cc2da25f625447fc9fd7da99f17da9fc177f9defdeef3785f12bc8a3e5d33077447dd1df301bf73cc4b1258a2c7c201f8a4fb9e7b47defbd1f3a3e747cf8f9e1f3d3f7a7ef4fce8f9d1f3a3e747cfcf93e70fa2d55ffaf11fddbba1dd8f9e1f3d3f7a7ef4fce8f9d1f3a3e747cf8f9e1f3d3f7a7ef4fce8f9d1f3a3e7ffb3cfff03504b030414000000000052a28e3b00000000000000000000000006000000737461746963504b0304140000000000999e8e3be72be69e7a0100007a0100000f0000007374617469632f636f70792e67696647494638396110001000d52800e2e9f049556b434b5c88afc895cafc3e455589bbecdee7ef2931439ac0d6cbccd184bc3b80b83895c94889c03f97cb4b7eb6378fc44492c74790c545d5dbe496ca4ad5e7f07ab3338bc0409ecefb52617b577091ecf1f672ac2de5edf57697b4a4d1fbb1d7fcf2f6fac0dffdbbdcfdabd4fbb6dafcffffffffffff00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000021f90401000028002c0000000010001000000697c09370481ca28e27cba9d3392506838ff473420a1f8da167eb316caacb8a24e2688ece228357d899601610338924aa6b888ccb704432994222774e4b667c7e212581420344737f8889018b22677d7f252520201e92271f1c95979920191e02429f8e909a191900a79e1c9688ac04040705a8227dabadb61cb9271b14221c5b00c800071c0a08a81bd01a1a010102020505088245dc4441003b504b0304140000000000999e8e3b784e96de1501000015010000110000007374617469632f64656c6574652e67696647494638396110001000c41f00f3323297cbfc7494b1e61313fe5656bcddfdedf1f5e5ecf5577091aad4fb4a576db6dafc84aac5a2d0fbfef8f8c2e0fd89bbecf0f5faff8888dadfe752617b444d5ffef6f6b1d7fc2931433f4656cbccd1fec8c8d44146e0e8f0ffffffffffff21f9040100001f002c0000000010001000000592a0e7589e589ee5a73adce06ddcc4cc42eda9e530105e141dc00304712b110680d2635988408622808b20f1309b3e8ac732a89e1e85c262718968bf4bb0989c30971891f4fa7249b415ef38785cb7370e781e0c066a6c090d8807152502066186880d011d8b1e8d737e9293198c11627d8801a2069c1e08131106411dac1d061a188c08b314140a0a15151919186728bfc021003b504b0304140000000000999e8e3b15f28dfa0d0100000d0100000f0000007374617469632f6d6f76652e67696647494638396110001000841f00c7e3feecf1f6bbdcfde5edf588afc87697b457709195cafcabd4fb49556bf2f6fab6dafca4d1fb89bbec52617baed3e5434b5cd5e7f0c0dffdb1d7fc9ac0d6a8cbdedee7ef2931433e4555e2e9f0b0d1e3cbccd19ecefbd5dbe4ffffff749dc421f9040100001f002c000000001000100000058aa0278ee4f89d5ef4685ee1114421bb282907433e3486f7b5b3994722513478a2a0502050381d2345d225112c161305d44351005a432b16a11511bc120f133b419013660551dc46301803782b301fdb191c031049016b75771c1c19837b747f1c07071618490a5687899101941e061d0a380319a31916011b174906ab0e0e090910101818175b25b72421003b504b0304140000000000999e8e3bf89dad2174020000740200000e0000007374617469632f7064662e67696647494638396110001000c62f002931433a3b4897292f3e4555434b5cd52a2749556baf3d3ca6435152617ba45250db4543577091716f6f9e647ad86866b079968787877697b4df7e7d939393c887a8b092b5e98d8cdf9897ada2c988afc8a9a9a99eafda89bbecdea9a8b7b7b79ac0d6b0bce9d8b6b695cafca8cbdec7c7c7dfc4c3d0c4f3a4d1fbb0d1e3cbccd1aed3e5abd4fbb1d7fceccccbd4d3d3dacdffb6dafcbbdcfddadadad5dbe4c0dffdf0d7d7c7e3fee0e0e0e2e2e2d5e7f0e5e5e5dee7efe2e9f0eaeaeaf1e9e9e5edf5eeeeeeecf1f6f3f3f3f2f6faf9f8f8fbfbfbffffffd4d3d3d4d3d3d4d3d3d4d3d3d4d3d3d4d3d3d4d3d3d4d3d3d4d3d3d4d3d3d4d3d3d4d3d3d4d3d3d4d3d3d4d3d3d4d3d3d4d3d3d4d3d3d4d3d3d4d3d3d4d3d3d4d3d3d4d3d3d4d3d3d4d3d3d4d3d3d4d3d3d4d3d3d4d3d3d4d3d3d4d3d3d4d3d3d4d3d3d4d3d3d4d3d3d4d3d3d4d3d3d4d3d3d4d3d3d4d3d3d4d3d3d4d3d3d4d3d3d4d3d3d4d3d3d4d3d3d4d3d3d4d3d3d4d3d3d4d3d3d4d3d3d4d3d3d4d3d3d4d3d3d4d3d3d4d3d321fe114372656174656420776974682047494d500021f9040100007f002c00000000100010000007bc8047828384837f87473a2b292420201a1a12921247882b3a4042999a409d1d0c9547294037a5a535a8441d9f822444a6373530103044b6098220afa735151016312d44b847babc352108162d2cc3821aafa832323108212ccd06cf44d231c10202212840da471242dd2d191616d6400482e7d3c12c101c2808e00110e642d4f40e1c2070602143800ae6885063060181bd1123840c10c48006112127102080d1a3070f212a00c4634052c001050608101830000031421536161a1408003b504b0102140014000000000052a28e3b000000000000000000000000030000000000000000001000b6810000000062696e504b01021400140000000800999e8e3b0e9aa9578d38000000a00000160000000000000001002000b6812100000062696e2f57696b69496e666f44657461696c2e646c6c504b0102140014000000000052a28e3b000000000000000000000000060000000000000000001000b681e2380000737461746963504b01021400140000000000999e8e3be72be69e7a0100007a0100000f0000000000000001002000b681063900007374617469632f636f70792e676966504b01021400140000000000999e8e3b784e96de1501000015010000110000000000000001002000b681ad3a00007374617469632f64656c6574652e676966504b01021400140000000000999e8e3b15f28dfa0d0100000d0100000f0000000000000001002000b681f13b00007374617469632f6d6f76652e676966504b01021400140000000000999e8e3bf89dad2174020000740200000e0000000000000001002000b6812b3d00007374617469632f7064662e676966504b050600000000070007009e010000cb3f00000000, '2009-12-18T09:22:22', NULL, 0);
INSERT INTO `Plugin` (`ixPlugin`, `fDeleted`, `sPluginId`, `ixSchemaVersion`, `fEnabled`, `sFilename`, `rgbFile`, `dtUpload`, `sVersionLatest`, `fBlacklisted`) VALUES (3, 0, 'wikiinfolinks@fogcreek.com', 0, 1, 'hostedplugin.zip', 0x504b030414000000000052a28e3b0000000000000000000000000300000062696e504b0304140000000800999e8e3bd069e74f472d000000a000001400000062696e2f57696b69496e666f4c696e6b2e646c6cedbd07601c499625262f6dca7b7f4af54ad7e074a10880601324d8904010ecc188cde692ec1d69472329ab2a81ca6556655d661640cced9dbcf7de7befbdf7de7befbdf7ba3b9d4e27f7dfff3f5c6664016cf6ce4adac99e2180aac81f3f7e7c1f3f22bef8a93fe9d7f8b57f8d5fe3d7f875e8fffff7fffd6bfc1a7fd7af21cfefa93f373d7f10fdff37f95dfe9edfe4d7f8db7eec9fff5dffae5ff3f93fffbbbe99174dbaaaab8b3a5ba4d36cb9acda7492a7f57a9916cbf4e997afd34535cbc7bff16f9cfc6e0ae3e5e9aff16b3cff357fed5fe3a7ffb1ef7ec7c0fd8f7e8d5feb77fd0d7fcddfe0d7f83556f4472a9ffd823f5a7fff8bf0d7ef29bfff6682371ef3935ee6cf7ff9eb5f93c6f57bfee1fcc76f862fcc4ffb839f7fee8ffa357e8d2ff1cb5f44affedaf259f0fc43bfc6aff11bd18f97d4ee778a7c3df8a4bfc6aff11b787ffe06f4f7b7bdbfc76dfeaea59fbf5b216d79acbf99d7403efe03c675534f7f0dc5ed2fd2367f50d8eef7a4ff8debbcaca6822b70e6767f52afdd93f0931f3d3f7a7ef4fce8f9d1f3a3e747cf8f9e1f3d3f7a7ef4fce8f9d1f3f3e6f9a3e5c7b7e9ffbfd6aff1ebfe1affd5e35fe3d798ff5ebfc6aff163faf59ff5e8d7f835bef8b528fe4d7b6167f4f97dfee5dff0bffc337ff0dfff367fe1dff41bffe3ffc72ffda37ff9dff51bfe9ddb3ffe97fdfa7fd0cefad7fdd37e8fffe54ff8ddeffcbdbffecedff827a47ffcbf72f68ffe397ff2fff6dffce37ff347fffad94f24ffcafff6077fe74ff8f5ff853fe1cb5ff52fff29bfecfe1ffb9ffd176f27dffff4f76b7ead7fe80fff1bfef97ff8bffe07f3bfe04f2cfed5ffb57afdb7fec67fd7eff1bd3ff2b7fee2cddff09bfef80fb692ffe8f1e96ff7fbfeb7dfdefa0dbff8f1bfeacfaecfbe5c7ffcfb5cfc963bbfd6afb14b78fc9abfc6aff19bff1abfd52fa51fbfcefff56bfe36ffd7aff91bfefadbbfedafd15096e0d7fb83f0197f51514cfdebfd1abf06ff9e7cf26bfc7adffae8d7f8adf8db6f25bfc6b77ec1afb5f59bfe1abf46429f6dfd5a68860f7e337cf06bfc1abfe5ceaffb6bfc66bf26e8f56bfce6bfd6afbdf59bd3a7bfc6aff15b25bfd56ff86bfd367ffcef425dff12faf3d7f9b57e27fefd37fa0d7e9b9a9aaefe92dfe0b7ad7f5dfef9dbd53fc63f7ffbfa37e69fbf43fd9bf3cfdfb1feadf9e72ff98df076fddbd31f5bbf05816e7e4bfae79750db5fa7fe8c3e4b7ebd2d82f7ebfde2df8a3eade88d8406f71bffd8f66ff06b6cfd368cc7aff56b57bf2dfdf26b57bf1dfd5bff0780f2dba3e9ef803fff27faf3b7f875feafdf9a20fc8ebff9afe37edbfa1dd107d00edefee5c1dbbfe1af3ffa0d7ffdaddf49bafce4d7fc6da9d7dfe4d7f8b57efdaddf19effe8648c17cf26b7c0bf4df27faffda4cffe4b7f90debe4d7bc19e9dfe637fce4d7f8f57fa34f7e8ddfe05ba0edf77f0dcee7fce64cd3fa97dee2fddff68fa7fe7fcddff2d7f9cd7f9ddfe6d7fac54caaff95deaa7e017d4913440d7ebd862623f94b7ef35fc776f46bc83cfefd04f7d7357dfd56bfd16ff51bff56bfe5aff35bfd96bfee6ff55bfe7abfd56ff9ebff56bfe56ff05bfd963f56ff5abf561c83dff237fccd7f4387c3af5da5f4933ffb2d7e8daddf15ed3ec2073f76f0e6d7e469f97143a75febd7da227afe7a8ae9f2d7524c994fb668f67fbddf905afc76aec59f665bfcbaa6c56ff46bfd5abf2d66c634f96b6c931f334d7e6302f23bba16ff906df11b9b16bf2530f96d5d93ffc436f9cd6d935ff7d7fab57e1bbfa35f6edbfcd6b6cdaff76be997bfdeafad5ffef6ccfbbfe56ff49bff46bfcdafff97fce6bfd16ffb1bd03fbfdd8fd13f5bbf095ef8f5cd0bbf4de485dffcd7c11bbff9af8b577ef35fcfbef31bd45bd4f837fff57ff3df60eb7763b27ef26bfce63ff65b92d8fee689cce5affd6bfced98213797f51ff89b0cccdbaffb9bffba9ec06cfdeef8ee17624cff3dbd517d8c8f7fad5f0c69f82d7e3d95905f6f6bcb7bf7b7f935eaff9b5ad6bff16f4a24b8435ffc4607f731c7f2d26ff3e7fc5abf18320c3c7fbda0fd856bffeb52fbdfea37362ffcc63f2693ff2daf93df8ae04105fd7a5bbf3158e2d738f8c7a05f7f4c78a0d7f0b7f11afe39d2f0c7ba0d7f7334fccd5dc34f1a6af51b475bfd665eabe7d4ea378fb6faadbd56bf3bb5faadbbad7e53b4fa2d5c2b7eeabf94c8f0eb6f7d023a9024fe96bf0ecde1af63e4f194e8f0eb9b39fc6d441eebbff1371d98c85fef37fff53c01fc6dffaf5fc77cf81bff1af56ffb9bfd1aabdff2d739f81f097033a206bfe1aff5eb0ab9795e7ea3fab7a7ef7fbb3ffed703dbfdfabff9afffdb10d7fdfabfedaffdc751cb5f937edbdaa6377ee35fbfdea646d5987eff85bffe6fb09dfc5abfee8f41dbfd7a9ffc06f88df8f6d7d3efeadfc7b5aba7eef75fd77cf627dacf7e0383e26ff16bfcfabfd66fc574912f7e8d4f767f8d5fbffed3075e16857297fe11852caffcfaf5af74edab1dfa21d4fc2d7f5dfaf7d7159afe5abfc6fffe6b702e3ad071f5affb9bdf86a642b95f7bf49bfcdad52efd2614fee4d7fc6db8d536f5fff637b7fd0b8a7b16bb5fbfaeec97bfc6270529c87b80f9ebd78dfdf8d7aef641e74feefd1a3f56dda7df5ae2d95feb37faf5ebbfd241fd0d00d1d2f9d7fc2d2cc41fab3ec57881c83ffcebd7bfadfb224a88df72e7d7f935fee45f83fd1aab1feefc160324203be248f0eb30276d3d00217e7df9ddb038dafd4ebf06d3c00d9e47cd3aea37fc35ea3ff5b7b04c46f2f0dbfcda7fc96ffeebfeb6a4117f5de62f70ff6ffcc9aff163467f3dfd35b843b57bbfc36f79b3ddfbb59a8fa19aa1c17ebdaddf1222e6ec6817de1f732b78df62785bb780f77fdc0ade36c3fb04f07eabcdf096bfd56de0ed30bc71041eb968f4ee6f3864cbebff6400fe6ff963bfb9d7437300de818182a586b7f3ebfd86bffe6fc52e2437fcf57e8d837f80d0feb57ffdea2166f037f82d12b510895a885fc76bf9a7fd1ad6bc3cc23f87f40fa9faa7bff5afb1fa6d8529c85bf86d7e83fa97fed6ca607fc96ffe1b3267548f81cc8f559fe1778808f1f167c4c82224bf11fb3a0d09e4af07f6ffcd7f9dea883efe25a4677f1dfeebf7c05fbf25fefaf57ff35faffa3d7f0d0805bdcbe202ccfe8edffcd7ff2d7f03920b3841a0dbeff36bf2bad100ddfeb0dffa1ba2db7f7f6bbafda31dba1d0bddfeab5bd3ed8947b7d2d2ed5e8f6e2701ddf0d7163165f2bbbcdcf931fdfb93df597ff95dbe60dbb0754abfd74f7e1b758c3791f98ff4c8cc74fe8a06fc1b0fd2f93bbfcd3744e7ff9abafbf57fdbead9009dd1ecd13ffe6b38127f8e7fbe2d24fefb7e9bdb92f82c4ae24fbb24aeff1382f8db3b88a227bf23007f5ba2edef45bfaad5fd0d7f3bfafbb9d7d7d61720f16fb581c4bfc6fbd1f8fff88669fce2fff3347e7f1aff5a1c9ffd26ce47abcbdff63676f4b7f98da204459b5ffbd7f824216a7e096a0636b1dfd77ff40df5f532d257d5e9ebd56f779bbe36f5f40b7e6df307f93dd54f709ff8ed55d03bfafe5ea7efbfeb83fbc6285fdfd8cfb77efb6fa29f37bd7e72eae737f57cadbfe076fd38a5ff6b575ffd1a9a73a852694b39076efeebc2e6ffbabfc66f15cedf6ff06b94f4f337f365bffecd7e875b45801217fcda5bbf0b86f76bfddabfcd16754821f6affd6bfdfabf415d1388fa4fa17f7e9dad1f87d7f111fd834e356c41bfbfe2d740a761cce274ce9f318443a0737e5b0d384375fd7b73584c30e55bd1b7bfce279f52cfa26ff135a9eddfd678a5db3ff663bf36ff025aa103e2b6dfe0c728f9f47bff46bf065eb252fdf7ff16bfe66ffb1bfcdec0ea13cae1fc563c740af67feddf96c74e21fdaffd6bfde6bfee6ffeebd5ff1b86ff3bfc8ec1f07fcb5fff939edefd53e9e76f61692f3937f2dc7e4ce2b0dfecd7fa35ea5ff03bdec2bf1336fbbde98ffa8ffb1dade1e0bc0eb30627b4aadfe7d7808df8757edb5fbbfe9f7e0d6b9e7e9ddf8e42b85f47ecc66f0fd6b1991ec4957fb28f5ffd97dd02975f47fefe9d7f8dfab7fb9dac510426bfb6e9e637fce4f1af51bffc9d0234f1e56fab6cfc53f8e77b8a1ce5a1c8f4fd7aeedd300ff58706f8fd45bfd3cdf8d5bfdeeffc6bac7e87cd04d2cf7eb9f7d96f070c7f7b21b4dadd2e4688957e22c0e7f1ef7c0b7cfe82dfd9c63a9612764ac2f1fe3abfc62f0ee0ff67b7817ff40b7e8dd5efe8c1dffa7d7594bf8ef9edb7fb75cd6fbffd6f623ffc1d7e13fb696f9cbfd6afd1021fa7337e9bdfb8fe0f7fc16d7486c8e26ff4c98fff1abf8193c4dff0d7fef583f4c7affb6bfcb6bff127bf39b560b1c327fff26f13e88e5ffbd7204efd357e2bf4ff6bfddabf84f4f2aff36bfd5fbfde2fa49e1bb27b09e7a4d5361dd0cfdfdad2ebe1ef7233bd7eeddfb6fafd305c192c65af7f7ffaabd7e76f2a7ddeb9b9cfbfef767dfe0137f7f99b499fa3589f0f823e8fd35bf45965fd2e7f8d6e9fbfb9f479f7e63eff895bf53989f6f96bfd1a64717f0d6af39bcb675816a8bff85de3006949c2293e56931c8ae8afbfa5fb955e228611b90ce5e69f1f001dea54bccf71cd6ff37ffd5af265a29ffe869f8c7e8dfa77fc2890db5feb17030bd61ebff8b794df7a72f36bff1a5f111ebfade7477cfed16decfbafcd099edf5000fffafcef6f2b61d5f4d708fdb1b35febd7f835fe857fe67ffc070820ebeef2f575d3e68bf1abbca9d6f5346fec6faff26c96d7a374d14cabba2c26a3f427f3ba29aae5677be31dfc374a4fd665bbaef3cf96f9baadb37294be5c4fca62fa7be5d76faab7f9f2b3c98307d9fde9fd4f771fdedbcf770e1efe78bfb3f5b22d16b9f9e075de127e7691ece5f153fcef5ffa177e83bfeeabfb7ff83fb4f557fc1ffffc6ff867fe73ffc26fffa7fe13ffe3df75e7cbe4f29fff6f7ea3f3fff34ffe2dfff1bf79f95bc1fffafbe8ffbfbdbefa4be8ff7bf4ff25fdff4fa1ffff95f4ff7f9f06fd5b3dfb355efd1a5ffe1a5ffc1abfffaf71f26b1c135b9d326b055f7cf96bbca175bb53fafb37a22f7e37f7c5777f8db35fe3f7a2fffffef4e62b6a7446309e3384df8e1afe2667bfc68b5fe30935fd8a7e3efd3588fcbf46f2fcd7c087bf17b52065f66bfc66f8ee8dd7e6313e7c437ffad83c731f3a4c5ed287a97c388c0519c65fe3d74c9ed5d5229d664ddee8ef553bcf29c3c7bf5f156f8b34abdb625ad2f7bffed97252ad97b35ff3d77d5e2cdf36bfe66ff0e5ba950f7e833795c2c06f02e137a3df82f7a9bb27afbff3e4d7fc35c04d9cebf8352ec11cf7771eec41f86905a8a47f9f1387fef82ffd357e8dbf8b7ebefc8de9f7d76d5d2c2ff0faaff11b10e5febc8fe8b3af5eff1a7fd923f6337f8d1ffffcab3312ab5fe36fa3bfff36fae0c79f94d00bfc107bfc9adffd5dfe921ffb31b2b3bfc6fffe6bde835240efa024d88664e4d7b847ffdfa2ffffdaf4ff29faf835d837875c715bf3ff5f4b7ffebafaf3d7d19f1029f9f9ebfd1affe6aff14fd15fffcbaff1df12845ff86bfec6bfe66ff26bfcc4afb94dff96f46ff26bfc21bfe67f4bdffed1fcefe9afb5ff6bfd26bfc6d5aff553f4ef9ffa6bfd21f4ef3ffd6bfdedf4effff16bfd7bbf56f26bfce4af7df26bff7abfc6dff76bff53bfc6e1aff14ffedaac6b7eddfff1d7f92d7e8ddf95fe4d7e8ddfe7d7fdfcd7fd2d7e8d4bfee42fe44ffe71fa24f935fe13fef757f3b7bfc5af87cf9ffe7afbbf5ef26bfc925fefa77fbdb7bfc69ffceb01d37fe8d7fb8be893ff88fffdbf7e3d60f2dbfdfaf8f777f9f5f1ee8b5fffa77fbddfe4d7f8feafff1b13b67f367dfeebfd1a7fd9afff4fd1bf7f0bfffb4fd1bfbfc9aff1dffdfac076fb37f84d7e83dfe4d758ff0618e3dff91bfcd5bf0141fb0dfe17faf737fa31409bfcd8c9af9dfc1a4bfaf737f935fe9e1fc3187fc58ffd6b3ff69bfc1a7793df3af94d7e8d6982dfffd4e4dfa3cfff9904dffe3bfcc9ffc49ffc36bfe1df4e14f8ef7e43c6ea37fa357ea3dfe4d7d8fd8dd0e3f96ff453bfd66ff36bfc95bfd19f07c6518a0b2ffd66bfc6eff86bfc6e342ff8ebd7fc357fb35fe3f7a0bf7e8cd7d17f4dfaee05fdf51bd35fbf3efdfd9b71e4f5dbd3287e77feabe5bf7e539a7ffcf527f05fbf19f9e2f8ebafe2bf7ef35f63cc50fe5182f2dbd33cecd2277ffaaff93bfd1a3ff907fd6bbfe61efdfbeff1bfff19fffbdff3bfff2bfffb7ff3bf3ff66be1dfdf84fefd357f8ddfe2d7fa0b7fc35ff3d7f89d7fadbf94fedde2dfbffab5fe0afaf76ffb757eb7dfa8ffefaff76bfc33bfce1ed1fc5fe47fff2dfaf75f4a31e23fe337f80b7fcd94a0fdc6bf2bfff56bfcf5bfe6ef4e7ffd36fcd71f4a6b6f77e8afdf9efffa237ebb7f80fffa5de5af5fe35fe0bfbe157cb76ffffa6b0893971fe1afffe2d7fc4b7fadbfe937fcb57e8d3f49fffaf57eedbf9dfefa3ff8af3fe2d7f81d7eedbfff37fcb57f8d7fea7793efb67eed7ff437fc757e8d3fee17e2af3ff8d778f06bff93f4d77ff4b1fcf507fcdaffc26ff8ebff1affd596fcf5f6d7fed77ec3dfe0d7f8a3eec85fef7eed7ff7374c7e8d7f4bfffaa3f82ff86cf8ebcfe6bfdee95f7f0dfff54fe95fffcaaffd1fd15fac2ce9af7f97fefa0d7f8df9b6fcf59f53cbdfe8d7f8e7c6f2d7ffca7fedecc85fbfdeaff3dfd35f7f9efef5dbf15fbfc1aefc75e7d7f99fe9af3f4cffdaa7ef7ee35fe3bfd3bf4ef9af377bf2d7777f9dff95fefaa7f4aff9aff37ffc86bfc9aff17bde93bf7e11fdf59bfd1a4ff7e5af1ffc3abfd66ff45bfc1aff99fef547ff3a3ff61bfd56bfc61f765ffefa737f9ddff437fa6d7e8ddfea53f9ebafa0f77edb5fa3d5bffe510aa77ffb5fe3ffd0bffec65fe777fe8d7ec1aff133ac1bffd05fe3effd75b67ea3f4d7f8cb1ec877ffd8af73ff37fa5d7f8dff8aff92d9fce8d7f89fbc961ffd1abfdd816bf9e3bfc6ef7be05afe6ebfc68cff9296bfdbaff1c7792d7ff75fe35ff45afec25fe3dff25ad2343f742d3ffe354e1eba965bbfc6f3e0afbf4efefa35fe835fe71ffd0db77e8dfd47f8ebbff835fff35fe7f16fb4f56b406e7fab5f1ffffe5bdebfffde6f001dfb9ffe06d0c4fff56f804f8e7e0cfffec93f86cfff1cfefdaff5fefdee6f887fff5efef79ff90dd1e65fe3dfff63eff7dfe2d7facde8f75fc5bf7ff51be1f3efff46e6f75ff3d7f803f9937ff1d76108bf0e7eff437f23f4fec7fd46d0ee7fda6f045d2f70fe496ef94ff35b7f1bb7ffe76ffdfb2ffc8d7f1dd219bf0ef9b63ff66bfcce44bb7fe0d7fcce6ff447f3bf7f32fffb67d3bf5ffe467f31fffb57f3277f33fffb77f3bfff30fffb4fff1aa0eabf4cffbef98dfe636ef95ff327ff33fffb63fcef6fcefffef6bf06cbf2afb9f5ebfffabff131fdfe1bffc63ff66b7cf6ebeffd1abfead738fdf57febdff8c77ecdeffefabf3bb900e5afff3bfcc667bfc6bb5fff1ffd0d7fd5aff147fffae96ffc9bff9a7fd2afff9bfe46bfebaff9d7fdfadbbff19d5ff31ff8f57fcfdf78f7d7fc577ffd5382f09fd0e7bf0fc1c97ee387bfe6fffdebaf7fe3e35ff3e037b8a67f9ffe06ffe86f98fd1abfdf6ff0df33843ff037feed7f8dc56ff06712cc3ffc37f8f37ee3b35ff34ff90dbef31bddf935ff92dfe02ff98d7fe2d7fc7b7f83f437fe55bfc63ffa1bfcf5f4fbbf48bfff3ebf26f0fc5d7fcddfe2c7fe11fafd77f9b17f9aa0fdc21ffb477fc3dd5fe33efd5bfc1a9fffd87fff1b1eff9a3fc1bf7fffc7eefc1ac5aff9831ffb0f7ee35f44fdfe67f4ef1ff563ebdff877fd35ff8a1ffb95bf71c1e3fdad7e8dbff5c77e7bf2a5fec91f4b7f93eb5ff3d7497ee16ff247ff9a87c9777ea33ff8d77c9a8c7e93ecd7384b80e74f2480f6fb278f7fa3eb5ff307c94ffc267f327dfbdddfe4cffe35ff72fafc77fd35ffc6e49460feadc9ef47edffaee40f2368ff4af2c7fc267ff1aff99f257fd26ff25753cb3fe33739fe357f05b5fc9b7fcd5ff337fcefe9dfdff037fc477fc3bffbd7fc477f8d3f9fdaffaebfe11f46ffeefd86ff33f572caff4ea94df66bbce37fff04fee42fa37faf7fcd7fe037fc5f7fc37ff8d7fc5f7ec3ffe437f9a79902fff2af79ff37faf57ed3b35fe3f437fa4d7fa333c2f3b7fa4dffed5f73f91bfda3bfe17ffc6bfeadbfd18fffa6bf158deede6f9afd1affca6ff487fd26bb3cd2ecd7f82f7f23f4f57ffe465fd0e7bff96ffcc56ffabbfe9aa3dff8bbbfe96f421ecb7db268bf11458abf0959aa43faf7b7fa358ee8dfdf8e5cbedfe4d7f89dc873fc4d7e8df4d7f89cfefddd7e8ded5ffb77fd359a5fe3fff88dc6e4f7fcbbbfe998a2ee3f9bfefd1d7f8dbf8ffefdf15fe39fa67f3ff935fe15faf737fc352ee8dfc35f63f49b8dc9617c4afffe5ebfc684fe7dcdef7eefd7f843e8f7e9aff1c7d2bf6f7f8d3fed37fb357fe3effcc6bff76f7cf11bff11bff1dffa1bff4bbff17ff51bff9fbff1afff9becfd26b3dfe42fff4dfef1dfe45ff84dfeeddfe47ffa4d7ec3df74eb377df89b3efd4d5ffda6bfdf6ffa6bfd1ab0daffd8afb9fd6be0b75f9b24e437fb4d7e9d3fe8d7b00fbefda9dfe8c5af213ed96f603ffda7f8e7af257ff2433e8f7dc33cbfe5aff1ebf29ffe67c7bfd1ff08772d78f777f84dc593306df77f63c8fbaf43d6f6d7215fe1d7a17e7f9d5fe3afff35febbdf841b3cfea29aadcbfce8d7f82e79b467cbf30a1ef0785696bfc6effffb7f4efe6656fe1acfaa8b933acfdf8e5f96eb8b62d98cd1748c76bf86b4386e9aac698a6500e3d7789e2d26b3ecf77f5e34adbad7f8faf7dff1bf307e367fb31b79e54b78dcbfff5eec1df9eadeafc19d7d376bb24961e228c5eb0939eebf8689db7e0d09ba7e8d2fb2ba99d377d7aff2f32f273f9d4f5b0cf0c9fae2076ea0fa8119f0af213f07bf1f9f2ddbbc3ecf2892fb35cee4330ce8657691831a4f8b665566d7e6ab57d915be319f2a0e6727d56295d5d9a4cc89f2d3755de7cbf6d7b8c8dbdffff7fffd4ff4afdffff77f75fafaf40d8ff8f7bfca9a5f633c6dabfad7700de4ebb317bfff77cf7eaf33fc3c397e7d8a9f5fbef9f629456f5fbd916ff00b7f855fe4bbe6e4f5eb5fa3f9ceeb5fa3be684e974063f66b14efcc307e8de3e7cf7fffd317c74f9e9fbe5642bae8f5d730bf7d912da96dfd6b94d9f2629858c7abe2d738913ff06bb7ddaff132af17458308fb797e9997bf86d2eb278ba6981465d15ef7417f45b19f4f710a94a66f87313825262130f6955f233a5b06ce936a766d90305fea4fb0a321c749559634918476f36b1cd7b57ec9f1e41b9e557d4770eb4805ffed0b83df80193d68219f3c5b2fb93f88a8fefa07ec713b07b2f7ea0964c203ce7f9fd06f610bfea4df84c1f9df714fc1ebfc09922618b4a530e8f0bcca66fccbb78b59fe6b7cf5ea392271e1b5e6d7f87279422993b7eea35fe33baf5f564dfb346bc9d64dabe5eb55b6fc354e4b92e0dffff76fe74503b6aff3ac85b890d8ff1a0d01242eae481449129a6fbff9e239a1b19c31c210adfc4dd55365bf06a9ae7c3129afcd17dfcd274dd1e6c72d85e6933501ef36385d6445793c9bd579d3b8565624ce9507dc7b45996bc26818e817c5b2aab515fdbea161f6d3b661bfd5d3bc99d6c5aa8d7ec944585ef7bf7853b4e586010ba5ce66bdc1bece494b418e8ecbb222e9a064485612b87a4d5f13d39038d47d123d2db28b25cd6b316d7e8da7f9647d7181c976cde4334a8b905d22b6308415bd3ec62088a0f5ebbcbe2ca07ae4830c437e9597d93bfecdeb555fe4c1b7aa3fdcb76fe6c441b3d72d7d35759f66a49524356389f16b7c9eb7a7ef68c02d7d6a3ffcfd1bc6f6d7385dce9aef16ed5c91278e7b4270df1a2df72aff45ebbc1165eeff2edfbeacf3f3e21d0d6439cde4f33398a917ebb20465fe805dc58568b122ec592fd50b1ee7af71d6bc582ff2ba98e2f54b618b5fe3e439215e59c923cc7530272febeadd3544f3cb6579cdc691bb6b8cb4f635a6d8d1e207d2ddc9f36a8abf688078d1581dfcfeec095b96dffff8e4e4f4f5ebdfffe9e98bb3d3a7bfc645defefe9e1141c3cc697f321b2b9aac5c09a37f34802c52fce67a457ae209b48a43eda4aaf35fe3f75e94ac0bd07db5fafd4f7fd13a63cb70027561be98b25efa359adfaba0f7ad51538e7a93bf6b95b24fd64509354156fcde1e7504ea9af95fad488598113efff2f8e9d98bcf7f8d37957e5d921e65f783c9c1bd69d3175fbea04c6455d37c9d2e31474c5ff33bac3638cafdf5457599bf004acdb76932009bec302b4d5891ef54e47d9cbf5bf21f67cb4bca2a3beb05238a5e2d997bb308a24c68ba7b86ef27d6797dfd6bbcc8afc20f0601d09b6400b4152941fe8bad0963f0555df24f1e43592c73b491de4edf918744960a430a7aed7fd16baf30494e7e8de7f992fe7fdef64c1a6902c2d490827ee5bf6d4ff6777c6ae6883d20fc5ebc339f36ac0c7f0dfad358fa8ea96c4263e77d14343a7fe304d0ffd60c2b84127eea5956bcdfe9d17d4c4a8378c876d3bca9d470369e1dc0c73414fe9cbd12386b24c1240fef68ada2ab5fd991ad5656bd7ec940c8c3b7ca1173ecbb4bf89b6639d0652a6bbfc6b991b9136a85b9091c60bcd95082bb51d34f7f2c2e5ed753fe795c5ac78a4cf2aff1edb65d7dd58af7f7ed76e1f0395d4ec94e50e047e2f26bacc4d3083c2ba155d7bd729f7627c66f693fac5e7dfbf5ef0f6d013b12464af075c7b575857f8d5f9b126cbf36a5ce7e6d4a8afdda9450fbb52955f66b53daebc7bffb6b1414511694a32051fe352a5aaa28e8b7b794852d29025efe1a17bfc6aff107fd85cf6865e3730a4b5fd13ac62905a6635af0784e8b249ff3fac96bfadbac7a8c7f0db3a6e23ec3df80e0bef966e1fd1abf7943509684ee8490ce7f8d190d8d3296bf75f16bbcfb35ccf05ed2b717f4ddafd17cb37d8f09ce317dfb92fefd9ce0fd247dfe9afeff84fe8f366f7e8ddfe7d7f835aebee93ecd37a657d3e229f70ed8c7e8f73774eb5bbfc6db6f1a07f3c913faec4b82fb7bf1c2d953f4fbbbdf664deed7f8ada36b7ddea76e79edd7f85d6f5a5bfb357ef3ee3a9df9c483f29b864b80bfc66fde5df0fb35fed8af525aab6a689de29a5929e5df56f4db6794ef6de9e73bfaf72e65621afaef23cafaa08561bc31cbce25fd4b6a503f4b69ed3afd35aee8ef19b59cff1a8fe8afdd5f6387fefbdd29db93d24a684adf2d8839c7f4d6826095f45f413d54044bdec6a7e4db3074bcbfc3ff1fd30a2ae5112c140a8ca9ef31bf0d096ee8b78ade9cf1df171158db8ce139e105a80e1afac6bb357f4e369fdeb9e66fce19ab96de7434429b82a920781f2a2ea4f858875c538b25bf976fc075aa9033fe24a73e05df158fc08c017dedd367ef2ca45500c5ccd610dde26f4d78b453fa5dde73a3bc225864bb69de844613a6cc8ce1f4a123c7071afa3dfd38b7439b636a4d5efc069cf11dfa377cb64d3de54c19cc404b6f54da974fcf70b6264c738cc560f098f8d5cd163836a10cf68f319f4fe9ad827a6f7f8d214eff69827649fff7db82ef05c6f9afb1263ca616b794c45178ced89186940470dba2df46f47d43a2f68abec5ef15a9a08a717bcae3cb7e8d3b4c0181fd63943ddda2be7e7c90a33fa2d69f30cc3b2c3d73faf68adeb9436337305ed348c83955fe7acdfcb4b4d87c9be532ef618bef3e62b914b3d1102516dc664dbf8f79d6cfa985b4dba6fffb7dfe6ed462a523434f9b468c4fbb54dc22aaffdea4029f2b3d520f3f435f9839330ad75ae65cb07a4718971dcc6aa6c69a7e2eb95fc86cc37c242d7e09fd1c9ed9211cce6834211efe2c827b20cd15b582d49fa874e5fc6f4afc964666dae80369e5661a7df9238a431d132fc8cc821b6e6a7bc154d922a9051f0103d140df26e380f1f83836f6d38f3a631e5ba90939f0f65c2c630b71bf79a431bedf348f433c8f99bc49fe86666518eb90e3364be32bfaf6927564792b89847d89c9e32701d76fa2c5a61e3f941e717df43ef4f8d9d04e9ba8318c8d91f073e2ef25b94b9474516bff56b53a65e8e92ff9fd98be6b07b54017fe9006303ed026d9efc21a1386787fc6d0321ef998e7774ab3b115d1b446c3b6ccbfa05ec52dcce804bbe1f7ba1ab54f1f433fa39de5dff71987f8875f672c0dcf8a8cc1ccd161d022e3b9322d64e6fa18dec66ee0a7f81ace53103fe1d75c7cd3c147187475c29edfdc792f62037f8ddf1801624dff417a7e8ddfe70dfdac7e0df1e096e4f5a4443b7c03bac837e704e18ae969f8d1f7f31b9df75f4414c15fe86f4658fd1a875f715b7867574ca9d8db03effe86ceb2fc1a17df34bd420a3de7bfde6019f6b7fcc564f5e0256e11e7ecf2acff1a9f3ca6b9835f094f12710e3c422797c64f8417f86bfcd863d6c347fc162cdae5af816860d67927d493bfc6afcbef667857de39fa35dcdb43fdf6ad66bf9fb0cdaff11bfb3dfc1af9374d55175ebf21ba22103ea5d4c316fd9fa878ef7130e7e1a8805f182732457e1fbc5333355ac21b1269fc76bce54791bbd4fffd5f432236bcfb0b09e2e4d740cc75c85288f70d1c82fc5bfb9fddd55e7e8ddf5c7e3758d227c5374da390f35cb2e0d7f883fef09ba7bc1f147ec403d8c49e2e98435b616fc3a4c2e2015354dff4808d7085b906d3fed7f8453f5bfd7573193ffb3d8623f4f22cdf788e6d688c5e9fd9cf569f968e0fbbb944840afd0c63ca1044a1ee8842fd75e116fd1ad39f2d0c3d2afc3e069b5336809018e4459d731be23cd42a32865f7ffc6be0bf9f3d6eeaceadc9e4fd1abffb133295178ab9fc1ec1efb737864c64fc11ffb647bffdb024dce2fb8d73ff89f6b18146dff8acb83e0746f98d1b537f94969f7f68e3b252fe439c3ddbe7373e4ac039a61e8c53625a1a87f967475be2379877f4fc6bfc2e9b43f55fe3d7fee467118b6fff1a08b8689cbfeb4090ece1b1fdb3109e48c2cfac649cd2a76626685de2b7154df5996aaa91d153df38e77d493f4ff86f385c316c7e8d076160379c1afa5835edc71c16fe9a5f86ef0d277ddd7bb0811feb98e52f1937c3fbc6b5c9777e0d389d5fb29e861cc041ff35eeff620e8f05a3478acf9e878fb31cf7d896fc12faefd7fcc6b914f3f125bf09797cf16bfc1aa748c59b64483fa8318910c1fba3c08f35ef2178f8a6f134bfd102f0e35f036b13738e5ccf193d834ccaa8b97c897cb7ab883efe352477814806b907f9764fdf94dc837c764f3f0bddfafe8ad847346810605f0990fdac0cfd94c5e30b1afa1ffc4d834620f405c91fb8f2f7e7cf87a385df9f88fc6bfc417fe80f078521f3f4fbd36cfed09008e9e03c81df9f988642c61f0e12c361c6ef4f7cfa6bfc815f0f0bf7db87bdff6b7cf161ef8b7b8071b18bf5c9b06cfb8a86e5ecf587f60cc5f705ab3d4000a5c993fc75fee3bff2b7fc137eeaf91ff7ee8f9cfccbf37ff98ff9357e83f4de3ffac7fe0effd35ffbbfff067fe70f7edf9ffcedf7ffa33ffa37f8abffdb377fcfe24ff9a97fffd7fef57e8bdfe0d7f9357e8ddfe237f8b52979f56ba7bfc6aff9ebfc06f4c7aff5ebfd26bfd6eeaff16bddfb357eadfbbfc6afb5f76bfc5afbbfc6aff5e9aff187fc673f5acaffd152feffdf97f2ffa8d58f16f37f3697cb7eb498ffa3c5fc1f2de67f9dc5eb1f2de6ffec6ba71f2de6ff6831ff87bd98ff6bff7abff36ff26bfd7abf0179e2bfebaf9bfe9abfe66ff1bbff3ae9aff19bdff9f5d35ff377fe2db67f8b5dfae837f92d76c933ff4d7ebdf4d7fe4d7e83dfe437e10feeff7ae9aff59bfc26bff36f424d7f8bfbbf51fa6bfe16f77febdfe2b35febb7d8fd9d7f036af91bfc3ae9aff91bfc5ad4eeb7d8fd0d7e5db4fb4dd0fa77c6abf4c7af45dffe26bfc96f90febabf093ff415bea3de7f338263a0fc16bfd9af47fdff06bfc52e40fd4ebfc1bff5e92ffeab2fffdc5ff3afa3bf7ecddf04fffc06c0f4375ffc417f1171e6aff1ebfc41bfc6aff1a751dcf1ebfd5af40ffdfdeaf5f1eeaff1eb6031fcd7fc357eafcb3ff3e3dfffbb8b7fffe59ff2bffe2dffc8fff9ef1efcf3ffdb3f30fac74fffa25fe7ea8bdfe4f7fb977ef33fe6cb7ffbbffbbf7ff11ff63ffd19cfffa05ff6dbfd1687a7bfcee9e23bffd34fedff86ffdefd1ffb27ffd53fe6cffb737eefbff52fcffef647e56ff8937ff6ff74e7b7f8877ef56ff46bfe237b3ff1f9d9dff00f4ffea8f1ab3ff16fdcfa8d7ffcc7ffa9dffc9ff953ffccdff677dbfe937fcdefdd6bffaedfeabfbffb97fdd59ffc4dbfd5ff7df5973ffb9fda7fedf24ffb9b7e9d5f9370fa757ffd5f8b629a5f97c29c3fe80ffef5d35f8be8f707fdc1348a5f8b08421ffdd1bfeeafc134faad7ff33fe88fff357f83dfe2d7f8758852bf93fc21fffe3abfc6aff96bfd4ef4cf6ff03bfdc6bffeaf0baaff5af2f96ff0ebff3abfc96f7ee737bf43a42698bf09bea429a3fffd5af47f9a07e9f12ffef57e8d5f1b84fecd7efddff83771cfaf2573f7bb33067f79f26bfc5abf817649c8009b5fffd79766f2e1af070c7fe7df89e6e4b7f883fe7aeae837a011fcf5bf1683f99d18c2df4dddfd4e78893eff2d7e37fa9bbec2b07ea7dfe4c77efd5f4ffafb9d80ee6f71ffb7b8ff6bfd06669609de6ff96bfe96bf0643f8fbf9df7f98fefd9d7f8bdd5ff0ebff46bf09b3c11ff40fff16bb048d40e2454146bbfca77f3d34fd83fe79a6deeff4bbd837fe69fa2cf60ab1d3afc52ffecbfcefbf2eafffdbbf3ebd4e3f7e1307e05fa73ffb007e03a22ef1f36ff06b25fc0bfefbb57e0319db6ff26bfdd86ff66bfe5abfe66ff63bff825fe337f8b5935ff337f9ad7ffddf90260934fabb3d1ad204fe26bf01a038aafdf7bfc1dff47bfcfe7fe06ffeaf278ff0e56f92001cbdf46bfd5a3ca3bfd36f97fcfa562040bcdff937a021d0acfdcebfc1aff3ebff5a24b2bfc6af4de22888fd6e84d8eeaff96b8ce66dbb7a74f7eed5d5d5f8bcba98d679fe763cad16779f55174fd6173fb8dbac57abaa6ec7f37651fe1abfc647bfe6aff13b4fd74d5b2df27abbc9ebcb629aff9efe7bbfc6aff11bfd9abfc6afbf3bdec17fbfc6aff11b8099f1d02fbf36fff29224ec78364ba7599b5f5475f1837c9616cb49b55eced28cfe5fad5bf9a32c966f9bb4add23c9bced3abe26d9166755b4ccbfce3263d5b9e57e92abbc82997fe6bfe1abf05219b9e0085f47575de5e65357dfe3bff9abfc66ff75dbc752c6ff13b8fd2e7004b6b13bfe6aff13b0066411f724f9d5110bebffeafa988ff068cf82f807278f36bfd36dfadb3d58b6a79fa6e9aafdaa25abe99d7d55523e3fce97fecbbdfc14fa895df9ffe5ffe51f4ff77d02f4f5f2fffe17ff667c6bfe48ff9e22fcc96bfc35f383afc6712fa7efae8f79d56b3fcf7a5be2744eced5f94fdbe2fcbf545b16c7edffc5db6589579f3fb620c40fdf705e6bfefa458da4ff0c178359bfc1abfc62fffa394ccf4fc267f34fd93babf83e78f76bf12862755fdb42cbfc88ae5afb168a6158d7e3c2b4bfeeefffedd7f8df4f78c41f8d1f3a3e747cf8f9e1f3d3f7afe3ffd84c8ff9abfc66f46fffe76b4c0d4fd1c967d27f2399e6fd3ff7fefbfe8d7f835fe30f16df8f9c37eed7dfaf7272938fbfde95facafbca670108bbdbf3faf813ce3158f5fe3d7f8fb7f9dfff1ff1238c647929fbf87fe45e108fb11fef3945bfd2487decf2824430af88c4238a4b8f1fc6efcd61b4e302f7f0d24a65ca2599ebfe9d7f9cf7e2dc0784d9f23a843c2aa0fe91fe2363bf6bf7d4a44efe06d4a5dfc9a9cb05ad07f922421678ac24c24f591bc467f39c1ac18fa0f7e0da41453ee07c97604b8f83bd39ff8a40dbe71e90204b515fd6b02645976794bff4f79fc18d794f1fe985b1bec6591016914cccf6f69f19540fc9a662063dcf120fd72416f9c70409c737ae0357d8645942bee45dafdbebfc66f4f700c9d9e728ac605c58ebedfb5181e07183aec1efd1a7ee215cf0ef9970ef64ffe1a4854361ecc5d0aea77ecffc103bf39b507bc96db2e397877a33238981e4d6f63a22f16a3f06c1167fd9af40d660a6f83422ba20d4624cb23e2423ee7bebed4cf0bedcbe0ba7caf3ef7799c2f0956459fae39d1d11d6d77ac07fccef1af81e5392cc56039e49a30ebbee7de91f77ef4fce8f9d1f3a3e747cf8f9e1f3d3f7a7ef4fce8f9d1f3a32778fe205aaba01fe9c31bdafde8f9d1f3a3e747cf8f9e1f3d3f7a7ef4fce8f9d1f3a3e747cf8f9e1f3d3f7afe3ffbfc3f504b0102140014000000000052a28e3b000000000000000000000000030000000000000000001000b6810000000062696e504b01021400140000000800999e8e3bd069e74f472d000000a00000140000000000000001002000b6812100000062696e2f57696b69496e666f4c696e6b2e646c6c504b05060000000002000200730000009a2d00000000, '2009-12-18T09:22:22', NULL, 0);
INSERT INTO `Plugin` (`ixPlugin`, `fDeleted`, `sPluginId`, `ixSchemaVersion`, `fEnabled`, `sFilename`, `rgbFile`, `dtUpload`, `sVersionLatest`, `fBlacklisted`) VALUES (4, 0, 'wikiinfochanges@fogcreek.com', 0, 1, 'hostedplugin.zip', 0x504b030414000000000052a28e3b0000000000000000000000000300000062696e504b0304140000000800999e8e3b0a1f4b2d001b0000003200001600000062696e2f57696b69496e666f4368616e67652e646c6cedbd07601c499625262f6dca7b7f4af54ad7e074a10880601324d8904010ecc188cde692ec1d69472329ab2a81ca6556655d661640cced9dbcf7de7befbdf7de7befbdf7ba3b9d4e27f7dfff3f5c6664016cf6ce4adac99e2180aac81f3f7e7c1f3f22bef8a93fe9d7f8b57f8d5fe3d7f875e8fffff7fffd6bfc1a7fd7af21cfefa93f373d7f10fdff37f95dfe9edfe4d7f8db7eec9fff5dffae5ff3f93fffbbbe99174dbaaaab8b3a5ba4d36cb9acda7492a7f57a9916cbf4e997afd34535cbc7bff16f9cfc6e0ae3e5e9aff16b3cff357fed5fe3effcaffe90ef18b8ffd1aff16bfdaebfe1aff91bfc1abfc6b7e88f5f4f3efbbf3ea77f52faff1f80bf7e4ff9fdd712bcf1989fbfc65f249f3f79fb6bd0b87ecf3ffcd7f8357e33fe9ffb697ff0f35711dcd7f8e50fa07e7f6dfdd07ffea05fe3d7f88de8c716b5fb9d225f0f3ee9aff16bfc06de9fbf01fdfd6defef719bbf6be9e7afb3256d79acbf96d7403efe03c675534f7f0dc5ed0ff83564a0a3b0ddef49ff1bd779594d05d75fe30ffa3504d64eafdd93f01382fbb9fcfcf6af81577edd5fe337233c7ebbdff9d7f8357e4cbfdfd9fa357e8d7fffd7a4794a05ec4dcf3ffc2bfeae7ffcbffbcbfec0adc9afbaff27ff67bff17f7efe77bdfb6f2ebffc1df6feda3fe24ffa6b7ec3d1fff29bfc310ffebcbf62fdd7fcd6ffeafff2cffe09bffcd7dbf95b7e8dffe5eff9b77ec7f6cffeadb3bf62f5277cabfe0dffcddfe39ffebb7e83f52fff6f467ffa977fd4affd07fcb1ffd1e7cffec09ffedef647a7ffda5fff673ffe13ff8cc5df7bff37fbdfe67fd39ffa697df9777ff67ffd0e3ffd4bfecc5ffef4d7feadfe845ff2af7dfaeffec41f7ef74f18fd7dbfd76f7ef08b7fcb9d5febd7d8253c08e5dffcd7f8ad7e29fdf875feaf5ff3b7f9bf7ecddff0d7dffe6d7f8d8688f7ebfd41f88cbfa87e6d662ffe3df9e4d7f8f5bef5d1aff15bf1b7df4a7e8d6ffd825f6beb37fd357e8d843edbfab5d00c1ffc66f8e0d7f8357ecb9d5f47e9f56bfce6bfd6afbdf59bd3a7bfc6aff15b25bf564defaeb67e0bfab3f92de99f5f42e07f9dfa0e7d96fc7a5bf4d5aff78b7f2bfab4faade91f41e837f835b67e1b7ef7935fe35bbfe5ceaff76bfc7ebf0678167827bfd56f58ff3b032ffec63fe65efc6dfff85f9f86fa5bfe3abff9aff3dbfc5abf98bbfba95ff3d75855bf2d7d4988d11cfe7abf6df3dbd11f7fc96ffeebfc869ffc1abffe6ff4c9aff11b28fea5c88ef4f55bfd46bfd56ffc5bfd96bfce6ff55bfebabfcd6ff9ebfd56bfe5afff5bfd96bfc16ff55bfe58fdeed78c63f05bfe86bff96fe870f8b5abdf9e7ef267bfc5afb1f53ba0ddef880f7eece0d7a63e7eadaddf099ffccef8e717d03fbfe1af5fff7740f177c1bbbf7e4db3b5fab5ab14dffeaef2c933faa4fa887fff5d92eac7f14b7d499f35a43192dfe837a87e77faf11bff58fda7a0d92fa4df7fe18f499f1fe31fff83adee0777dc07d5b74021f9f813fa0733fbeb55237cf7eb57dbf8748c21fcba07ff2578fa37ff75abbbf467fb634aeb6a87fefa6dffaf5febb7fcf5eabf8cd0f82d7ffddffcd73354f98d7e8ddffcd7f96dab5dbcfcebff1abf55b3875f7e83dffc37f88d7f8cdeba477ffc71d4dbafb9b58f1eee63683ff66bfd5abff9afb3f51b52ef60a35f4fd1c387d5a7c0eb37ed7cf39bfffaa609b5788016de97322a00fc8de9436a7080060ff1cfa37090bf417508141ed33fbff96f201f61949ffd1a32918f7eecfffebfff6f37a8dfe5d7f0daff5a325d5bbf8905f66bd47f0551e1d7da225ef8f57e83ea883eaaff25fa60ebf700b41ffbe4d7f8cd7fecb724e9facd936f41360925d23286c7ff835feb661eaf8f7eed5f6365b91772f2e7fc1a2cb70ae377fe756f01e3cfa446bfdd1fff6b5961f9b5abdf93bef8b57926b74867fe7a2421bfedef200d7edddffcd7fd6db68e7f0d48cdaffbdbd6bf82dea45f7e3b69cbf3477ffef6f5affbebf1e75b4fb8e1afb375423f0319fbb57f8db360acbff5af77339ebff6d65390ef8fa7a6bf8eb0ca6908f6d7000d7f7ffaf9eb3bd9adfff201c818aa2fa7cf00ebd78725a36f7f2dd3e03721a1fb9d7f7d9a2ff0c86f283dfdc69ffc1a3ff62deaebd7657fe037e8e889fa935f7fa0c35fef37fff5fcc17c1b101b220309aeeaa7bffcd757fda4b3f1ebffe6bffe6ff3bb18b2fefabfedaf4fff3029abef00c66ff03b56bf17ffacff55bcf71cbf8b54910af8eff191481173be32f28ffd96bf0e71dbaff35bfebaf4efaffb2dccc39ff96bb03d0bc740fec52dc6a0eaeb0ba6dcafff6b572ff0d7971890fdeba560034db0f5131e8cdffcd7304d7e9bea15dafc1a3f56ffc1d4e96fb045fe4602d22b8a3ca7345cf4a7bcf2870f20e7f30ad3f537a42e9852bf7efd3fd23bd51bfedde3c1e380077fd52de0d6dffb31d2c97541ff32a6bfa1e53d3cff36bdfb2ffc33ffe33f403f7e8d3f99fe5fbebe6eda7c317e9537d5ba9ee68dfded559ecdf27a942e9a695597c56494fe645e3745b5fc6c6fbc83ff46e9c9ba6cd775fed9325fb775568ed297eb49594c7faffcfa4df5365f7e3679f020bb3fbdffe9eec37bfbf9cec1c31fef77b65eb6c522371fbccedb5f4b06cccfcbe3a7f8df7ffae7fe9d7fd9dffabd7ffe9ffccb7ea3ffe3dffccd7ebbbff6f05ffe3f7ee9cfe06b52d3bfc6e4d700717e8d5f83accbaff1fbd3a07ea31332edc7bfc68b5fe3f35fe39461fc26fe07afd9a7fb0d9ed2076fe84fbc387aae7fbca67f7fff5fe315fdf69324f9afe9ff5fd25bafe9b3d704e1cb5fe3bbf41731feaff13ba1c909fdff05bf1082ff696af06bfe7a27f36c7991ff9abfbefc6c7ecd5fe769d6e6bfe64f6c7db92cafd3769ea725fdddb4e92fdef925699d5f16a06a9366759e36f3ea6a394e1f67e9bccecf3ffbe817effe928f8e5ed387e929118a1a7cbb68daaabe7e7c373b1adff9357f9357f9345fb6a976449d3f79fd9d27bf26bca75f437cc94b4cd6fd9d077b0ff0c9affb6b94f4ef6f46caf7c77fe9aff16bfc0cfdfc3609d68fbf6eeb627981d77f8d7f8c2cd6cfe0b3af5eff1abfe76f2fbef68f7ffed5d9534c07fdfd4f9116f8f1276505bae38112f8eeeff297fc9a3f862efff75ff3deaff1dbb0eff66b908cb3ab4bcd99ccbf210843ff7fa33fc9fc8059f977ffffbfaefec4b7f29394e3af91d15f7fecaff187d15b7f2b598fdfe4d7f80f7e8dbf873e79fd6b3ef9357f935fe30fff35e7f4ef5ff66bfe49f4efbff96bfe9df4efafff6be1dfd9aff5e4d74a7e8d3ff2d7c25b7f19fdfe5bfc1affc6aff58fd3bfbf92fe4d7e8dbbbff6effc6bff16bfc6f35f1b9fac7f6d7cf2e7d227c9aff177f1bfff327ffb5ff1e7bfc3af93fc3ad4d7aff37bfe3abfffaf71f1eb00af3fe3d7b9a44ffe0efef75ffb75fe30fae47ff875f0d66ff5ebe2f7dfedd7fd3d7f9ddfe4d7f8bd7fddcf7fdddfe4d728f8dfbfe6d7fd63e9dffff4d7059ebfe0d7fb3fe9f7dffbd73bfaf57e13a23ffefd13f9dfbff9d703b6bfe9afff7ffc7ac9aff119ff7bc6fffeb1bffe1f4614f8937ffd8c08fb6ffcfaffecafff9bfc1abffcd77ff26bfd26bfc683dfe04ffa357fbd5fe3d96f90d1e856bf017af9877e8339134ca8263cf09bfd1abff3aff10b89a6f8ebd7fc357f3362d65f489af4d7e24f7e33e2f55ff86bfcc6f4d7af4f33f4ab283afac93fe8d1afb947df4c7fcd47bfc6bf9402ca9ff11bfcdabf664a9ffcc6bf2bfff56bfce6bfe6ef4e7ffd36fcd71ffa6bfcf6bfe61dfaebb7e7bffe88dfee77e3bf7e576db9cf2dbf157cb76fff3aa2bffe28feebbff835ffe35ff329e1f0cbe5bb5fe357fc9acf89674a88f3aff107ff1abff6aff58ab8e86fd2bf7ef35feb27e9afdffb7797bf3efab57e5f1ac7dfa47fedd177bffeaff13bfd42f9ebf2d79a90a4ff47fad79ff46bcd69d47fd8c7f2d7dff96b2d6996fe3dfdeb1ffab55ae5cdffe6d7c1bff77e5df72fe954faf77bbf01b8fcfc37083ff9357f8dbf9ffffdad7f0cfffec21ffb758886c5aff1bbfd9a7fc8aff18bf8df6bfef70fa67fffc85fe38fe67fff64fee4cfe67fff62fef7afe67fffe65f03d4f9bbe9df3feed7f8a7b9e5bfcc9ffcdbfcef8ff1bfbf39fffbdbff1aa0dc7ffc6bfcca5fe7f7a0bf7eb75ff3e9aff963bfc66ff4ebfe5ebfe67ffd6bfc8ebfee8b5ff37ffe35b67fdddffdd7b8f36b7cf6ebb6bfc643faf6f7fe357fcd5ff3677edd2549e6dffeebd6f4ef3ffcebbe2208ffeeaffbeed7dcfd35fea75ff797fc9abff9afb9fdebfda1bfe6effa6bce7ebd3f8414d8e2d7fba37fcd3bbfe61ffaebfdf1bfe6eeaff9e7d127bbbfe65ff9ebfd91bfc6c35f13183efc35ffa15fef4ffd357fe2d7f8677fbde5aff163bfe6bffaebbda27fff43fef77fa07f7fe2d7f8ad7ffd3f8be0ff2ebffeab5fe3f8d7dcfff5ff825ff3b7ff350f7efdbff4d73cfb35bffaf5ffea5ff327a8f7bff1d73cfb35a6bffe1f4dfffea25fff6f25388079f66bfc0c7d92fd9a7fdeafff77d1277ff1af8f4ffeba5fffefa7367f2bc139fb35fe01fab7f835ff935fff9fa5d1fdf7bffebff46b3efc357ffddfe0dff8357fd1aff99bfd067f16c1fced7f83257df2d16ff0ead7c0b7ff1ebd05fcaf7fcdcf7e835ffbd7c227bffeaff507ff9a2f7e83dff8d7faa37fcd8f7eaddf853ff9dd7eadb35fa3a5f67ff0aff907ff069fd0e77ff86ff0bbfc5a195335fb35feacdfe00fa17fff92dfe08fa47fff46fa7df7d7f8e77f836fff5a7ff2aff9effc062fe8dffffc3798ff1a7ff2aff93fd1bffff5aff17ffd065fd127c98f7d8f614e08c2eff8637f0871da6ff06bdcff357ed75fa321ae1fff1af77e8dffe5d71aff1abfe5aff137d1bfbfe3aff1afd2bf3ffe6bfc47f4ef27bfc67f4dfffe86bfc62fa57f0f7f8d4f7fed3149e30bfaf7f722fd3326d38177bff76bfc99f4fbf4d7f88be8dfb7bfc65ffd6b3ffc355fff9a7fc0aff99ffd9affc7aff95bfd5a3bbfd6c1af55fc5aeb5febd7fa3520d9dffa35b77f0dfcf66bff1abfce1ff46bd807dffc2924d7a2777f03fb69c63f7f2dfd1b4ff26bfc62fb86797e4b7ab7fbd9f5aff18ff36bfebbffc8aff9cffefae677b445a0cacfe32faad9bacc8f7e8def166f8bb3e5792576693c2bcb5fe3f7fffd3f27ab9195bfc6b3eae2a4cef3b7e397e5faa2583663341e4bcb5f43da1c374dd634c5b203e7d7f86ed66493c2380ddaf849d6e4bf8671527e0df1307e8d2f273f9d4f5bf4f5647df103d7a77e60fafe35e4e7e0f7e3b3659bd7e719b92abfc6997c06945e661739d07a5a34ab32bba6b14dd7754d86f8d7b8c8dbdffff7fffd4ff4afdffff77f75fafaf4cdaf21e8fffe5759f36b8ca764be7f0dd7441a4cc901225f4ab177fed1af617efb225b529ff5af5112a0616c8f57c5af71227fe0d75ebbafce7e8d131f7fb2e3d3b7c3e0e072b4d7ee955f2336760be74935a3b6af5fff1a27afd4a5b1ed4f6745fbbc58be0d3ef8aa2e7f0d723cf2e5453b37c022188fd1369b94f91bfcf36b9c047fbeaaae7e8dd377ab6c3953bf081fc0d97a03fe20bfa96ec5b77956570b7cde79ff2427cefc6e31935f5e544fea1e7bfe1ac48cf962525e9b2fbe9b4f9aa2cd8f5b023c5913c86e83d3455694c7b3599d378d6b65a7f6bc24ce0475ec7b4599ab6b3d0cf48b6259d5da8a7edfd030fb69dbb0dfea69de4ceb62d546bf3ca91644caebfe176f8ab6dc3060a1d4d9ac37d8d739c90558e8b82cabab9759dd165949e0ea357d3d3ba1df09cfde5b4f8bec6259356d316d7e8da7f9647d7181a972cde4339a54d236242286b0a214c6180411b47e9dd7970544483ec830e4577999bde3dfbc5ef5451e7c5b4c8a921076dfbe213f3c9bbd6ee9aba9fb3423e93254f8353ecfdbd37734d29650b21ffefe0da3f96b08fbfd1aa7cb59f3dda29d2bf224c94f08eedb5fa3b2b24550b46d57089c88193139795957efae11a021a2600508c573d6e02316939e2089ae2c7ec0a3ff354e9e5753fc4578e045a38cf0fbb327bfff77cf7eafb3dffff8e4e4f4f5ebdfffe9e98bb3d3a7fc0d066d651bfa051f5a59eff548e2964d0835ab464cd39f58e7f5f5aff122bf0a3f1804400a689ed7b9b422b9e2bfb8f3e29d25df897c4d0124b159b620bd4dba2887a8d9f7beac299e7d72fd6b34f4e6f36251b41d65c020bfcd512f9ab34a508a3c3d7e736a7e3ff9f6f18bcf4f5f9b3f4f9f9ebdf9f295e1c293aa54f12683f19c7492d0974035e1fbbfffb74f8f9f9ebe4247bf06b73b3b5dae1779cd8898df612ac05dee2fc0585a9a8b5d61cd2ae4b0dfd0f8efed11eb2f2f45131031da9a47de908a3c9b71fb59fb6b8000556d213424050b70820e8774ddaff1edb65d7dd5b258d0ef8bf2743925b903ec69d62521db0000b2bf506fcdaff1457599bfc07ac9ab7c49d405945fa372b84e412dc0c16f2a310df143bdc88c4c7833ed86ef5b107ef579ee6c8e1a04b4e16173a7f8ada0396a48cfc9c7274d735292b3f16b10314e60357eaa5ae686b9cddff4cd4fc1827cf5e6e4d7c0678a140ccad39c1c0f9e9a6af5fb9ffea275c674c237daa8f9f69b2f9e4b5f64684803345def08369d967f8cc9a7e7e3ef522cf196fe7ff66b2c7f8df35fa3224f714e3edcf2d7b8f835f25f634c31bcfcfe6bfc417fe3334a4c7c4e5f2327714aaee4f8d778f96b3cff35bea2cfce387931a6b4c5197d7ef66bc0dd74990af739da014af8edcf0edc5fe30ffcd981ebbe7d499fe113d3ea29a772d0c7f1aff1fbfc1abfc6efbc2977f36b343f5bd8994f9f10347cf77bd16fc08d303a7945537a4953ddd0ff2b9ad631fd7cf76b18067849538d494f7f8dcfe8ffbf67f4bb5fe3b78e7e7ab70f79f96b743f4b090b8c9d52b6bf23be9bd2ff97bf461b301cb1e46fde7d8ffcfe3b8f7f8d19fd7549300afaedb35fe323fe19bef9d1af41eb09bff1e35fe3aeb6a5bf7eff9f2d2a9fd0bb348b7ff0bf9ffe1a8fa9eb966297924987df56f41b506ce9e73bfaf72e0db55104538ad0faa8a7f43b6231ffb3ed5fa3ee11f017730f02759ba0808815b5cbe86f69f3885a2cf9b79c22bff4d758d077a4cae9db25bd011ccfa92d5add233cdf719b5f724bac86b02aa8970bc5ee92bead199b29f55c527bfc4b2a4e719bd03b2dfd57d13bdf44df0d67ec6e4f9b35fd9c318ec0ca5009588071dc4c62a67ecdeb9f2df6e9aa9053561e6f0836dad332c6f71f13de298d00fa17bc037eba891a1fd11b73fef49cdbffe25f63874606aefbc59467f8253cc28cfefa357f53e15aa11c89c96f2a63b77f5ffdb0c7fd15f5440b36bfed2f8ca88dcf7e16f1411e1e30f1f71bfaa6a3c27f63e03361cad09ae6cf1a379cfe1abf3753e405f5ff6dc6e00db5794518bce2b5805f63fb7dd60d7e8ddf7ec17c9f2b8734c4f325f175432b680df147f56b5ca99440367ef6cca460f48a30162a9ff137cf784c5ffc1a6659e4d7f8b5d35fe3d7287eb670c0b7303a30c3cfc1613fb64b32b1f36b502237fbd9eaf3051bdf576c8aa0892744672363dedff4bcfed3be75affdc57febd33ffeff3efa3f7ec35ff1f7fe8a5fe33748effda37feceff03ffdb5fffb6ff077fee0f7fdc9df7eff3ffaa37f83bffabf7df3f72cfe949ffaf77fed5fefb7f80d2869fc5bfc06946cfb358966bfe6aff31bd01fbfd6aff71bd0ba0011f1d7fb2d7eeb5f37fd357fcddfe2b7fff5d35ff377fe2d7ee7dfe277a5bf7e93dfe277a586bf09fff6bbffbae9aff59bfc06bf01fdfe5bdcc1bfbfc96fbe8ddf777f935f877eff4d7e837febd35ffc575ffeb9bfe65f477ffd9af8e8d7449b5ff337cffea0bf088b5dc8fafd69d4cbaff76bfd1abcf8f5eaf5f12e165c90e9ffbd2effcc8f7fffef2efefd977fcafffab7fc23ffe7bf7bf0cfff6fffc0e81f3ffd8b7e9dab2f7e93dfef5ffacdff982fffedffeefffec57fd8fff4673cff837ed96ff75b1c9efe3aa78beffc4f3fb5ff1bfe7bf77fec9ffc57ff983fefcff9bdffd6bf3cfbdb1f95bfe14ffed9ffd39ddfe21ffad5bfd1aff98fecfdc4e7677fc33f3cf9a3c6affec4bf71eb37fef11fffa77ef37fe64ffd337fdbdf6dfb4ffe35bf77affdbb7eabfffeee5ff6577ff237fd56fff7d55ffeec7f6affb5cb3fed6ffa759014fc757ffd5f8b6801f2fca25f2ffdb568b8bfe8d7faf5308c5feb37f9757efd5feb37f9b57efdf4d7a641fee6bfe437fef57fdddf848843fffbb5e8ff449b5f8b52efbfc51ff487ff3ae9aff15bfcf6bf2efdf307fdd1fcef1f4f5f110108d06f80afeef0877f31c1fb0d7e27faf5770631e983bf9a5afd4e201f75fc6bfe26f4dbaff19b6fff067fd3eff1fbff81bff9bf9e3cc247bfc9affb6bfc5abf09fd8bc67ff7afff6bfc3abf099edff6d7ff8d7e13eae1b7f883fefcdfe2ce6ff1bb13945feb37f92deefc26bfc9aff5ebfdfaf8fed7a2d9a5d77ecddfe477fe9d7e3dbcfc3bff4ec9afffebe1f3dff977fa9d7f27c0fc0d7ebd5fe3d7fe4d7ea7df09bfff06bfd3af4fe3c197bfe9afff1bfc26bfc96fb14b00e93f6aca3dfed3bf5efa6bfee6db34cdbfc6af4580882c34e5bf16dea68796a709897f9a5ffe0da8637a77f7d7dafd357f8dd19ce2af4777ef5e5d5d8dcfab8b2987c8d36a7157c3e4bbcd7ab5a23cd7788e00e7d7f8e8d7fc357ee729a5572a8a18b71bc981fc9efe7bb42cf86bfe1abffeee78174bb8942336c9dedf00b9643c27bfe6af714451693a97002aadced35a5619a7b2ca98b6559a67d3797a45714c8aa4ceb4cc3f6e528434e90a21daaff1dbfe9abfc66f41f8a51cd0a7afabf3f68a56377f8d5fe317d20211a29ff458dee2771ea5dd55ccdff5d7fc357e27002fe85bedb43306c2f6d7ff3515eddf80d1fe05e0fc37bfd66ff3dd3a5bbda896a7efa639a7b92881432128b7fd3bffab3fe43bf8099199d2ff9f7e4effbf03d979fafa6ffc65e33ff7cff8fbffa5e33ff87b7fd66ffaef5cfdabffdc31da3cfa7d11eafebed435256d7eb0fd8bb2df579382bf6ffe2e5baccabcf97d4d2cf7fb0af2bfefa458dacf34be5bcd26bfc6aff12f7dae74a6e77fc0efa9fbdb7ffe23af9d3cbfff49553f2dcb2f32ca53739a3b97843a9efffb77ff35d2dfb3fbc28f9e9fb70f56757f8d5fe3b7a3cc40f77308c04ee4733cdfa6ffffde7fc0aff16bfc61a200f8f9c37eed7dfaf727d98ff949b2a1afac67f3fb5b1b8be7efff75fec7ff4be00b2cf3f3f75038640082b5233c4fb9dd4f7214f48c3c4af8f626d381e777e3b7deb02f44691af6b74dbc20cfdff4ebfc67bf1660bc668f0931c34504d23fc46d76ec7ffb64e777e8f33f8bb0fb35c94340bcb3f83524e045dee598a29019fbebf0745bf6d8aee9ef8ae0a5ecb799f038edf8fd29b74ee9f78cbf49c99f93703ce5514aec05ec3ee6d606c794fd7b0ed77f0dccc36f69f112bfff9a289d318e789ed13788e94e18979ce0a7440160d7527f197f8aa7a4f8e2d7b4f478ca184e994eab808e266590d2c87d1c1d7e88cefcb400fa0e120344cfdfc0ebeb277f0d4471364940cf2e795ff8ff0effdf8cf18ca1a1ed92635137cacd99af19b515cdb7c5ab9fcfe9d30b8600aaad885e18e505bdd3fe1aa2625f727f5feae785f667f05dbe77bffb3cde9704afa24fd74499b637eaee980ff89d638e1969a992b8b064beeabeb763df91f76ef5fc9e64d0f1f36073b31f3dffff7cfe1f504b030414000000000052a28e3b0000000000000000000000000900000062696e2f64652d4445504b0304140000000800999e8e3b58df4ba32a080000001000002600000062696e2f64652d44452f57696b69496e666f4368616e67652e7265736f75726365732e646c6cedbd07601c499625262f6dca7b7f4af54ad7e074a10880601324d8904010ecc188cde692ec1d69472329ab2a81ca6556655d661640cced9dbcf7de7befbdf7de7befbdf7ba3b9d4e27f7dfff3f5c6664016cf6ce4adac99e2180aac81f3f7e7c1f3f22bef8a93fe9d7f8b57f8d5fe3d7f875e8fffff7fffd6bfc1a7fd7af21cfefa93f373d7f10fdff37f95dfe9edfe4d7f8db7eec9fff5dffae5ff3f93fffbbbe99174dbaaaab8b3a5ba4d36cb9acda7492a7f57a9916cbf4e997afd34535cbc7bff16f9cfc6e0ae3e5e9aff16b3cff357fed5fe3effeaffe90ef18b8ffd1aff16bfdaebfe1aff91bfc1abfc6af477ffc06f2d9dff0bbd33fe9afa188fd9ef2fbaf2578e3313f7f8d3f483effb3fefc5f83c6f57bfee1bfc6aff19bf1ffdc4ffb839f3704f7bbf8e5f7a4ae2c10eff9037e8d5fe3378a7c7ce3935ad4f9f90de8ef6f7b7f8fdbfc5d4b3fffb65f57daf2587f2daf817cfc078ceba69efe1a8adbefa9ed7e83b01d7dfc7b8eebbcaca68aeb1ff06b08acdfa4d7ee49f8c9aff16bfc49bfbbfcfcf6af81577edd5fe36ffa5d7f8d5fe32f2386f831fdfe5f4a7f8d5fe33fa49f2f5321ed4dcf3ffad55ff6f20ffbf7fe9abffcab7797edc5effa87ff76c91ff1bffc4d9f9dee7dff776effcedfe3cf3afd1dd3dfe4f7fa0bfeefbf79f93ffc892ffff3dfe31ffc7d7ec35ff1af3edd7938fbabffcf7fee9f5bfd4cf55ffcad93dffbe13ff69ffeaeffe3fffe47fc077fc6d33fe77ffa4dfed8bff877fa93fff8cf7fcfbffed7f845ffce4fffafbfddfff63bfe13ffc53ffc9ffc2bffd3effbebbdd9ff87ffe97ffccd7ffdf7fcf11f6ffd67bffcb7f8e37fa7ffe6d7fafdffcadfe577facdefec8f7fe9effaef120effc23ff33ffe03bf26fdfc93e9ffe5ebeba6cd17e3577953adeb69ded8df5ee5d92caf47e9a2995675594c46e94fe6755354cbcff6c63bf86f949eaccb765de79f2df3755b67e5287db99e94c5f4f7caafdf546ff3e56793070fb2fbd3fb9fee3ebcb79fef1c3cfcf17e67eb655b2c72f3c1ebbcc5bcfc9a42ab5fe3e5f153fcef37fbedfeda43fcf92fd2ff7f93139a8ae35fe3c5aff1f9af71fa6bbce656bf66f253797a32cf961779f36b3c79fd9d27bfa602c05c5f02d9fb3b0ff61ee0935ff7d728e9df7f89feffe3bff4d7f8351e53b3ff0dbfbf6eeb6279d1a0c5feaf25ecf3e35fbdfe351eff5a220b3ffef957674fe9e773fafbf7a6777efc49594d1445fae8d7fcf57f2be20774f9bfff9af77e8ddf46d0073b9a9fe677f3ff5fe3d7f8d3f5e7aff76bfceebfc66f49ff3ee17f7f7ffef71dfd8be7d7d47f7f4de2b5c7bfc6eff26bfce6fcef6fcffffeaefceff8d7f80d7f8d7f82fefd2d7f8dff9efefd1d7f8ddd5f73fc6bfcf8af71f66bfe3a7f9022a7507eb75fe36ff935fed940787ecd5f23a17f13fdfdd7f835fe65f9f8f117d56c5de647bf8699f35fc34ed879994f5b9afc5fe3b869f2c5a4bc7e53b4657edc12e526eb36ff35c6d3b6aaed974ff3665a172bbce09a982f4faac52a5b5ef7bf785694b9f298fbf2bbc5dbe26c795ec90493181bd69995e5e097bfc62cdf7e7adafdbaa47fc7fc8dd712cfaf9df28f5ff2d5273ffe1bfe097fd7e99ff127fe1b7fd2dff1e82797bfc66ff077fee0f7fdc9df7eff3ffaa37fabdfefdffa7bffcabfe6ffcafe855ffd07fe9e2fffc5dfe07fff25bfde6ff93fffccaf93fe9abfe66ff207fd4544de5f0314ffd308c2af0722d3dfaf5e1fef62da317bbfd7e59ff9f1efffddc5bffff24ff95fff967fe4fffc770ffef9ffed1f18fde3a77fd1af73f5c56ff2fbfd4bbff91ff3e5bffddffddfbff80ffb9ffe8ce77fd02ffbed7e8bc3d35fe774f19dffe9a7f67fc37feffe8ffd93ffea1ff3e7fd39bff7dffa97677ffba3f237fcc93ffb7fbaf35bfc43bffa37fa35ff91bd9ff8fcec6ff887277fd4f8d59ff8376efdc63ffee3ffd46ffecffca97fe66ffbbb6dffc9bfe6f7eeb57fd76ff5dfdffdcbfeea4ffea6dfeaffbefacb9ffd4fedbf76f9a7fd4dbff0d7fc357e5710223daedb625ae62928f2287d954ff3656be5e6d738f9357f8da3e3d92c250b4533799d56e7692d4da6d2246dab34cfa6f3f40ac03201f671c3e0d2557691ff1abfc66ffb6bfe1abfc5b3ea223da9f3fc6dfaba3a6fafb29a3eff8d7ecd5fe3d7df1def426980ce3fa33a15cf5f60ec56e431ba377c7eff93aa7e5a965f64c552f834cf9917f0fcdfbffbaf91fe9eb197bea1e7d7647df0dbf554bd689c9dc8e778be4dffffbd7fcf5fe3d7f8eb7e6dfe939fbfeed7dea77f7f9254d8ef4fff9efe1aafe8b7b35fe34b526cbf3ffd7cf16b3ca3dff1fcfdbfcefff87f097ca70ff0fc1e0a07baa563167f0de8aa5f93a066bf464d700ad27939c15cfe1ae7bf46c5dfff6efcd61bfa36a34f1bfa3efb355a6a57d15ff2fc4dbfce6ff46b03c66bfabca66f96bfc64504d27f05e547a336ffedff1a13d0e0d7f8b308bb5ff3d738a1360bfa2fa7f6edaf01413bfe3566f45ffa6bcc0952439f5504fb9afeae085e4abfe7bfc6545ba7f4db9cb1bba04f1afa1bad53fa3de36fd25fe38a60bca5ffa73c4a603f65ec3ee6d606c7f4d758d1f78081e7dba4290d5e2b867e4d94ce18473ccfe89b0b7ae78471c9097e4a1400762df597f1a778ca5fe3238263e8f194319c329d56011dbf6b713c0e7074f83da2df5f05e33e09c60d9efa0dbcbe7e92fe5fd3e7ae8f5dd2fcf8ff0effffd7f8357edf5fe377a6f6670c0d6d9704adf44669703218f8fd8d79840d7dbaa6dfa6fcfb9866acfc3544bab688d37ecd5fe3397d7ec15041c915d11023bf2038f0d752faff8c71f8523f2f14073386e53782cb3ed3e5257d57d1a76b6ad1f6a8d3a5cd01bf734c2d1a6ab9206e2d99ffbaefedd877e4bd1f3d3f8f9f54fcc8bfe9fe4d0d7ff4fcfff1f97f00504b0102140014000000000052a28e3b000000000000000000000000030000000000000000001000b6810000000062696e504b01021400140000000800999e8e3b0a1f4b2d001b000000320000160000000000000001002000b6812100000062696e2f57696b69496e666f4368616e67652e646c6c504b0102140014000000000052a28e3b000000000000000000000000090000000000000000001000b681551b000062696e2f64652d4445504b01021400140000000800999e8e3b58df4ba32a08000000100000260000000000000001002000b6817c1b000062696e2f64652d44452f57696b69496e666f4368616e67652e7265736f75726365732e646c6c504b0506000000000400040000010000ea2300000000, '2009-12-18T09:22:22', NULL, 0);
INSERT INTO `Plugin` (`ixPlugin`, `fDeleted`, `sPluginId`, `ixSchemaVersion`, `fEnabled`, `sFilename`, `rgbFile`, `dtUpload`, `sVersionLatest`, `fBlacklisted`) VALUES (5, 0, 'toc@fogcreek.com', 0, 1, 'hostedplugin.zip', 0x504b0304140000000800999e8e3b4c84ed986725000000500000130000005461626c654f66436f6e74656e74732e646c6cedbd07601c499625262f6dca7b7f4af54ad7e074a10880601324d8904010ecc188cde692ec1d69472329ab2a81ca6556655d661640cced9dbcf7de7befbdf7de7befbdf7ba3b9d4e27f7dfff3f5c6664016cf6ce4adac99e2180aac81f3f7e7c1f3f22bef8a93fe9d7f8b57f8d5fe3d7f875e8fffff7fffd6bfc1a7fd7af21cfefa93f373d7f10fdff37f95dfe9edfe4d7f8db7eec9fff5dffae5ff3f93fffbbbe99174dbaaaab8b3a5ba4d36cb9acda7492a7f57a9916cbf4e997afd34535cbc7bff16f9cfc6e0ae3e5e9aff16b3cff357fed5fe32ffae3ffcfef18b8ffd1aff16bfdaebfe1aff91bfc1abfc633fae33790cf9639fd936aa7c00ebfff5a82371ef3f3d7f887e4733cbff6aff17bfee1bfc6aff19bf1ffdc4ffb839fdf8ee0bec62f7f10e1628178cf5ff46bfc1abf11fd58cd7e8d5fe3778a7c3df8a416757e7e03fafbdbdedfe3367fd7d2cff654daf258156ff3d0c77fc0b86eeae9afa1b8fd41f4ff5fefd70801fd1a4c8ddf735ce76535155c8133c37ad16bf724fc84e0e6f2f3dbbf065ef9757f8dff68efd7f835fea4dd5fe3d7f835cdf7dbf4f7afdb7d6bf8f90f7eade6b7fe357e8de497606a7ead9aa0ac7ec9af8d5f7fedaddf863ea63e7ead5f8cbfd37bd4a0f96dd1f2d7c1e47debb7dcf9757e8d835f83fbfdcd7f8d5febd7a9ff287af3b7d9faeda8c16ff37ffd9abfe1afbffddbfc1abfd616b5fcf57ead5f678bb0f9f5b67e7bfae637fbb57e8d5febd7fe75b67e07fa35f9e4d7f8f508c6affd6bec1a18bff69adafd5abfd5fff56bcbfbbfa57ef06bfd6260f64b7e33748a977f47f332bdf75beefc9abfc66ff86b30e97ef35fa3fe930803f9e6b7dcf9757f8d6f99cf0540f53b6134bfd62f06f2bff6aff57ffd7a342bbf5ef33bd367d52f7000f1de3ff86b800f814ff5bbd037bf6d95a2d1ef8a46f2c96fe73ef90de593dfde7df21bfd065bbf0146fb113ef871fa67eb77138afc96bfce6ffeeb6cffd8afcd8d7ee34f7e7f414a51fbddd1cfeffdeb6dfd42faf91b34bf3ebd5f7d0c6cebeffd26bfc6ea77f8e3a9cdaff95bfebabff9affbdbfc7a7fc96ffeebfeb6bf3efdf3db792ffe7134dfbf267df6dbff06f4cfd61683ff357eec5b7fc5afb57547e6efd7fe25bf3ebafa757ec9af8b1fbfaee0f763f4cf2ff9f57822998ebff6aff13b5a3afeebd46b431f27bf56fd5fd3af5b9f5802a15d6adbfdb7b61d8fb4d3f85b06815f43defb3d7e0d96f9dffcd7f8a584c0aff35b6ddd15bafc46bfc1f647bf46fd6bfea6bfc6ea5fa26f7fadad1d108e782269f600e9d7fb83d05adef90d3ff9357e7dc09239ff7519168de3d7e1ee3efa357ead3f087f304ffd0e06c72d6af9ebd59f10746e59ddf3e7bad7eef496edfed05bb6fbf36fd9eeefbd65bb7ffb96ed7ee52ddbfdd6bfd9eddaddbb65bbefdfb2dd9f7acb76ffe62ddbfd8a5bb6fb5d7ff348bb5f9bda1dff1af2fc5abfed2f492024bfed2ff90de5c76f243f7e63f9f19bc88fdf143f4469fe66f89594d203c3e9a293a0d3b9df5f0b8ae0d7e39e80cf9ffa6bb039a0cf7fedad03a0f0dbfc86bf1e740309f7f6ead7f89dfef80348faaff79bff7abfcdaff58b81c79ff79bff7abfedaff58b7f43f98d64fe3792df7efb5feb17ffc6f2dbeff06bfde2df447efb1d7fad5ffc9bca6fbfd16ff31b7ff2dbfe1abfc18ffd4906f0affb6bfcb6bfe127bff9aff163bfedeffd1bffd86ff02714ffd7afc39ffefbbfc6af37fab57ffd4f7ecddfe6b7fc753ef9357ef35f4774e66f4348fffac04f5181d231a8fcba16955fd7a2f2eb5a547e5d8bcaaf6b51f97593e6210df237fc6d7ea34f7e875fef37607c686cdbc9afff1bfcb6bf77f50814a35f7ea3dfe0d7639cf0cdbff3eb5787d05f3ff65bfefabff9af7ffaeb8b901336647ce9ffdfa5ffff71f4ffff92feffe5aff96bfc1a07afe99f2deaead7fb2d7f9d83efe3776af9ebfdfabf4df5f8d750adb8f519fd465ffe9ef8f2b7e87cf9ebffb65ec32369f8dba2e16fb9a1e1afffdb792ffd1ef2d27f42f86cfd56f4926aeadfe037ff0d7e1bfffdbfe437ff0d7e5b1f06fdfddbf970e8efdffed7ffed83bf598d13e83f12a089d17ebddff11b03fd3bfcfabf43acab4f7e175865a2e427bf4dfd7b9198fc980cf1f7a42f1b928ee40760112b53bf01db47b1d3bfce6f957cf21b42069ef8b2f71bfc1a3f205afe98c74bc0ddf0d26f6079e937b0bcf41b585efa0d2c2ffd0696977e031295fa8f27c47e23b818bfde6ffc6bfde213eaae7acac837a7f841cc5a97bfc5afb1aac8314b7ee16ff35bfe7a077f04649a188b59efc77ef31fdbfeb57edbdf90c4e7fbf4a7f9e437a697fe33fbd26ffeebfe06bff9af53ffeff43749deef2d24f89cbe008ced5f9f0ddc27bf6efd9bfc9664e7be8deecfe89f7aefb7ec3667ce1088bf06be01730b9753978f7efafffebfff6feaf5d3dfd2f4da7c07e813cbffb6d5ef45bffd1abff9af0fd7ebd7ab9ecb1fbff9af5b7d01782fe4cf1fabbec42fbfbea2ffeb6ffdb668fb129ffddad54fd08fdffcd7af5e012ccfc3affb6b404a12d1453f0e5df4ebb1d7a024a04eb77f231e1791eb5bd49249f91bfefaf51b60f71a607eabdfe8b7fa8d7fdbdff2d7f96d7ecb5ff7e01f147afebad51bfae237fe0d46bfe98ffd62f814bff9afc3c03ef9357f5b86f79bfd1abf7efd1fdad77f8d4f5efc1a9ffc56f4d17f6b3ffacd7f1d22c9aff36bd8977f2d7eeddfe356bfc26ff5fbf8ad7e1d69456d7eebdf8af8933f6692ffd82ffef5ddaf706984fc0ce4c77e236948804881fddee01119bf807b34a6b988f74b3f14b1fff8d7afff9edfca7cfbebf35cfc96bf1ee94cf640d97765d7fdd7a6ffff3aaab2e0f2ff8ee41fff047df91b7e8332e0c0fc866c7f7e2372687f33faaefa0a48fdd8277bbfc58f6dfd24e6e6d7f8f564dcbfedefc3bc9ffce6c9f66f4d3641dcca5fdf7cf7dbfe79bfc6af416f7c172fa3c93ffc1ffca6bfc58ffd5fbf0d8de477ac7e6fb4fcf70871d0f577ff977e0bd0f5f741c35fe7b7fd2d7f5d12ae4f7eb75fe3d757c9c2abbf2911ec3727d6f80b84ccbf86e5fbdf89288d06fff2aff11b182c7f478be58ffde6bf8ec1e54f63f73440e7dfeaa3f31bfc96bf3e51fed707e57fcddf0974bff8354efe9a5fe337c53cfc5abfc66ffc6b8e1efe9afcfb5ff06bfddabf76f36bc2cffd2966fe5f8ba3937fe9d7350ee6d6f7f8639ec03f8e3efd17fe99fff11fc03cfec9f4fff2f575d3e68bf1abbca9d6f5346fec6faff26c96d7a374d14cabba2c26a3f427f3ba29aae5677be31dfc374a4fd665bbaef3cf96f9baadb37294be5c4fca62fa7be5d76faab7f9f2b3c98307d9fde9fd4f771fdedbcf770e1efe78bfb3f5b22d16b9f9e075de82b97e1366350aee8e9fe27fffcbeff2fbfe89778fffd53ffff7399afe833ff5fbfed83ff2efff657bffc8dffd67fd1effe6a7ffc8aff86fff95edd1effeafd2ffff35faffbf4effff37e9ff7fc6bfd5b42fbefa87da7f9e06f93fd0ff7f3f0295d2cf2f7e4d01fb3b531fff01fdfcbfe9ffc413bfc6df4fffffc5f89cfeff47509b25cdc16ff7e6d7f8f2d738f9357eff5fe3f4d778fa6b9cfd1a6fe837f904cf63f7e52bfaef4bfaffef4fc1ec97f4efb7e9b3637ee5c5aff13945eebf3ffdfff4d7784eff3f210000865e2cf46e73d268bfc6ef34f4e5ef4fd1e3f73637d8fb357e6673837bbfc65fb1b9c1feaff1af6f6e70ffd7f831f80da601be38a1017e458d4e232f3ca1c6fbb76dec53f4f7a5179fdcfe45fcf69a48fc8ada80d467f4263ef9237f4d6f34d2087db809fdb7a9c1b74c833704f5094fd7ef4f9f3ca37f4f180ea60effbefe35fe37197cf56b4ca961c93fdf52b3a7bf46f16b34bfc68a3ec97e8d6b6a9afd1a8b5f23ff357e43f831bfe3e9ac68d397d9459ebec926659e56e7e949b56cf365dbfc9a7bbd8fd2bcaeabfa51faa24ae72482c5f2226daf5779933679994fdb7cf66bfe06df96cf9b5ff377e9bfbda55fa6bf78e797dcf935b7861b34689166cb59fa8b77a9e5f60d2d476826cdf7a87904ef7ef311daca3bf7e89d07b77e678417e4c57d7af1b73b5b4ecbf52c4f6d6b82f18688f26bdef97daa75ba5837ad5227cddab4cc33fabb5ae601fd7ecd976fe6b9a5a1f9aa49af8ab24cb3755b2db2b6986665798d8c60592cdf52abb64acfeb6a91b6f46a6b909f9ab9fb9dcf964d5e0f4eed6f7e9b8f9ebcfe0e49882826c4519750aef7771eec3dc027bf2ef1d3aff16bfc67e458fef82f2575484afcaf2383f9e3afdb1ab8a3c5ff41fed07f47eef88f7ff5fad7f8af46923bfcf1cfbf3a2357f1d7f8dfe8ef3f8b8cf48f3f29ab89a83ed8ee5ff3bb7ffe5f72e7c760c0fff75ff3deaff1db884d274788f38164f97e8ddf8dfe4f1fb3ae813afe5d7e0d69f31bea4ff4f19bff1ae203fc9afaff5fcffb1dd6467efe7abfc61ff66b2ce9afbffcd7f80be8f7bf8e7efff57e8dbf833ff91f7e8d7f95d4fcdd5ff337fb357f8b5fe3e2d7fc0efdfb67fd9aef7ecd5fffd7f83b7e4da8ffff813e4f7e8d67bfd6fd5f2bf935ae7ead09fdfb4b7fddb7bfee6ff16bfc5bbfeedf4ffffe0afa37f9359eff7a8f7ebde4d728f8dfbff8d7fb43e8dfbf91fffd47f9937f8ffffd95fcef6ff1ebe3df4ff8dfa7fcef94fffd83e8dfdfe6d7f8ab7efd3ff3d7ff6d7e8d7f9afffd1ff9dfdfee37c0bf47f46ff26b34bfc11ff01bfc91bfc61ff91b604c7fc76ff067fc06c9aff16fd0bfbf097917bf1961fbbbff183effbd7eec2f209c7f9a3ef94d7e8d3f94fffd0bf8dfbf9efefd1d7e8d7fe6c7fec11f4b7e8dff8bdb3c487e9724f9355e247f00c1799b00da9f91fc0504e1cfe57fffc1e4d1aff79bfc1abf3af9cf93dfe4d7f8ad7ec3ff3cf9f57e8d3bbf2128f6e83704c55efc8668f393fcef9ff91bfeb1bfe16ff16bfc8bbfe1df44fffe8adf1034f98d7e23fc3bfe8d4099cbdfe8edaffbdbfe1a7ff26f04dcfed6df08ed7fa3df18ff7efe1ba3c79fe4df7f5ffa17cfafa9ffe2bfdfecd7f805bfc61de239e1c7df8c14df1d8a697e5dc4c8f4d74ff25fbf01cfed6f46bc71e7d7f88de9f7df89ff9ad15fbf39fdf7bb31b47ff237422cf45bfc1abffbaff15b12a0df8638f6c77ecddf92fefa893fe89fe0b77fc5afb145fffe9ffcfbfd5f738746f86bfd5a19fdfb6334cfbfdeaff15bd0efbff9aff193bfd68afefd437fad963ef95d7e5d70cfb7f8dffbfcefefc9fffe5efcef4fd2bfbff6af91fdba5bbfc6eb3fe80ecdea6ff96bdefb8dffa55feb650a4cfe88dfaefe353fa35efe28feeb9ff835fe925ff38438fa9fe3bffeb15fe31ffb35bf433ed86ff4bbe2af3ff8d7f8d77ecd5704ed77d3bffe835ff327e9afdf57fffae5bfe6f7880a1f7f6460ce880e6ff8af3fe3d7f8ad7fadb724193fa37ffd2ef4d76ff46bfc55fcd71f4a2ddf1195fe36feeb4ffd0dfed45feb677e0d88affcf557fe5a7f30fdf5dbea5f7febaff547d05fa9fef50ffe5a7f1c71cbb7f5af7f89ff5ae95fbf8cfffab3f4af5fe7d7c65fff90fef5dbf25fff95fef52dfeeb37fbdde4afcff8af03fdeb25fff507e85f53feeb8fd2bf7e86fffa9bf4af3f97fffab7f4af7f98ffa2c9e4bffe35fe6b4bfffa1ff8af97fc17a8f417d35f7f11fff54ffc1a7fd4affb8af8e4efd2bffee45ff7afa6bf7eef5f287ffdc5f4dd6ffe6bfccc96fcf5dffeba7f23fdf597f15fffd8aff17ffeba7fc7aff15bfe1a23f65dffe05fe337fbf55e9166faab3e91bf7ec75fef1fa0bf7eb76dd3df67acb57ecd5fe3d7f931fcfb5bff18b4d7efc8bfff3efcfbefcfbfcb277f30fffb5bfc5af8fcd7fab5a0cb7eecd7e2b712fcfbdbf2bfff3afffbebf0bbbfc76f88dfe5df3fe037c42773fefd927fc727bfb67ef2ebfcd81f4c19de7fe1d7f8a3f9df3f99fffdb3e9df7ff5d7f88bf9f7bf9afffd9bf9dfbf9bfffd87f9df7f9afffd97f9df7f9bfffd8ff9dfff9afffd9fe9dffff8d7f855fcefaff96be2931fa37fff8b5fe3b7ff35f1c9effa6b82d37ea35f03fffed8af014aecd2bfbf9c7efff4c7fe8f5fe3e1aff9eac77edd5ff3c798fb7f8cb9fe37fa35663ff6eed738a6b77eab5f73f7d7b8feb1dfe1d7fc895fe34ffdb18f7ecdb35ff32ffbb1ad5ff3f7f935fff61f7bf56b64bfe6bff1636fe9ddff987e7ff86bfe173f76f06bfe46bfc62fffb1cf7ecde2d7fc759263fa3d499efd9a0f7fcddf2479fe6bfee6dcef2ee30968dfff357f11419efe9ad78cd51fccfffee6bfc61f91fc8dbfe61ffd6bfef5c9df4efffe53c93ff06bfe3ed4fe1fa37fffdde4dffe35ff626af31ffd9a7f33b7fcbbf9dfdffed700fffcf6cc29bf15c3ffadb8c7df8a71f8ad7e8dbfecc7bef56ba1f71dfef753fef7b35f0b233dfdb5fe69a6cf6fcf9cf4dbd37ccc7ead87bfc60f7ec357bfc6bfcc90ffe55ff32fff0de7dcb2fab5feed5ff3dff90d2fe9dfff82befd8ff9dbfff8d74c7fa39ff9b5fee75ff3d16ff42f10cea7bfd1ab5fe37ffe355fd0effff3aff93dfe7741ff5eff1a7fd06ff487fe5abfead74c923ffad7fa977fcd3fe6379aff5abf11e3f31bfd1a7fde6ff4b7ff5abfd3aff1effc86ff24fdfbd7fc46ffdcaff563bfd63ff81bd1587eadea37fed77eaddf9546f16bfedabfebaff107fec63ff66bff26a4777e63928ea7bfc63f499af32ffd35ffcb5f734c6ae1dbbff698fc73fcfb97fe1a57bfce9874ecdf4cbfff86bfc66f4efffe8ebfc62fa07f0f7f8d17f4efc9aff18efefdbd7e8d3f9bfe7dcded7ff1aff119b5ff737f8d25fdfbf6d7f8afe893e6d7f81de8f729b7fc437f8d67f4fb1ffb6b7c49fffea9bf46feeb9c718f7fe8aff1f6d7fc6be8df29cde81ffa6b34f4fb5ffa6bfcb5bfe6fff46bfea7fcfbf1aff9b7fe9a3ff66b65fcef1fccfffec5fcef3fccfffec7fcefaff96bfc76bf06bc86df90acf5eb5ff39ffb35ffb55ff3b7fbb57eaf5febf7fbb5fe845feb2ffeb5fe835febd7612bf2ecd7fa93e8df5fffd7f9d3e9dfdff4d7f973e8dfdf89ff3de47fbfcdff7e97ff3de77fd7fcef1fc6fffea9fcef5fc5fffea3fcef7fcefffe72fe37f975ff1c92bcdf90e4eed7227e86d5fa8de9df5f8ba8faebd3bfbf2971faaf453ae637a47f7f73fae6d7227bf49bd2bfbf255243c44bbf25fdfb5bd37fbf16e98cdf96fefd6d89537e2d1acfef48fffef614a3fd5a94f9fb5da03f7e8ddff5d7f8ef7f8ddfedd7fa077fad3fe9137847bfce1fe46ca63cbffc3770bfcbb3e47f7f2dfd4bdafee9fc33fcccb7c0f2ec73b8147ef66ffd1a7f260c70f0eedd5ff31ffc31f33bdafe71bf31e6819b3dfea29aadcbfce8d76057f3cb73e3688e6765f96bbca9a65f644b7257eb5fe359757152e7f9dbf1cb727d512c9bf1778bb7c5b8f3d2af01879b1a97d9f2022f9323397d8b5fe4a538905f03ff704bd3974921fc1a12ffff1a5f4e7e9abc70d7cefda6709b9759dbe6f5f245b6c8f5a5f14955c277a7044433fe3c5fe67531fd359e174dfb07ecfe1a73c6b2f9351a41f74d7661009897dfd06a36a51d2ed665569fbe5bd579834c46f36bd047f9bb5fa3cedd8b18d393f5c50fdcd8f4033bc6e355f16b9cc81ff8753c6d2b8f9cddd6a794e068af7f8d130c1181c2af617e795a34ab32bbfec922bf223496d43df9f43479b9fee5a8f379de12c94f9ae6d7385e2eab366b15dde6d7f8226ba7f35fe3655d512e4507ff6b2c9fe79779f96b3427d90ac4fa358a77bf06e285150fee4d5d2c9e4be8f3dd79d1e6cd2a9b5a0adbb4ccaf617e331358bbbf4de3cf29a6c8cae2071977a299a0b3e579651beb67bfc645defefe5d80f8cc7cdf78bfe3f3375f9efcfea74fcfdee017f7c1ab575fbefafd5f7cf9fb7ffbf4f8e9d98bcf5ffffeaf4f9f9f9ebc397d6a9b986f7a1ffcfebbfd8ff6fa1fddeb7fb4dfffe8befde8ecc5c9f3af9e9ef6fbed7e21c80f7f7df6e2f59b575f9dbc39fbf2850fe4f5e9ab90066f8e9f3c3ffdfdbf7cf6fb9f7cf9e2cde98b37da58c5f2f757867a9191cc187a06b4bc818e010d3bf4ebd0ae43b70ecd3af48ad26a039d6ea651873e71da44e972ae99846fefba5ff7dcaff7dcaffbeed7fbeed74f7f8dfac2085f5f2ffd1adfce9a39e7097e0d88f5b7db45f96b3ccd2947504052f2a7599b4198ad64432bbd2c4902e75539f375b251225f9d8d9fd2bb15e57dbf28dee533ea6bbd58ea4704c97ca93f8f6733f4217f9d11728dea0ec6e45951924a34d83f79fee5c9eff5fb9f3d255a9d3d3b3b7de594c0b90ee7d7386e9a7c3129afe9c55c73bfc72da992c9bacded97bd2f0c1cc9ec8ecfc892d4d5ea755e5f16502d9faf8b996b7c522d7eb2680aa2581fb2f270ff8b37350d6191d56f23ef54abebbab898b7fdaf484bced6d3c81784c32a5b5ec7be589e1717eb9a555cff6b9ad929e9d5f8976f8ad61f53d7503adaea17dfcd270de9e33e20d3e0749115254d304cd770ab2f8a6555eb94d0ef1b1a663f6d1b0eb7126ccfbc09d3d92516bb58560d65cc1ae2f0c9fae2220be6503e53836645c5f004284e3c555ba6900f98ceaff2327bc7bf79c3d41779a6da6252946452ddb75da72523abcc86fdcb958865c586b7b10d9c0066174823fe1af826a369f1bff83524cb86efa659fb6b4cd8142f609f4f28c3588bed3dbdccca750607e055be822453daf7f3ba5aaf9c566025cd9f35f2157f00e9fc3560a28dd5fb490264c94bdcf06b7cbb6d575fb53cd45f03f2fb349fa27358f05fe3ac79b12ecb2febd3c58abe65635a11897e0d12b67b7bbfc6cbac6e72280362bb9ad29abf86f58c9cce9ae54fab859d885f831d2a722c66f8a63b8d79fda25a7e456a2cfcd2bc6cdff5e62b3fcfeb7c39cd4f7fd13a2bc9ed00917512f1fbb729b54b4a12ca89fe7a462956fdc430208fc9fe71c9b4a1d63a2576148b15a579972d98acfc359066afea277575d584ccd8f9e2353c28c7038649583bcf0a4f439092ac2a9aebe5af71fa6e9a8b37752e39df5fe35c94ecebf56451b4bfc6acbc608c455e5ed6f939bc2ee77a2a2f3d5917ace78f572b72f19e174b4f311895dff1ab9e5753b61dc665aa89ac2dfffeec89b18e11e3c0ece57d8abf7912e06cb9bfd470706b7cd33ccf2639c20425347fa662237fd0f0db7aade6ee75de9e62b1e2d738aeebec1aceb8e5ed4607f96b9c2ed70bb04705266bbdbfbea82ef317a0cd190c74c553f36bc8aff9aff1f8655d5cd2349d2d5665bea0de991c4f7392d2b239fac5f7f60ff64e9edcdfdf3edd3fbeb7bd7ffcecdef6c327f7f7b6ef7d7affc9c1f1bd83dd7b0f9efd925f83458ac7f9fbfffe98f462ca789e2d0b66bbd744d6cff6f67f8ddfed775be4edbc9aedbcfb74879ebd7bdbbb8657bf9d972b184b7ecf7cf8acc8cb99f22b60897197262474ce6fef466088a2c6c63b46f6fe0ffac31fff1a734a86fe1ebfc6634af4e7bfc625fdbffc358e28f0dffd35b67f8d4f7f8def537240becd7e8d96feab699169f26bace9379a486ef7fbd1bfdfa795dd3bf4535a4ea9ed8a5a14b434b5a44fc7f4edef41df3ffe35ee525fbf2fa507c2be8e7e8d5ff3d76f7919ebd7f8e3ff696474d381ff1e53972de53ef072cabfade8b7cf7e8d8f189d77f4ef5d0242aa863e39e2dcf02668e6bff1af219ddfa6ed2fbe552bf3df840881b5b90b225b45445b52967a9b3ea978d5aefe351e519b1fa725be87f6ff87ef091f5066347681b54bf478473f1beea1a06f00ffd8fbeffde09ff304b6847343d07e40fd482f7bdccfd7857545700aa2c99cfe02bc258f6241b42a15e68fd9fff029e91d6abfa43731efe7fa968fc350fb3ae8e77db0fe25efcd3de0c7d9adde783f1e5ad18866f41f4674c1e3b8ffb33c0ef3dbefcf22dc32d56f03e1fdc66524769be71df3b4e4d14de9f3257f5bdf728ce6bf610e9bb03ccc6e09efebd00cf06ff3c6fbd1a8e459cf6944f3ce8876a9effbbf065cbddb8dc987d8308d9c26ddb69a149067dce2ed7bc2f5e50e50767e0de491811fe4cefdbea33fef7d4dfcfbd2b0f31ed260fe1be23da35f6e07edebf2c9cf16b7f4e7c0fd7fef3d68fd75c6052aa6d4ff6dde7abf51b9b9829d83edacd91511e702e35cf26ff90f61748f48fe2a765bea5b41f8a6472a1e047a379ae1676fccc2a932f2cdfffd626dd7d52ba24d3092c25a7783cbfbe2711b6c36e1017feb8a292732bfa299cc3e189fcd58dd161ff886a0cff21bc26708ab1fde3c6dc6e6b674f9a6e76908abdbe2139ba7f7c1e9f7e777a7ac43ea1fa22e41df3ffb5a13c19da31d8574d7082c7f31599f5f42ffeed2bf471c44a2e78ce868e236a1cc2f260bf54be86ff87f257d8f18ceffdea71c62bb5f4c1ec42fe13e33867bd7f675f46bfc1abfe5630a44c7bfc6cf10b6777e8d4f28f43cc212e56ffdfbd1a7bf90e04c08f68ac68def7e8d3b6f08c28471fe926cffc9af213ea4f8a00d4129b9ef8b5fe3d7f8eddf508b13c2e594d6cccf7e8d37f49b7cf26b7ce6be7945ff7d49fffffd7f8d17f4f3f7ff35be4d9f1d73fb17bfc6e7b452fefbd3ff4f7f8de7f47f5a3360480e6eb7edaff13b0f7df3fb133d377dbbb7f1db7b1bbfdddff8ed7da6987c8b4f4f682c5f518bd318fef76fdbd2a7dcaf7172fbb7f01badb2d05b5f313dcfe84d7ce246202d00dd9baf4fccb76f08de139e8ddf9f3e7946ff9e3004cc0cfe7dcda305073e614d8058fef7270c0ae62070c635b5136efe358e4f49e2e0454f997f107beffc1a90c48afefd94fe0f1f1edeabf8aecdaf31fa35246611ab9e522ee6df7ffc6b20880443a3d18af32c61a263ca608008829a772c32be408910e05384ffe12797ac52d7daf20d89127eef0bdd8cfebae0cf4570ef3246250b0a323682761d403f52118628ba96229a32a65fe30aa333c226815ec92ade77e90173477192ef1b6e31f5bebfcfdf3bd75de8e2c2466093fc1ae8ad46bfbfb5e050879ffe96e7c41c4b1ef99acddfb77f8d5fe3c71d7573a5def4d7987b9f7cf46bfc1abf364dd4ef1c42bceb8d8b20ff417f7477a07d8df611934640b84907112e0775a08bc6f1765753010d791f9060df0895df50a6a3c0ef3f663ffd5ddca7f84d3ef55afe417fe963fe750811a020b93b37fba2dae73420845068fde39e72dfb5ad6436971b0629862be428f396a00995ff6bdc0d51372434f3d29b955fe3d778f3cffe21fb7fe97ff6cbbef3e7befaf47b7fccc16ff907fe1abfc1dff983dff7277ffbfdffe88ffeb57ebddfe4771039ffb6ca28d808960172faebff7abff56ff15bff9abfc56ff46bff7abfc56fff1bfcd5ffed9bbf67f1a7fcd4bfffeba6bfe6aff95bfccebf5efa6bfd26bfc5effa9bfcfaf8f11bffe6bf3bf1c66ff2eba4bfe66ff29bd0b7bfc96f71e7d7faf57e835f2ffdb57fcddfe037f84d7e9d5f833ea4f7b7e9ffbbd4ead7fc757e8d5fe3b7d8c63fbbbfeeaf4180767fed5f83defc0df019fdb3fb6bff06bfc66ff26bfd7abf1681a53e7e8bfb04edd7fa2dee535fbfc5c35f8b3efcb57fcddfe2b35febd7fa0dd25f43d0faf58474d4efaf89ce7fcd5feb37f8b73efdc57ff5e59ffb6bfe75f88b30f8357fcddffc0ffaa3750c00f99bfce67fd09ffe1ba4bff6aff59bd02f7ff6affb6bd0cfdfe4d7f9f57faddfe4d7fab57ffd5f9310ffb57ecddfe9b7c3787e93dfe20ffa8b7fddf4d7f82dfea0bf9c20fc167fd05ffd1bfc067fd3eff1fbff81bff9bf9e3ca2c1fc5abf090de237a05f7e030cf5d7fc2d7f8d5f0f607ee7dfe9c77efd5f8fa0fd26bfd6effc3bfdba00c1e07e93dfe4f7fc357f8d7b76695753cfe337b4aed18c29c95f2d2f68ad9292e133f3a5ae51fcfa7be31dfcf76bfc1abfceaf49d34798fe5abfd3eff41bfc1a84cc3ffe9bff41ff34e3f6cff378f0f3d7ffb57f8beddf62fbd7fa757e7d22e6afc7e8efcac8fff5dfe0d7fc357e2d4cffaff1dbfd9ae405bcfe4d7e23d30d56e37f1d24c47f13fee2d7faf5be5dcc66f9f2d7fc0d7ffd5fffd7fab57ee75feb37c03fbf2ec8f61bd0187fcb5fe3376052fd4ebfdeaff16bd3bfbfd3afff6bfc3af8f13be1c3dfe977fa2d7efd1ffb9d7f2d6e4a93fd3bd3e410017e7d4c17cdf7efccf4fbaf7f13bcc82f10deffbde0f62b7810ff27cdd36f4020127af13701ddffebdfe0b7f883fe67fae3b7fcf57f039935fa88fef98d08f6aff56334edbff91f0c92fffafcf3b7f88d7e9df4d7f82da195a8afdf3cfdb15f8358e60ffecd7ff33ff8b7fee8d7ff0d7fe75f4b90c2bbbf336126bfd367f2a2e1af5f5789f88fff46bfe6aff1ebef32cdc9bdb8f36bfe1abfdbbd9d3c3bdfd9996c4f763f7db8bd3f9b4db71fdedfdddfce76cf27bbbbf7f2fd870f273431981d6e6f97bed37fe4af4e693529e575a5f47575de5e65759eeeedec1cfc1abf46fa6bfe1abf235628522c89a6bc429156e7a95d1afd357edb5ff3d7f82dfa6fff1abfc6a7bfe6afb17bbc6eabed0b5dee6bd22c6dcdfb537d3f3dafea94e1af083e81dbfd357f8dd19c56321fddbd7b7575353eaf2ea6bcdc35ad167775c9eb6eb35eadaaba1dcf6995f3d7f8353efa357f8ddf79ba6eda8a168ab61b5921fe3dfdf77e8d5fe337e041ff1afccbafcdbffcd6bfe6aff19bb5d5b4dfeed7ff35b5dd6fc0ed7e01b8edcdaff5db7cb7ce56b4a869d7f5deccb13aa860ffa23ffefffc0e7e8273ff18faff1f37a3ff3ffb357e8d57af9fbefeb70ffe89adbff1e327dffe33b78bfffe6c74f4d3a4467e8d9347bf2f96667f5f1dcff62c5be6db0fb6777f5f5decff7df37719d6b19adfd7ae0dfdbe9db5a1dedfd5e4a77f5f5e7ded7e335ecd68da7f8ddf335712d0f3fbe1f7d4fded3f2fbd76f2d05271fdb42cbfa0f5ee5f63d14c2b22d7785696fcddfffdbbff1ae9efd97de1ff450fcd32fdfbdb9195ec7e8ea9db897c8ee7dbf4ffdf9bbef9df8457f8f9df7e6df2b57f8d9f644ff627d9477dad1eacf8adcfe8773c7fffaff33ffe5f02e7d75468f2f3f7503898ff5f4b7f37cf536ef593bf063282cfc894c308c2dd81e386e777e3b7e002c2ac366c8a4d7428cfdff4ebfcdebf3660bc66832ace571fd23eb7d9b1ffed93c1dda1cf7f864cf7afc93eca825d53f151c8496697b6a2b8f4823fcd190318fd865dbad433da88d2cfd951083d1de37ea6bfc677099fb7eca8c03db86028a0f56f69fb16b7c1f3d2e97946df5cd03b27ecace40421a551a2af9662fd8c3fc5f307fc1abf13c131637ecad0a74c0bb7b889c761f152b148d9770847d1f5d7c02bbf8107ff2799168d071739fe1dfdff2e8febb7a2f6670aa566b7bff4467653240bb71e3256d2ecff9a14f5e4842b20a0e58a68e456cb7e8dc867e9aff157d3ff6f433b649bc10b0704e725e3fca5c2291467336613b8dc1ef7df9be7e4e5af815ccc8c7809b1963fb75f772ef6792e42b8dd19e9cec701bf73cc2e2cb2ebe8e39aa0dff4de8f9eff8f3d7fc0aff16bfc46f46375ffa6863f7afefff8fc3f504b030414000000000052a28e3b0000000000000000000000000500000064652d4445504b0304140000000800999e8e3b0005347b4a060000000e00002900000064652d44452f466f67437265656b2e506c7567696e732e57696b692e7265736f75726365732e646c6cedbd07601c499625262f6dca7b7f4af54ad7e074a10880601324d8904010ecc188cde692ec1d69472329ab2a81ca6556655d661640cced9dbcf7de7befbdf7de7befbdf7ba3b9d4e27f7dfff3f5c6664016cf6ce4adac99e2180aac81f3f7e7c1f3f22bef8a93fe9d7f8b57f8d5fe3d7f875e8fffff7fffd6bfc1a7fd7af21cfefa93f373d7f10fdff37f95dfe9edfe4d7f8db7eec9fff5dffae5ff3f93fffbbbe99174dbaaaab8b3a5ba4d36cb9acda7492a7f57a9916cbf4e997afd34535cbc7bff16f9cfc6e0ae3e5e9aff16b3cff357fed5fe35bffd877bf63e0fe47bfc6aff5bbfe86bfe66ff06bfc1abfdeaf21ffa7e7ffc20be9afa188fd9ef2fbaf2578e3313f7f8d3f483ec7f36bff1abfe71ffe6bfc1abf19ffcffdb43ff8f9eb08ee97f8e5f7fc353c20def307fc1abfc66f14f9f8c627fd357e8ddfc0fbf337a0bfbfedfd3d6ef3772dfdfc757e5d69cbe354bccd431fff01e3baa9a7f803b8fd9efaf33708dbd1c7bfe7b8cecb6aaab8fe01bf86c0ea204eed9e849f10ad7522befd6be0955ff7d7d8f95d7f8d5fe36788217e4dfdfe65fa6bfc1aff61f7a50dcfbf4bffff17fe99fff11fc0fb7f32fdbf7c7dddb4f962fc2a6faa753dcd1bfbdbab3c9be5f5285d34d3aa2e8bc928fdc9bc6e8a6af9d9de7807ff8dd29375d9aeebfcb365be6eebac1ca52fd793b298fe5ef9f59bea6dbefc6cf2e041767f7affd3dd87f7f6f39d83873fdeef6cbd6c8b456e3e789db7a08b1ddcf153fcefbf3bfee37f7bfcf9afd2ff7f8bef128d7eff5fe3c5aff1d5aff105fd76fa6bbce296bfe6afb75c2f1679fd6b3c79fd9d27bfa60200792f81ecfd9d077b0ff0c9affb6b94f4ef6f405ffff82ffd357e8d967efebef8fd755b17cb8b062dfea55f4ba6efc7bf7afd6bfc5bbf96f0e28f7ffed5d953faf95fd1df7f1afe7e52561345913efa357ffddfead7f8357e0c5dfeefbfe6bd5fe3b711f47ffd5fc3fd34bf9bffff1abfc67fa63f7fbd5fe377ff357e4bfaf709fffbfbf3bfeff8df3f99fffdebf8df7f92fec5f36beabfbfe6aff163bfc6e35fe377f9357e73fef7b7e77f7f57fef70effbbcbff3ee47fc7bfc66ff86bfc6ef4ef6ff96bfc1ef4efef48041bff1a3fce9f7cf26b7c9ffebdc79f1ffe1a7fe4aff1ebfc418ef0f2fc06bfe6d6afe9b3fcaff96b24f46fa2bf938c98e68fbfa866eb323ffa350caffc1a76a2cfcb7cda12d3fc1ac74d932f26e5f59ba22df3e396283e59b7f9af319eb6556dbf7c9a37d3ba58e105d7c47c79522d56d9f2baffc5cb9aba9fb6b13756d77571318f7cf5a626ee5e64f5dbfe57cf8a325756775f3eab2e4eea3c7f3b7e59ae2f8a6533fe6ef1b620a1368c3c2bcb9bdafc1ab37cfbe9e940ab325b5e8cb981f7029e5f3be51fffec7f7dbdbffadb8a277fd89ffed73df997ff8ebf9326e7effcc1effb93bffdfe7ff447ff56bfe8d7fde2cd3ff6c7ff237fd22ff963ffc5ef8efff63feba35ff1bdf1aff7eba4bfe6aff99bfc0ebfe6aff15bf77afbaa2d48067edd5ff3d72063f2dbfe9abfc66f410d526e91beaecedbabacce7f8d5fe3ceaff96bfc6e9676e93ff257a7fd46e9decece0189d8aff96bfcfabba20e7e8d5fe35f3346839effc1d883c863749a3cbfff49553f2dcb2fb26229fc93e74c4d3cfff7effe6ba4bf670cc4cfd3e7d7647df4db89150d3e8728ee443ec7f36dfaffeffd7bfe1abfc65ff66bf39ffcfc65bff63efdfb93bfc66bd23a3fc96af4f5af714696f605fd7d46ff3e13abfb6bfcfdbfcefff87ff99acbfcfc3df42f98bb8e59fc35a02b7f4d829afd1a35c12948e7e60473f96b9cff1a157fffbbf15b6fe8db8c3e6de8fbecd768a95d457fc9f337fd3abf0edbb8d7f4794ddf2c7f8d8b08a4ff08ca97466dfedbff3526a0018df7b7a4cf4fa8cde2d758711fd734a28cfeca19fa33fae68298f38460e7f4df5bfafd357d764ebd5d31d6d2ee0d29f35fd3f6fb94fedffc1a53c66715e02bf01cb4f1aff192de58d367058f6f4cc6aa652898a3dfc083f993f4ff9a5a3858bbd47ac7feffd7f835e644ad5f93c7dc72db25e1577aa3b9b9efefd26f6fe9ff636ed350fb35fd36e5dfc7bfc68c5a03af92fb794e9f5e700fa0de8ae886d15e1016f085fa9fa5bfc65f4dffbf0d3dd35f638fe7e880e0acb8af2f154ea1633234597ee3637bcef3f892bea9e8b3357ddf46f8e176f3b7cff317c2eace62770e0ff89d636ad150cb05716949544c6f7c8f9f54ddc4fbe6831f3d3f9f9eff07504b0304140000000800999e8e3b9958446bb9060000001000002300000064652d44452f5461626c654f66436f6e74656e74732e7265736f75726365732e646c6cedbd07601c499625262f6dca7b7f4af54ad7e074a10880601324d8904010ecc188cde692ec1d69472329ab2a81ca6556655d661640cced9dbcf7de7befbdf7de7befbdf7ba3b9d4e27f7dfff3f5c6664016cf6ce4adac99e2180aac81f3f7e7c1f3f22bef8a93fe9d7f8b57f8d5fe3d7f875e8fffff7fffd6bfc1a7fd7af21cfefa93f373d7f10fdff37f95dfe9edfe4d7f8db7eec9fff5dffae5ff3f93fffbbbe99174dbaaaab8b3a5ba4d36cb9acda7492a7f57a9916cbf4e997afd34535cbc7bff16f9cfc6e0ae3e5e9aff16b3cff357fed5fe327ffb1ef7ec7c0fd8f7e8d5feb77fd0d7fcddfe0d7f8357e3dfae33790cf5efceef44ffa6b2862bfa7fcfe6b09de78cccf5fe30f92cff1fcdabfc6eff987ff1abfc66fc6ff733fed0f7efe0f42e44bfcf27bfe1abfc63b0bc47bfe805fe3d7f88d221fdff8a416757e7e03fafbdbdedfe3367fd7d2cf37bfaeb4e5b12adee6a18fff8071ddd4d35f4371fb3db5dd6f10b6a38f7fcf719d97d55471fd037e0d81f59bf4da3d093ff9357e8d9ddf5d7e7efbd7c02bbfeeaff1e677fd357e8dbf8a18e2d7d4ef5fa64447f3c72d1e62a15fe35ff867fec77f00affcc9f4fff2f575d3e68bf1abbca9d6f5346fec6faff26c96d7a374d14cabba2c26a3f427f3ba29aae5677be31dfc374a4fd665bbaef3cf96f9baadb37294be5c4fca62fa7be5d76faab7f9f2b3c98307d9fde9fd4f771fdedbcf770e1efe78bfb3f5b22d16b9f9e075de822e7670c74ff1bf4fff915ff1dfe2cfff9afebff5e6d7a87e8d29d1a9e49f6f7f8ddfffd778fa6b14bf46f36bace893ecd7b8fe355ed0bf8b5f23e7f77fcddfeaa7f2f44d3629f3b43a4f4faa659b2fdbe6d778f2fa3b4f7e4ded04f3718901dddf79b0f7009ffcba0488a690befef15ffa6bfc1a2dfdfc367e7fddd6c5f2a2418bbfefd79229fef1af5eff1affd8af25fcfae39f7f75f6947efe6bf4f7bf86bf9f94d54487411ffd9abffe6ff56bfc1a3f862efff75ff3deaff1dbc8107ffd5fc3fd34bf9bffff1abfc67fa63f7fbd5fe377ff357e4bfaf709fffbfbf3bfeff8df3f99fffdebf8df7f92fec5f36beabfbfe6aff163bfc6e35fe377f9357e73fef7b7e77f7f57fef70effbbcbff3ee47fc7bfc66ff86bfc6ef4ef6ff96b9cd2bfbfe3aff133f4ef8ff3279ffc1a7f1afd7befd7f807e8dfc35fe31ffb357e9d3fc84d8e8eedd7fc9d7e4d5f2c7ecd5f23a17f13fdfdd7f8353e32cd1f7f51cdd6657ef46b187efa352c339c97f9b425c6fa358e9b265f4ccaeb37455be6c72d517cb26ef35f633c6dabda7ef9346fa675b1c20bae89f9f2a45aacb2e575ff8b9735753f6d636facaeebe2621ef9ea4d4d12b0c8eab7fdaf9e1565aee2e0be644efbf2dcf01989bc61f359590e7ffb6bccf2eda7a7bdefcb6c7931e6afbca624ec2993f3ef3fddfb37fee11ffbb79efd796f1efc917fe05ff29bff27bfc66ff077fee0f7fdc9df7eff3ffaa37fab5ff4eb7ef1e61ffbe3ff913fe997fcb1ffe277c77ffb9ff5d1aff8def8d7fb75d25ff3d7fc4dd25ff3d7f81dbf5bbc2dd297d9454c2e7e8d4f7fcd5f63f778dd56db17f932afb3366fd22c6d4dbba9b64bcfab3a65382b8243affdb6bfe6aff15b3cab2ed2933acfdfa6afabf3f62aab4902effc9abfc6ef66c99bfe237f75da6f94eeedec1c90ccfd9a504cbfd1aff96bfcfabba25b788cbf9bea3e3c47c6be441ea323e5f9fd4faafa69597e91154be1b53c67fae3f9bf7ff75f23fd3d6320fe3ff2fc9aac6b7e3bb1a2c1e710b39dc8e778be4dffffbd7f4f229f673fd35f679ffefdc95fe33569949f24b97f45bf9d91a57d417f9fd1bfcfc4eafe1a7fffaff33ffe5fbe56323f7f0ffd0b203b66f1d7801efc35096af66bd404a7207d9a13cce5af714e2a1bcfefc66fbda16f33fab461c5dd52bb8afe92e76ffa75fe20b671afe9f39abe59fe1a171148bf2fb7d9b1ffedff1a13d080f4d71e7d7e426d166c0a960405a273fc6bace9b7ead7d82668f834670c5afad9106b65f4ff96fe9d702f29b53ba77fa78c556ba1a4dc774d3fbf4bf8bca5ffa7647a3286883ebe4d5ad4f4bde2f18526e9197d7341ef9c108c9cfe7b4bbfbfe6beda5fe38a2926edfe805fe377223866cc4f19fa9469b10a68e5b078a958a444d9ee284e3aa300affc061efc9f645a341edc5dd2f83bf6ff44eb5fe31750fb338552d3cf8cde7423737d7e493d76fb1bf3b81afa744dbf4df9f7f1af31a3f690cb9238e2d7fc359ed3a7170c156faf886e18edc5af31ff35e087f53f4b7f8dbf9afe7f1b7aa6c40fe08f038233e3717ca9700a1d87a1c3f21b19cfefcd73f792bea9e8b3357ddf063cf075e76c9fe72c84db9db9eebc1df03bc7d4a2a1960beee39aa0dff4de8f9eff973ca9f8a82fefdfd4f047cfff1f9fff07504b01021400140000000800999e8e3b4c84ed986725000000500000130000000000000001002000b681000000005461626c654f66436f6e74656e74732e646c6c504b0102140014000000000052a28e3b000000000000000000000000050000000000000000001000b6819825000064652d4445504b01021400140000000800999e8e3b0005347b4a060000000e0000290000000000000001002000b681bb25000064652d44452f466f67437265656b2e506c7567696e732e57696b692e7265736f75726365732e646c6c504b01021400140000000800999e8e3b9958446bb906000000100000230000000000000001002000b6814c2c000064652d44452f5461626c654f66436f6e74656e74732e7265736f75726365732e646c6c504b050600000000040004001c010000463300000000, '2009-12-18T09:22:22', NULL, 0);
SELECT 'Imported Table Plugin';
SELECT 'Importing Table PluginKeyValue';
SELECT 'Imported Table PluginKeyValue';
SELECT 'Importing Table Prediction';
SELECT 'Imported Table Prediction';
SELECT 'Importing Table Priority';
INSERT INTO `Priority` (`ixPriority`, `sPriority`, `fDefault`) VALUES (1, 'Must Fix', 0);
INSERT INTO `Priority` (`ixPriority`, `sPriority`, `fDefault`) VALUES (2, 'Must Fix', 0);
INSERT INTO `Priority` (`ixPriority`, `sPriority`, `fDefault`) VALUES (3, 'Must Fix', 1);
INSERT INTO `Priority` (`ixPriority`, `sPriority`, `fDefault`) VALUES (4, 'Fix If Time', 0);
INSERT INTO `Priority` (`ixPriority`, `sPriority`, `fDefault`) VALUES (5, 'Fix If Time', 0);
INSERT INTO `Priority` (`ixPriority`, `sPriority`, `fDefault`) VALUES (6, 'Fix If Time', 0);
INSERT INTO `Priority` (`ixPriority`, `sPriority`, `fDefault`) VALUES (7, 'Don\'t Fix', 0);
SELECT 'Imported Table Priority';
SELECT 'Importing Table Project';
INSERT INTO `Project` (`ixProject`, `sProject`, `ixPersonOwner`, `fDeleted`, `fAllowPublicSubmit`, `ixGroup`, `fInbox`, `ixWorkflow`) VALUES (1, 'Sample Project', 2, 0, 0, 1, 0, 1);
INSERT INTO `Project` (`ixProject`, `sProject`, `ixPersonOwner`, `fDeleted`, `fAllowPublicSubmit`, `ixGroup`, `fInbox`, `ixWorkflow`) VALUES (2, 'Inbox', 2, 0, 0, 1, 1, 1);
SELECT 'Imported Table Project';
SELECT 'Importing Table ProjectPercentTime';
SELECT 'Imported Table ProjectPercentTime';
SELECT 'Importing Table ProjectView';
SELECT 'Imported Table ProjectView';
SELECT 'Importing Table Repository';
SELECT 'Imported Table Repository';
SELECT 'Importing Table Revision';
INSERT INTO `Revision` (`ixRevision`, `ixWikiPage`, `ixTemplate`, `ixPerson`, `sRemoteIP`, `nRevision`, `sTitle`, `sBody`, `sComment`, `fDiff`, `dt`, `dblStrength`, `ixTagEventLatest`) VALUES (1, -1, 1, -2, '0.0.0.0', 1, 'Default', '\n<!-- \nCustomize the layout of an entire Wiki by editing this template.\nThis basic template displays the article headline, a small timestamp, and the article body.\n-->\n\n<div class=\"center\"><div id=\"idContainer\">\n\n	<div class=\'wikiSearch\'>\n		<table cellspacing=\'0\' cellpadding=\'0\' border=\'0\'><tr><td>\n			<label for=\'wikiSearchFor\'>Search this wiki</label><br />\n		</td></tr><tr><td>$search$</td></tr></table>\n	</div>\n\n	<h1>$headline$</h1>\n\n	<div id=\"idMeta\">\n        <table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" width=\"100%\"><tr><td>\n			<span class=\"color32\">\n			<i>$lastmodified$<br/>$subscribelink$</i>\n			</span>\n		</td><td align=\"right\">\n			$rsslink$\n		</td></tr></table>\n	</div>\n\n	$body$\n\n	<div id=\"idFooter\">\n        <table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" width=\"100%\">\n		<tr><td colspan=2><strong>Tags: </strong> $tags_vertical$ </td></tr>\n		<tr><td>\n			<span class=\"color32\">\n			<i>Home: <a href=\"$homeurl$\">$homeheadline$</a></i>\n			</span>\n        </td><td align=\"right\">\n			<span class=\"color32\">\n			<i>What\'s new: <a href=\"$recenturl$\">Recently changed articles</a></i>\n			</span>\n		</td></tr></table>\n	</div>\n\n</div></div>\n			$FB_TEMPLATE_DELIMITER$/* Customize the styles of an entire Wiki by editing this stylesheet. */\n\n/* Font Families */\n	span.Arial { font-family: Arial, Helvetica, sans-serif }\n	span.Helvetica { font-family: Helvetica, Arial, sans-serif }\n	span.ArialBlack { font-family: Arial Black, Gadget, sans-serif }\n	span.Comic { font-family: Comic Sans MS, cursive }\n	span.Courier { font-family: Courier, Courier New, monospace }\n	span.Georgia { font-family: Georgia, serif }\n	span.Impact { font-family: Impact, Charcoal, sans-serif }\n	span.Console { font-family: Lucida Console, Monaco, monospace }\n	span.Palatino { font-family: Palatino Linotype, Book Antiqua, Palatino, serif }\n	span.Tahoma { font-family: Tahoma, Geneva, sans-serif }\n	span.Times { font-family: Times New Roman, Times, serif }\n	span.Verdana { font-family: Verdana, Geneva, sans-serif }\n	\n/* Font Sizes */\n	span.LudicrousHuge { font-size: 128px }\n	span.OutrageouslyHuge { font-size: 64px }\n	span.VeryBig { font-size: 26px }\n	span.Big { font-size: 20px }\n	span.Small { font-size: 12px }\n	span.VerySmall { font-size: 10px }\n	span.Microscopic { font-size: 6px }\n	\n/* Paragraph Styles */\n	/* Example: p.ExtraPadding { padding: 25px; } */\n	\n/* Heading Styles */\n	/* Example: h1.HugeBlue { font-size:100px; color: blue; } */\n	\n/* Image Styles */\n	img.FloatLeft { float: left; }\n	img.FloatRight { float: right; }\n	img.Outset {\n		border-top: 1px solid #C7C7C7;\n		border-left: 1px solid #C7C7C7;\n		border-right: 1px solid #444444;\n		border-bottom: 1px solid #444444;\n	}\n	\n/* Table Styles */\n	table.Basic { BORDER-COLLAPSE: collapse }\n	table.Basic TR TD { border:1px solid black; }\n	table.Basic TR TH { border:1px solid black; background-color: #B3EEEE; }\n	\n	table.LightBlue { BORDER-COLLAPSE: collapse; }\n\n	table.LightBlue th {\n		font: bold 12px Arial, Helvetica, Verdana, sans-serif;\n		color: black;\n		border: 1px solid black;\n		background-color: #99C1E9;\n		text-transform: uppercase;\n		text-align: center;\n		padding: 4px;\n	}\n\n	table.LightBlue td {\n		color: black;\n		border: 1px solid black;\n		background-color: #D6E6F6;\n		padding: 4px;\n		text-align: left;\n	}\n\n	table.YellowHighlight { BORDER-COLLAPSE: collapse; }\n\n	table.YellowHighlight th {\n		font: bold 12px Arial, Helvetica, Verdana, sans-serif;\n		color: black;\n		border: 2px solid white;\n		background-color: #E9FDD6;\n		text-transform: uppercase;\n		text-align: center;\n		padding: 4px;\n	}\n\n	table.YellowHighlight td {\n		color: black;\n		border: 2px solid white;\n		background-color: #FDFDD6;\n		padding: 4px;\n		text-align: left;\n	}\n\n	table.DarkBold { BORDER-COLLAPSE: collapse;	}\n\n	table.DarkBold th {\n		font: bold 14px Arial, Helvetica, Verdana, sans-serif;\n		color: white;\n		border: 1px solid black;\n		background-color: black;\n		text-transform: uppercase;\n		text-align: center;\n		padding: 4px;\n	}\n\n	table.DarkBold td {\n		font-weight: bold;\n		color: #9BADBA;\n		border: 1px solid black;\n		background-color: #053353;\n		padding: 4px;\n		text-align: left;\n	}\n\n	table td.Header { font-size: 20px; }\n	table td.Highlight { background-color: yellow; }\n\n	h1 { margin: 0; }\n\n	.center { text-align: center; }\n\n	#idContainer {\n		width: 640px;\n		margin-left: auto;\n		margin-right: auto;\n		text-align: left;\n	}\n\n	#idMeta, #idFooter {\n		padding: 6px 0;\n		font-size: 11px;\n	}\n\n	#idMeta {\n		border-bottom: 2px solid #E9F0F6;\n	}\n\n	#idFooter {\n		border-top: 2px solid #E9F0F6;\n	}\n\n	\n/* Palette Colors */\n	span.color10           { color:            rgb(255,255,255) }\n	span.color10_highlight { background-color: rgb(255,255,255) }\n\n	span.color11           { color:            rgb(0,0,0) }\n	span.color11_highlight { background-color: rgb(0,0,0) }\n\n	span.color12           { color:            rgb(250,243,232) }\n	span.color12_highlight { background-color: rgb(250,243,232) }\n\n	span.color13           { color:            rgb(31,73,125) }\n	span.color13_highlight { background-color: rgb(31,73,125) }\n\n	span.color14           { color:            rgb(92,131,180) }\n	span.color14_highlight { background-color: rgb(92,131,180) }\n\n	span.color15           { color:            rgb(192,80,77) }\n	span.color15_highlight { background-color: rgb(192,80,77) }\n\n	span.color16           { color:            rgb(157,187,97) }\n	span.color16_highlight { background-color: rgb(157,187,97) }\n\n	span.color17           { color:            rgb(128,102,160) }\n	span.color17_highlight { background-color: rgb(128,102,160) }\n\n	span.color18           { color:            rgb(75,172,198) }\n	span.color18_highlight { background-color: rgb(75,172,198) }\n\n	span.color19           { color:            rgb(245,157,86) }\n	span.color19_highlight { background-color: rgb(245,157,86) }\n\n	span.color20           { color:            rgb(216,216,216) }\n	span.color20_highlight { background-color: rgb(216,216,216) }\n\n	span.color21           { color:            rgb(127,127,127) }\n	span.color21_highlight { background-color: rgb(127,127,127) }\n\n	span.color22           { color:            rgb(187,182,174) }\n	span.color22_highlight { background-color: rgb(187,182,174) }\n\n	span.color23           { color:            rgb(199,209,222) }\n	span.color23_highlight { background-color: rgb(199,209,222) }\n\n	span.color24           { color:            rgb(214,224,236) }\n	span.color24_highlight { background-color: rgb(214,224,236) }\n\n	span.color25           { color:            rgb(239,211,210) }\n	span.color25_highlight { background-color: rgb(239,211,210) }\n\n	span.color26           { color:            rgb(230,238,215) }\n	span.color26_highlight { background-color: rgb(230,238,215) }\n\n	span.color27           { color:            rgb(223,216,231) }\n	span.color27_highlight { background-color: rgb(223,216,231) }\n\n	span.color28           { color:            rgb(210,234,240) }\n	span.color28_highlight { background-color: rgb(210,234,240) }\n\n	span.color29           { color:            rgb(252,230,212) }\n	span.color29_highlight { background-color: rgb(252,230,212) }\n\n	span.color30           { color:            rgb(191,191,191) }\n	span.color30_highlight { background-color: rgb(191,191,191) }\n\n	span.color31           { color:            rgb(114,114,114) }\n	span.color31_highlight { background-color: rgb(114,114,114) }\n\n	span.color32           { color:            rgb(162,157,150) }\n	span.color32_highlight { background-color: rgb(162,157,150) }\n\n	span.color33           { color:            rgb(143,164,190) }\n	span.color33_highlight { background-color: rgb(143,164,190) }\n\n	span.color34           { color:            rgb(173,193,217) }\n	span.color34_highlight { background-color: rgb(173,193,217) }\n\n	span.color35           { color:            rgb(223,167,166) }\n	span.color35_highlight { background-color: rgb(223,167,166) }\n\n	span.color36           { color:            rgb(206,221,176) }\n	span.color36_highlight { background-color: rgb(206,221,176) }\n\n	span.color37           { color:            rgb(191,178,207) }\n	span.color37_highlight { background-color: rgb(191,178,207) }\n\n	span.color38           { color:            rgb(165,213,226) }\n	span.color38_highlight { background-color: rgb(165,213,226) }\n\n	span.color39           { color:            rgb(250,206,170) }\n	span.color39_highlight { background-color: rgb(250,206,170) }\n\n	span.color40           { color:            rgb(165,165,165) }\n	span.color40_highlight { background-color: rgb(165,165,165) }\n\n	span.color41           { color:            rgb(89,89,89) }\n	span.color41_highlight { background-color: rgb(89,89,89) }\n\n	span.color42           { color:            rgb(125,121,116) }\n	span.color42_highlight { background-color: rgb(125,121,116) }\n\n	span.color43           { color:            rgb(87,118,157) }\n	span.color43_highlight { background-color: rgb(87,118,157) }\n\n	span.color44           { color:            rgb(132,162,198) }\n	span.color44_highlight { background-color: rgb(132,162,198) }\n\n	span.color45           { color:            rgb(207,123,121) }\n	span.color45_highlight { background-color: rgb(207,123,121) }\n\n	span.color46           { color:            rgb(181,204,136) }\n	span.color46_highlight { background-color: rgb(181,204,136) }\n\n	span.color47           { color:            rgb(159,140,183) }\n	span.color47_highlight { background-color: rgb(159,140,183) }\n\n	span.color48           { color:            rgb(120,192,212) }\n	span.color48_highlight { background-color: rgb(120,192,212) }\n\n	span.color49           { color:            rgb(247,181,128) }\n	span.color49_highlight { background-color: rgb(247,181,128) }\n\n	span.color50           { color:            rgb(140,140,140) }\n	span.color50_highlight { background-color: rgb(140,140,140) }\n\n	span.color51           { color:            rgb(63,63,63) }\n	span.color51_highlight { background-color: rgb(63,63,63) }\n\n	span.color52           { color:            rgb(87,85,81) }\n	span.color52_highlight { background-color: rgb(87,85,81) }\n\n	span.color53           { color:            rgb(23,54,93) }\n	span.color53_highlight { background-color: rgb(23,54,93) }\n\n	span.color54           { color:            rgb(69,98,135) }\n	span.color54_highlight { background-color: rgb(69,98,135) }\n\n	span.color55           { color:            rgb(144,60,57) }\n	span.color55_highlight { background-color: rgb(144,60,57) }\n\n	span.color56           { color:            rgb(117,140,72) }\n	span.color56_highlight { background-color: rgb(117,140,72) }\n\n	span.color57           { color:            rgb(96,76,120) }\n	span.color57_highlight { background-color: rgb(96,76,120) }\n\n	span.color58           { color:            rgb(56,129,148) }\n	span.color58_highlight { background-color: rgb(56,129,148) }\n\n	span.color59           { color:            rgb(183,117,64) }\n	span.color59_highlight { background-color: rgb(183,117,64) }\n\n	span.color60           { color:            rgb(127,127,127) }\n	span.color60_highlight { background-color: rgb(127,127,127) }\n\n	span.color61           { color:            rgb(38,38,38) }\n	span.color61_highlight { background-color: rgb(38,38,38) }\n\n	span.color62           { color:            rgb(62,60,58) }\n	span.color62_highlight { background-color: rgb(62,60,58) }\n\n	span.color63           { color:            rgb(15,36,62) }\n	span.color63_highlight { background-color: rgb(15,36,62) }\n\n	span.color64           { color:            rgb(46,65,90) }\n	span.color64_highlight { background-color: rgb(46,65,90) }\n\n	span.color65           { color:            rgb(96,40,38) }\n	span.color65_highlight { background-color: rgb(96,40,38) }\n\n	span.color66           { color:            rgb(78,93,48) }\n	span.color66_highlight { background-color: rgb(78,93,48) }\n\n	span.color67           { color:            rgb(64,51,80) }\n	span.color67_highlight { background-color: rgb(64,51,80) }\n\n	span.color68           { color:            rgb(37,86,99) }\n	span.color68_highlight { background-color: rgb(37,86,99) }\n\n	span.color69           { color:            rgb(122,78,43) }\n	span.color69_highlight { background-color: rgb(122,78,43) }\n\n\n	@media print {\n		/* Customize the styles of your printed articles by adding styles within this @media block. */\n	}\n	', '', 0, '2009-12-18T09:19:32', 0.0, -1);
SELECT 'Imported Table Revision';
SELECT 'Importing Table Scout';
SELECT 'Imported Table Scout';
SELECT 'Importing Table SearchLog';
SELECT 'Imported Table SearchLog';
SELECT 'Importing Table Setting';
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (1, 'dtLastDailyTask', '2009-12-18 00:00:00');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (2, 'sCustom1', 'Version');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (3, 'sCustom1Help', 'Enter the version that this case is related to.');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (4, 'sCustom2', 'Computer');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (5, 'sCustom2Help', 'Describe the computer and software environment that this case is related to.');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (6, 'fCustom1Visible', '1');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (7, 'fCustom2Visible', '1');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (8, 'fAnybodyCanCreateAccounts', '0');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (9, 'fAnybodyCanCreateCommunityAccounts', '0');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (10, 'fCheckForUpdates', '1');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (11, 'fPluginFailsafe', '0');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (12, 'fInitialConfigDone', '0');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (13, 'fLDAPCanCreateAccounts', '0');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (14, 'fLogOnTextBox', '1');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (15, 'fPasswordEnable', '1');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (16, 'fRememberMeAllowed', '1');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (17, 'sTimeZoneKey', 'W. Europe Standard Time');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (18, 'sLDAPServer', '');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (19, 'sLDAPDomain', '');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (20, 'sLDAPDC', '');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (21, 'sLDAPPasswordURL', '');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (22, 'ixBugTitleWordsBackfill', '0');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (23, 'ixBugEmailBackfill', '0');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (24, 'ixRelBackfill', '1');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (25, 'ixRelBackfillStop', '0');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (26, 'ixBugEventAttachmentBackfill', '1');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (27, 'ixBugEventAttachmentBackfillStop', '0');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (28, 'ixBugEventLatestBackfill', '1');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (29, 'ixBugEventLatestBackfillStop', '0');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (30, 'nWordBackfillLine', '0');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (31, 'ixRevisionStrengthBackfill', '0');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (32, 'cbUploadMax', '10240000');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (33, 'iAuthType', '0');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (34, 'sSMTPServer', '');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (35, 'nSMTPPort', '25');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (36, 'fSMTPSSL', '0');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (37, 'sSMTPUser', '');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (38, 'sSMTPPassword', '');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (39, 'sCVSView', 'default.asp?pg=pgInvalidSourceControl');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (40, 'sCVSDiff', 'default.asp?pg=pgInvalidSourceControl');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (41, 'sLocale', '*');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (42, 'sLanguage', '*');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (43, 'sURLPrefixEmail', '');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (44, 'sSafeExtList', 'tar,gzip,gz,zip,bzip,doc,xls,ppt,docx,xlsx,xml,cty,pdf,csv,rar,txt,jpg,jpeg,bmp,gif,png');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (45, 'sSiteSecret', 'hlhd87apm058j94np9bgthllj6229h');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (46, 'sSiteSecretOld', 'hlhd87apm058j94np9bgthllj6229h');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (47, 'dtSiteSecretRotate', '2009-12-21 09:19:39');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (48, 'fProtectActions', '1');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (49, 'sReplyEmail', '');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (50, 'sCacheVersion', '7.1.5H-734-20091214201239');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (51, 'nTZOffsetLast', '-18000');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (52, 'fTrialDB', '0');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (53, 'ixAttachmentLogo', '-1');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (54, 'ixCategoryDefault', '1');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (55, 'sCasePrefix', '');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (56, 'dtLastHeartbeat', '2001-01-01 00:00:00');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (57, 'fCommunity', '1');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (58, 'ixLatestTextSummaryBackfill', '0');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (59, 'ixLatestTextSummaryBackfillStop', '0');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (60, 'ixResolvedByBackfill', '-1');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (61, 'ixClosedByBackfill', '-1');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (62, 'ixLastEditedByBackfill', '-1');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (63, 'ixBugTZBackfill', '-1');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (64, 'ixBugTZBackfillStop', '-1');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (65, 'ixBugEventTZBackfill', '-1');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (66, 'ixDiscussTopicTZBackfill', '-1');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (67, 'ixDiscussTopicTZBackfillStop', '-1');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (68, 'ixDiscussTopicIPBackfill', '-1');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (69, 'ixDiscussTopicIPBackfillStop', '-1');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (70, 'cMaxEmailToDelete', '200');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (71, 'sForwardToFBSite', '');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (72, 'dtLastSnippetChange', '1970-01-01 00:00:00');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (73, 'dtLastScheduleMaint', '2009-12-18 09:42:03');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (74, 'fCustom1Persist', '1');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (75, 'fCustom2Persist', '1');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (76, 'sPluginModuleId', '5fkv9v06n77e69k4k144mn5kvvc4oo|61f9ef7e603e6602b7109bf04e5c5cac');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (77, 'ixIndexGeneration', '6');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (78, 'ixLowestBugEventIndexed', '2');
INSERT INTO `Setting` (`ixSetting`, `sKey`, `sValue`) VALUES (79, 'ixHighestBugEventIndexed', '3');
SELECT 'Imported Table Setting';
SELECT 'Importing Table ShipDate';
SELECT 'Imported Table ShipDate';
SELECT 'Importing Table Snippet';
SELECT 'Imported Table Snippet';
SELECT 'Importing Table SorterSetting';
SELECT 'Imported Table SorterSetting';
SELECT 'Importing Table SorterToken';
SELECT 'Imported Table SorterToken';
SELECT 'Importing Table Status';
INSERT INTO `Status` (`ixStatus`, `sStatus`, `ixCategory`, `fWorkDone`, `fResolved`, `fDuplicate`, `fDeleted`, `iOrder`) VALUES (1, 'Active', 1, 0, 0, 0, 0, 0);
INSERT INTO `Status` (`ixStatus`, `sStatus`, `ixCategory`, `fWorkDone`, `fResolved`, `fDuplicate`, `fDeleted`, `iOrder`) VALUES (2, 'Resolved (Fixed)', 1, 1, 1, 0, 0, 0);
INSERT INTO `Status` (`ixStatus`, `sStatus`, `ixCategory`, `fWorkDone`, `fResolved`, `fDuplicate`, `fDeleted`, `iOrder`) VALUES (3, 'Resolved (Not Reproducible)', 1, 0, 1, 0, 0, 1);
INSERT INTO `Status` (`ixStatus`, `sStatus`, `ixCategory`, `fWorkDone`, `fResolved`, `fDuplicate`, `fDeleted`, `iOrder`) VALUES (4, 'Resolved (Duplicate)', 1, 0, 1, 1, 0, 2);
INSERT INTO `Status` (`ixStatus`, `sStatus`, `ixCategory`, `fWorkDone`, `fResolved`, `fDuplicate`, `fDeleted`, `iOrder`) VALUES (5, 'Resolved (Postponed)', 1, 0, 1, 0, 0, 3);
INSERT INTO `Status` (`ixStatus`, `sStatus`, `ixCategory`, `fWorkDone`, `fResolved`, `fDuplicate`, `fDeleted`, `iOrder`) VALUES (6, 'Resolved (Won\'t Fix)', 1, 0, 1, 0, 0, 4);
INSERT INTO `Status` (`ixStatus`, `sStatus`, `ixCategory`, `fWorkDone`, `fResolved`, `fDuplicate`, `fDeleted`, `iOrder`) VALUES (7, 'Resolved (By Design)', 1, 0, 1, 0, 0, 5);
INSERT INTO `Status` (`ixStatus`, `sStatus`, `ixCategory`, `fWorkDone`, `fResolved`, `fDuplicate`, `fDeleted`, `iOrder`) VALUES (8, 'Resolved (Implemented)', 2, 1, 1, 0, 0, 0);
INSERT INTO `Status` (`ixStatus`, `sStatus`, `ixCategory`, `fWorkDone`, `fResolved`, `fDuplicate`, `fDeleted`, `iOrder`) VALUES (9, 'Resolved (Won\'t Implement)', 2, 0, 1, 0, 0, 1);
INSERT INTO `Status` (`ixStatus`, `sStatus`, `ixCategory`, `fWorkDone`, `fResolved`, `fDuplicate`, `fDeleted`, `iOrder`) VALUES (10, 'Resolved (Already Exists)', 2, 0, 1, 0, 0, 2);
INSERT INTO `Status` (`ixStatus`, `sStatus`, `ixCategory`, `fWorkDone`, `fResolved`, `fDuplicate`, `fDeleted`, `iOrder`) VALUES (11, 'Resolved (Responded)', 3, 1, 1, 0, 0, 0);
INSERT INTO `Status` (`ixStatus`, `sStatus`, `ixCategory`, `fWorkDone`, `fResolved`, `fDuplicate`, `fDeleted`, `iOrder`) VALUES (12, 'Resolved (Won\'t Respond)', 3, 0, 1, 0, 0, 1);
INSERT INTO `Status` (`ixStatus`, `sStatus`, `ixCategory`, `fWorkDone`, `fResolved`, `fDuplicate`, `fDeleted`, `iOrder`) VALUES (13, 'Resolved (SPAM)', 3, 0, 1, 0, 0, 2);
INSERT INTO `Status` (`ixStatus`, `sStatus`, `ixCategory`, `fWorkDone`, `fResolved`, `fDuplicate`, `fDeleted`, `iOrder`) VALUES (14, 'Resolved (Waiting For Info)', 3, 0, 1, 0, 0, 3);
INSERT INTO `Status` (`ixStatus`, `sStatus`, `ixCategory`, `fWorkDone`, `fResolved`, `fDuplicate`, `fDeleted`, `iOrder`) VALUES (15, 'Resolved (Completed)', 4, 1, 1, 0, 0, 0);
INSERT INTO `Status` (`ixStatus`, `sStatus`, `ixCategory`, `fWorkDone`, `fResolved`, `fDuplicate`, `fDeleted`, `iOrder`) VALUES (16, 'Resolved (Canceled)', 4, 0, 1, 0, 0, 1);
INSERT INTO `Status` (`ixStatus`, `sStatus`, `ixCategory`, `fWorkDone`, `fResolved`, `fDuplicate`, `fDeleted`, `iOrder`) VALUES (17, 'Active', 2, 0, 0, 0, 0, 0);
INSERT INTO `Status` (`ixStatus`, `sStatus`, `ixCategory`, `fWorkDone`, `fResolved`, `fDuplicate`, `fDeleted`, `iOrder`) VALUES (18, 'Resolved (Duplicate)', 2, 0, 1, 1, 0, 3);
INSERT INTO `Status` (`ixStatus`, `sStatus`, `ixCategory`, `fWorkDone`, `fResolved`, `fDuplicate`, `fDeleted`, `iOrder`) VALUES (19, 'Resolved (By Design)', 2, 0, 1, 0, 0, 4);
INSERT INTO `Status` (`ixStatus`, `sStatus`, `ixCategory`, `fWorkDone`, `fResolved`, `fDuplicate`, `fDeleted`, `iOrder`) VALUES (20, 'Active', 3, 0, 0, 0, 0, 0);
INSERT INTO `Status` (`ixStatus`, `sStatus`, `ixCategory`, `fWorkDone`, `fResolved`, `fDuplicate`, `fDeleted`, `iOrder`) VALUES (21, 'Resolved (Duplicate)', 3, 0, 1, 1, 0, 4);
INSERT INTO `Status` (`ixStatus`, `sStatus`, `ixCategory`, `fWorkDone`, `fResolved`, `fDuplicate`, `fDeleted`, `iOrder`) VALUES (22, 'Resolved (By Design)', 3, 0, 1, 0, 0, 5);
INSERT INTO `Status` (`ixStatus`, `sStatus`, `ixCategory`, `fWorkDone`, `fResolved`, `fDuplicate`, `fDeleted`, `iOrder`) VALUES (23, 'Active', 4, 0, 0, 0, 0, 0);
INSERT INTO `Status` (`ixStatus`, `sStatus`, `ixCategory`, `fWorkDone`, `fResolved`, `fDuplicate`, `fDeleted`, `iOrder`) VALUES (24, 'Resolved (Duplicate)', 4, 0, 1, 1, 0, 2);
INSERT INTO `Status` (`ixStatus`, `sStatus`, `ixCategory`, `fWorkDone`, `fResolved`, `fDuplicate`, `fDeleted`, `iOrder`) VALUES (25, 'Resolved (By Design)', 4, 0, 1, 0, 0, 3);
SELECT 'Imported Table Status';
SELECT 'Importing Table Subscriptions';
SELECT 'Imported Table Subscriptions';
SELECT 'Importing Table Tag';
SELECT 'Imported Table Tag';
SELECT 'Importing Table TagAssociation';
SELECT 'Imported Table TagAssociation';
SELECT 'Importing Table TagEvent';
SELECT 'Imported Table TagEvent';
SELECT 'Importing Table Template';
INSERT INTO `Template` (`ixTemplate`, `ixRevision`, `sTemplate`, `sBody`, `fDeleted`) VALUES (1, 1, 'Default', '\n<!-- \nCustomize the layout of an entire Wiki by editing this template.\nThis basic template displays the article headline, a small timestamp, and the article body.\n-->\n\n<div class=\"center\"><div id=\"idContainer\">\n\n	<div class=\'wikiSearch\'>\n		<table cellspacing=\'0\' cellpadding=\'0\' border=\'0\'><tr><td>\n			<label for=\'wikiSearchFor\'>Search this wiki</label><br />\n		</td></tr><tr><td>$search$</td></tr></table>\n	</div>\n\n	<h1>$headline$</h1>\n\n	<div id=\"idMeta\">\n        <table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" width=\"100%\"><tr><td>\n			<span class=\"color32\">\n			<i>$lastmodified$<br/>$subscribelink$</i>\n			</span>\n		</td><td align=\"right\">\n			$rsslink$\n		</td></tr></table>\n	</div>\n\n	$body$\n\n	<div id=\"idFooter\">\n        <table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" width=\"100%\">\n		<tr><td colspan=2><strong>Tags: </strong> $tags_vertical$ </td></tr>\n		<tr><td>\n			<span class=\"color32\">\n			<i>Home: <a href=\"$homeurl$\">$homeheadline$</a></i>\n			</span>\n        </td><td align=\"right\">\n			<span class=\"color32\">\n			<i>What\'s new: <a href=\"$recenturl$\">Recently changed articles</a></i>\n			</span>\n		</td></tr></table>\n	</div>\n\n</div></div>\n			$FB_TEMPLATE_DELIMITER$/* Customize the styles of an entire Wiki by editing this stylesheet. */\n\n/* Font Families */\n	span.Arial { font-family: Arial, Helvetica, sans-serif }\n	span.Helvetica { font-family: Helvetica, Arial, sans-serif }\n	span.ArialBlack { font-family: Arial Black, Gadget, sans-serif }\n	span.Comic { font-family: Comic Sans MS, cursive }\n	span.Courier { font-family: Courier, Courier New, monospace }\n	span.Georgia { font-family: Georgia, serif }\n	span.Impact { font-family: Impact, Charcoal, sans-serif }\n	span.Console { font-family: Lucida Console, Monaco, monospace }\n	span.Palatino { font-family: Palatino Linotype, Book Antiqua, Palatino, serif }\n	span.Tahoma { font-family: Tahoma, Geneva, sans-serif }\n	span.Times { font-family: Times New Roman, Times, serif }\n	span.Verdana { font-family: Verdana, Geneva, sans-serif }\n	\n/* Font Sizes */\n	span.LudicrousHuge { font-size: 128px }\n	span.OutrageouslyHuge { font-size: 64px }\n	span.VeryBig { font-size: 26px }\n	span.Big { font-size: 20px }\n	span.Small { font-size: 12px }\n	span.VerySmall { font-size: 10px }\n	span.Microscopic { font-size: 6px }\n	\n/* Paragraph Styles */\n	/* Example: p.ExtraPadding { padding: 25px; } */\n	\n/* Heading Styles */\n	/* Example: h1.HugeBlue { font-size:100px; color: blue; } */\n	\n/* Image Styles */\n	img.FloatLeft { float: left; }\n	img.FloatRight { float: right; }\n	img.Outset {\n		border-top: 1px solid #C7C7C7;\n		border-left: 1px solid #C7C7C7;\n		border-right: 1px solid #444444;\n		border-bottom: 1px solid #444444;\n	}\n	\n/* Table Styles */\n	table.Basic { BORDER-COLLAPSE: collapse }\n	table.Basic TR TD { border:1px solid black; }\n	table.Basic TR TH { border:1px solid black; background-color: #B3EEEE; }\n	\n	table.LightBlue { BORDER-COLLAPSE: collapse; }\n\n	table.LightBlue th {\n		font: bold 12px Arial, Helvetica, Verdana, sans-serif;\n		color: black;\n		border: 1px solid black;\n		background-color: #99C1E9;\n		text-transform: uppercase;\n		text-align: center;\n		padding: 4px;\n	}\n\n	table.LightBlue td {\n		color: black;\n		border: 1px solid black;\n		background-color: #D6E6F6;\n		padding: 4px;\n		text-align: left;\n	}\n\n	table.YellowHighlight { BORDER-COLLAPSE: collapse; }\n\n	table.YellowHighlight th {\n		font: bold 12px Arial, Helvetica, Verdana, sans-serif;\n		color: black;\n		border: 2px solid white;\n		background-color: #E9FDD6;\n		text-transform: uppercase;\n		text-align: center;\n		padding: 4px;\n	}\n\n	table.YellowHighlight td {\n		color: black;\n		border: 2px solid white;\n		background-color: #FDFDD6;\n		padding: 4px;\n		text-align: left;\n	}\n\n	table.DarkBold { BORDER-COLLAPSE: collapse;	}\n\n	table.DarkBold th {\n		font: bold 14px Arial, Helvetica, Verdana, sans-serif;\n		color: white;\n		border: 1px solid black;\n		background-color: black;\n		text-transform: uppercase;\n		text-align: center;\n		padding: 4px;\n	}\n\n	table.DarkBold td {\n		font-weight: bold;\n		color: #9BADBA;\n		border: 1px solid black;\n		background-color: #053353;\n		padding: 4px;\n		text-align: left;\n	}\n\n	table td.Header { font-size: 20px; }\n	table td.Highlight { background-color: yellow; }\n\n	h1 { margin: 0; }\n\n	.center { text-align: center; }\n\n	#idContainer {\n		width: 640px;\n		margin-left: auto;\n		margin-right: auto;\n		text-align: left;\n	}\n\n	#idMeta, #idFooter {\n		padding: 6px 0;\n		font-size: 11px;\n	}\n\n	#idMeta {\n		border-bottom: 2px solid #E9F0F6;\n	}\n\n	#idFooter {\n		border-top: 2px solid #E9F0F6;\n	}\n\n	\n/* Palette Colors */\n	span.color10           { color:            rgb(255,255,255) }\n	span.color10_highlight { background-color: rgb(255,255,255) }\n\n	span.color11           { color:            rgb(0,0,0) }\n	span.color11_highlight { background-color: rgb(0,0,0) }\n\n	span.color12           { color:            rgb(250,243,232) }\n	span.color12_highlight { background-color: rgb(250,243,232) }\n\n	span.color13           { color:            rgb(31,73,125) }\n	span.color13_highlight { background-color: rgb(31,73,125) }\n\n	span.color14           { color:            rgb(92,131,180) }\n	span.color14_highlight { background-color: rgb(92,131,180) }\n\n	span.color15           { color:            rgb(192,80,77) }\n	span.color15_highlight { background-color: rgb(192,80,77) }\n\n	span.color16           { color:            rgb(157,187,97) }\n	span.color16_highlight { background-color: rgb(157,187,97) }\n\n	span.color17           { color:            rgb(128,102,160) }\n	span.color17_highlight { background-color: rgb(128,102,160) }\n\n	span.color18           { color:            rgb(75,172,198) }\n	span.color18_highlight { background-color: rgb(75,172,198) }\n\n	span.color19           { color:            rgb(245,157,86) }\n	span.color19_highlight { background-color: rgb(245,157,86) }\n\n	span.color20           { color:            rgb(216,216,216) }\n	span.color20_highlight { background-color: rgb(216,216,216) }\n\n	span.color21           { color:            rgb(127,127,127) }\n	span.color21_highlight { background-color: rgb(127,127,127) }\n\n	span.color22           { color:            rgb(187,182,174) }\n	span.color22_highlight { background-color: rgb(187,182,174) }\n\n	span.color23           { color:            rgb(199,209,222) }\n	span.color23_highlight { background-color: rgb(199,209,222) }\n\n	span.color24           { color:            rgb(214,224,236) }\n	span.color24_highlight { background-color: rgb(214,224,236) }\n\n	span.color25           { color:            rgb(239,211,210) }\n	span.color25_highlight { background-color: rgb(239,211,210) }\n\n	span.color26           { color:            rgb(230,238,215) }\n	span.color26_highlight { background-color: rgb(230,238,215) }\n\n	span.color27           { color:            rgb(223,216,231) }\n	span.color27_highlight { background-color: rgb(223,216,231) }\n\n	span.color28           { color:            rgb(210,234,240) }\n	span.color28_highlight { background-color: rgb(210,234,240) }\n\n	span.color29           { color:            rgb(252,230,212) }\n	span.color29_highlight { background-color: rgb(252,230,212) }\n\n	span.color30           { color:            rgb(191,191,191) }\n	span.color30_highlight { background-color: rgb(191,191,191) }\n\n	span.color31           { color:            rgb(114,114,114) }\n	span.color31_highlight { background-color: rgb(114,114,114) }\n\n	span.color32           { color:            rgb(162,157,150) }\n	span.color32_highlight { background-color: rgb(162,157,150) }\n\n	span.color33           { color:            rgb(143,164,190) }\n	span.color33_highlight { background-color: rgb(143,164,190) }\n\n	span.color34           { color:            rgb(173,193,217) }\n	span.color34_highlight { background-color: rgb(173,193,217) }\n\n	span.color35           { color:            rgb(223,167,166) }\n	span.color35_highlight { background-color: rgb(223,167,166) }\n\n	span.color36           { color:            rgb(206,221,176) }\n	span.color36_highlight { background-color: rgb(206,221,176) }\n\n	span.color37           { color:            rgb(191,178,207) }\n	span.color37_highlight { background-color: rgb(191,178,207) }\n\n	span.color38           { color:            rgb(165,213,226) }\n	span.color38_highlight { background-color: rgb(165,213,226) }\n\n	span.color39           { color:            rgb(250,206,170) }\n	span.color39_highlight { background-color: rgb(250,206,170) }\n\n	span.color40           { color:            rgb(165,165,165) }\n	span.color40_highlight { background-color: rgb(165,165,165) }\n\n	span.color41           { color:            rgb(89,89,89) }\n	span.color41_highlight { background-color: rgb(89,89,89) }\n\n	span.color42           { color:            rgb(125,121,116) }\n	span.color42_highlight { background-color: rgb(125,121,116) }\n\n	span.color43           { color:            rgb(87,118,157) }\n	span.color43_highlight { background-color: rgb(87,118,157) }\n\n	span.color44           { color:            rgb(132,162,198) }\n	span.color44_highlight { background-color: rgb(132,162,198) }\n\n	span.color45           { color:            rgb(207,123,121) }\n	span.color45_highlight { background-color: rgb(207,123,121) }\n\n	span.color46           { color:            rgb(181,204,136) }\n	span.color46_highlight { background-color: rgb(181,204,136) }\n\n	span.color47           { color:            rgb(159,140,183) }\n	span.color47_highlight { background-color: rgb(159,140,183) }\n\n	span.color48           { color:            rgb(120,192,212) }\n	span.color48_highlight { background-color: rgb(120,192,212) }\n\n	span.color49           { color:            rgb(247,181,128) }\n	span.color49_highlight { background-color: rgb(247,181,128) }\n\n	span.color50           { color:            rgb(140,140,140) }\n	span.color50_highlight { background-color: rgb(140,140,140) }\n\n	span.color51           { color:            rgb(63,63,63) }\n	span.color51_highlight { background-color: rgb(63,63,63) }\n\n	span.color52           { color:            rgb(87,85,81) }\n	span.color52_highlight { background-color: rgb(87,85,81) }\n\n	span.color53           { color:            rgb(23,54,93) }\n	span.color53_highlight { background-color: rgb(23,54,93) }\n\n	span.color54           { color:            rgb(69,98,135) }\n	span.color54_highlight { background-color: rgb(69,98,135) }\n\n	span.color55           { color:            rgb(144,60,57) }\n	span.color55_highlight { background-color: rgb(144,60,57) }\n\n	span.color56           { color:            rgb(117,140,72) }\n	span.color56_highlight { background-color: rgb(117,140,72) }\n\n	span.color57           { color:            rgb(96,76,120) }\n	span.color57_highlight { background-color: rgb(96,76,120) }\n\n	span.color58           { color:            rgb(56,129,148) }\n	span.color58_highlight { background-color: rgb(56,129,148) }\n\n	span.color59           { color:            rgb(183,117,64) }\n	span.color59_highlight { background-color: rgb(183,117,64) }\n\n	span.color60           { color:            rgb(127,127,127) }\n	span.color60_highlight { background-color: rgb(127,127,127) }\n\n	span.color61           { color:            rgb(38,38,38) }\n	span.color61_highlight { background-color: rgb(38,38,38) }\n\n	span.color62           { color:            rgb(62,60,58) }\n	span.color62_highlight { background-color: rgb(62,60,58) }\n\n	span.color63           { color:            rgb(15,36,62) }\n	span.color63_highlight { background-color: rgb(15,36,62) }\n\n	span.color64           { color:            rgb(46,65,90) }\n	span.color64_highlight { background-color: rgb(46,65,90) }\n\n	span.color65           { color:            rgb(96,40,38) }\n	span.color65_highlight { background-color: rgb(96,40,38) }\n\n	span.color66           { color:            rgb(78,93,48) }\n	span.color66_highlight { background-color: rgb(78,93,48) }\n\n	span.color67           { color:            rgb(64,51,80) }\n	span.color67_highlight { background-color: rgb(64,51,80) }\n\n	span.color68           { color:            rgb(37,86,99) }\n	span.color68_highlight { background-color: rgb(37,86,99) }\n\n	span.color69           { color:            rgb(122,78,43) }\n	span.color69_highlight { background-color: rgb(122,78,43) }\n\n\n	@media print {\n		/* Customize the styles of your printed articles by adding styles within this @media block. */\n	}\n	', 0);
SELECT 'Imported Table Template';
SELECT 'Importing Table TimeInterval';
SELECT 'Imported Table TimeInterval';
SELECT 'Importing Table TitleWord';
SELECT 'Imported Table TitleWord';
SELECT 'Importing Table TitleWordWord';
SELECT 'Imported Table TitleWordWord';
SELECT 'Importing Table TokenAssociation';
SELECT 'Imported Table TokenAssociation';
SELECT 'Importing Table Tokens';
INSERT INTO `Tokens` (`ixToken`, `fbToken`, `sIPAddress`, `ixPerson`, `ixPlugin`) VALUES (1, 'a707eba6i5htecrr98r7et6trc9552', '10.2.1.19', 2, 0);
SELECT 'Imported Table Tokens';
SELECT 'Importing Table TrainingRequest';
SELECT 'Imported Table TrainingRequest';
SELECT 'Importing Table Version';
INSERT INTO `Version` (`ixVersion`) VALUES (734);
SELECT 'Imported Table Version';
SELECT 'Importing Table Wiki';
SELECT 'Imported Table Wiki';
SELECT 'Importing Table WikiExternalLink';
SELECT 'Imported Table WikiExternalLink';
SELECT 'Importing Table WikiLink';
SELECT 'Imported Table WikiLink';
SELECT 'Importing Table WikiPage';
SELECT 'Imported Table WikiPage';
SELECT 'Importing Table WikiPageView';
SELECT 'Imported Table WikiPageView';
SELECT 'Importing Table Word';
SELECT 'Imported Table Word';
SELECT 'Importing Table Workflow';
INSERT INTO `Workflow` (`ixWorkflow`, `sWorkflow`, `fDeleted`) VALUES (1, 'Default Workflow', 0);
SELECT 'Imported Table Workflow';
SELECT 'Importing Table WorkflowRule';
SELECT 'Imported Table WorkflowRule';
SELECT 'Importing Table WorkingSchedule';
SELECT 'Imported Table WorkingSchedule';
